﻿using Microsoft.EntityFrameworkCore;

namespace DineHard.Data
{
    public class DineHardContext : DbContext
    {
        public DineHardContext(DbContextOptions<DineHardContext> options)
            : base(options)
        {
        }

        public DbSet<DineHard.Models.Recipe> Recipe { get; set; }

        public DbSet<DineHard.Models.Ingredient> Ingredient { get; set; }

        public DbSet<DineHard.Models.RecipeIngredient> RecipeIngredient { get; set; }

        public DbSet<DineHard.Models.SaveMenu> SaveMenu { get; set; }

    }
}
