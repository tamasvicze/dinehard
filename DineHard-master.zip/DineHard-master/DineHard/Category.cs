﻿namespace DineHard
{
    public enum Category
    {
        Chicken = 1,
        Beef,
        Vegan,
        Assorted
        /*Miscellaneous*/,
        Side,
        Pork,
        Seafood,
        Pasta,
        Vegetarian,
        Starter,
        Lamb,
        Goat
    }
}