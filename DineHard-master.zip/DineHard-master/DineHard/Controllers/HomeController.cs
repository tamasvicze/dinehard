﻿using DineHard.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using DineHard.Controllers.ViewModels;
using DineHard.Data;
using DineHard.Logic;
using Microsoft.EntityFrameworkCore;

namespace DineHard.Controllers
{
    using System;
    using System.Globalization;

    public static class FirstDayOfWeekUtility
    {
        /// <summary>
        /// Returns the first day of the week that the specified
        /// date is in using the current culture. 
        /// </summary>
        public static DateTime GetFirstDayOfWeek(DateTime dayInWeek)
        {
            CultureInfo defaultCultureInfo = CultureInfo.CreateSpecificCulture("nb-NO");
            return GetFirstDayOfWeek(dayInWeek, defaultCultureInfo);
        }

        /// <summary>
        /// Returns the first day of the week that the specified date 
        /// is in. 
        /// </summary>
        public static DateTime GetFirstDayOfWeek(DateTime dayInWeek, CultureInfo cultureInfo)
        {
            DayOfWeek firstDay = cultureInfo.DateTimeFormat.FirstDayOfWeek;
            DateTime firstDayInWeek = dayInWeek.Date;
            while (firstDayInWeek.DayOfWeek != firstDay)
                firstDayInWeek = firstDayInWeek.AddDays(-1);

            return firstDayInWeek;
        }
    }


    public class HomeController : Controller
    {
        private readonly DineHardContext _context;

        public HomeController(DineHardContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            return View();
        }


        [HttpPost]
        public async Task<IActionResult> GenerateMenu()
        {
            var dateNow = DateTime.Now.ToShortDateString();
            bool existsInDb = false;
            var allMenus = _context.SaveMenu.ToList();
            foreach (var n in allMenus)
            {
                if (n.Date.ToShortDateString() == dateNow)
                {
                    existsInDb = true;
                };
            };
            List<DateTime> weekDates = DateToSaveMenu.GenerateWeekDates();
            List<SaveMenu> mealPlan = new List<SaveMenu>();
            if (existsInDb == false)
            {
                var allRecipes = await _context.Recipe.Where(x => x.Wanted == true).Select(m => m.Id).ToListAsync();

                var randomMeals = GenerateRandomMeal.GenerateMealPlan(allRecipes, 7);
                var recipes = await _context.Recipe.Include(r => r.RecipeIngredients).Where(x => randomMeals.Contains(x.Id)).ToListAsync();

                for (int i = 0; i < 7; i++)
                {
                    mealPlan.Add(new SaveMenu
                    {
                        Date = weekDates[i],
                        Recipe = recipes[i]
                    });
                }
                _context.SaveMenu.AddRange(mealPlan);
                await _context.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Menu), new { date = weekDates[0] });
        }

        public async Task<IActionResult> Menu([FromQuery] DateTime date)
        {
            var menuItemInWeek = await _context.SaveMenu.ToListAsync();
            bool existInDB = false;
            foreach (var n in menuItemInWeek)
            {
                if (n.Date.ToShortDateString() == date.ToShortDateString())
                {
                    existInDB = true;
                }
            }

            if (existInDB == false)
            {
                return RedirectToAction(nameof(Index));
            }

            var startOfWeek = FirstDayOfWeekUtility.GetFirstDayOfWeek(date);
            var endOfWeek = startOfWeek.AddDays(7);

            var weekMenu = await _context.SaveMenu.Where(x => x.Date >= startOfWeek && x.Date < endOfWeek).Include(x => x.Recipe).ToListAsync();

            return View(weekMenu);
        }


        public async Task<IActionResult> Recipe(int id)
        {
            var recipe = await _context.Recipe
                .Include(x => x.RecipeIngredients)
                    .ThenInclude(x => x.Ingredient)
                .FirstAsync(x => x.Id == id);

            if (recipe == null)
            {
                return NotFound();
            }

            return View(recipe);
        }


        public ActionResult AddRecipe()
        {
            return View();
        }


        [HttpPost]
        public async Task<IActionResult> AddRecipe(AddRecipeViewModel viewModel)
        {

            if (ModelState.IsValid)
            {
                var newRecipe = new Recipe
                {
                    Title = viewModel.Title,
                    Region = viewModel.Region,
                    HowTo = viewModel.HowTo,
                    Wanted = true,
                    Custom = true,
                    Category = viewModel.Category
                };

                foreach (var ingredient in viewModel.Ingredients)
                {
                    newRecipe.RecipeIngredients.Add(new RecipeIngredient
                    {
                        Ingredient = new Ingredient
                        {
                            Name = ingredient.Name
                        },
                        Amount = ingredient.Amount,
                        Unit = ingredient.Unit
                    });
                }

                _context.Add(newRecipe);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Recipe), new { id = newRecipe.Id});
            }

            return View(viewModel);
        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }


        [HttpPost]
        public async Task<IActionResult> Reroll([FromForm] int id)
        {
            //var recipes = await _context.Recipe.Select(m => m.Id).ToListAsync();
            var recipes = await _context.Recipe.Where(x => x.Wanted == true).Select(m => m.Id).ToListAsync();

            var reRolledMeal = GenerateRandomMeal.GenerateMealPlan(recipes, 1);

            var recipeToAssign = await _context.Recipe.Include(r => r.RecipeIngredients).FirstAsync(x => x.Id == reRolledMeal[0]);
            var existingMenu = await _context.SaveMenu.FindAsync(id);

            existingMenu.Recipe = recipeToAssign;

            _context.Update(existingMenu);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Menu), new { date = existingMenu.Date });
        }


        [HttpPost]
        public async Task<IActionResult> NotWanted([FromForm] int id)
        {
            var existingMenu = await _context.SaveMenu.Include(x => x.Recipe).FirstAsync(x => x.Id == id);
            var previousRecipe = await _context.Recipe.FindAsync(existingMenu.Recipe.Id);
            previousRecipe.Wanted = false;

            _context.Update(previousRecipe);
            await _context.SaveChangesAsync();

            var recipes = await _context.Recipe.Where(x => x.Wanted == true).Select(m => m.Id).ToListAsync();
            var reRolledMeal = GenerateRandomMeal.GenerateMealPlan(recipes, 1);

            var recipeToAssign = await _context.Recipe.Include(r => r.RecipeIngredients).FirstAsync(x => x.Id == reRolledMeal[0]);
            existingMenu.Recipe = recipeToAssign;

            _context.Update(previousRecipe);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Menu), new { date = existingMenu.Date });
        }


        [HttpPost]
        public async Task<IActionResult> RerollWholeWeek([FromForm] int id)
        {
            var recipes = await _context.Recipe.Where(x => x.Wanted == true).Select(m => m.Id).ToListAsync();
            var reRolledMeal = GenerateRandomMeal.GenerateMealPlan(recipes, 7);

            var recipesToAssign = await _context.Recipe.Include(r => r.RecipeIngredients).Where(x => reRolledMeal.Contains(x.Id)).ToListAsync();
            var existingMenu = await _context.SaveMenu.FindAsync(id);

            var startOfWeek = FirstDayOfWeekUtility.GetFirstDayOfWeek(existingMenu.Date);
            var endOfWeek = startOfWeek.AddDays(7);

            var mealPlan = await _context.SaveMenu.Where(x => x.Date >= startOfWeek && x.Date < endOfWeek).ToListAsync();


            for (var i = 0; i <= mealPlan.Count() - 1; i++)
            {
                mealPlan[i].Recipe = recipesToAssign[i];
                _context.Update(mealPlan[i]);
            }

            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Menu), new { date = existingMenu.Date });
        }


        //public ActionResult CustomRecipes()
        //{
        //    return View();
        //}


        public async Task<IActionResult> CustomRecipes(Recipe recipe)
        {
            var customRecipes = await _context.Recipe.Where(r => r.Custom).ToListAsync();

            return View(customRecipes);
        }
    }
}