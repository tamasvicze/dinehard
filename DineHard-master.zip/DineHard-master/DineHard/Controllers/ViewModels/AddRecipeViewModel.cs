﻿using System.ComponentModel.DataAnnotations;

namespace DineHard.Controllers.ViewModels
{
    public class AddRecipeViewModel
    {
        [Required]
        [MinLength(2)]
        public string Title { get; set; }


        public Category Category { get; set; }

        [MinLength(3)]
        public string Region { get; set; }


        public string HowTo { get; set; }


        public AddRecipeIngredientViewModel[] Ingredients { get; set; }
    }

    public class AddRecipeIngredientViewModel
    {
        public string Unit { get; set; }

        public double Amount { get; set; }

        [Required]
        [StringLength(50)]
        public string Name { get; set; }
    }
}
