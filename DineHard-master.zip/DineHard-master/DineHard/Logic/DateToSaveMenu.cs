﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore.Migrations.Operations;

namespace DineHard.Logic
{
    public class DateToSaveMenu
    {

        public static List<DateTime> GenerateWeekDates()
        {
            DateTime today = DateTime.Now;
            //DateTime today = new DateTime(2021, 09, 28);
            List<DateTime> dates = new();
            if (today.DayOfWeek == DayOfWeek.Monday)
            {
                dates.Add(today);
                dates.Add(today.AddDays(1));
                dates.Add(today.AddDays(2));
                dates.Add(today.AddDays(3));
                dates.Add(today.AddDays(4));
                dates.Add(today.AddDays(5));
                dates.Add(today.AddDays(6));
            }
            else if (today.DayOfWeek == DayOfWeek.Tuesday)
            {
                dates.Add(today.AddDays(-1));
                dates.Add(today);
                dates.Add(today.AddDays(1));
                dates.Add(today.AddDays(2));
                dates.Add(today.AddDays(3));
                dates.Add(today.AddDays(4));
                dates.Add(today.AddDays(5));
            }
            else if (today.DayOfWeek == DayOfWeek.Wednesday)
            {
                dates.Add(today.AddDays(-2));
                dates.Add(today.AddDays(-1));
                dates.Add(today);
                dates.Add(today.AddDays(1));
                dates.Add(today.AddDays(2));
                dates.Add(today.AddDays(3));
                dates.Add(today.AddDays(4));
            }
            else if (today.DayOfWeek == DayOfWeek.Thursday)
            {
                dates.Add(today.AddDays(-3));
                dates.Add(today.AddDays(-2));
                dates.Add(today.AddDays(-1));
                dates.Add(today);
                dates.Add(today.AddDays(1));
                dates.Add(today.AddDays(2));
                dates.Add(today.AddDays(3));
            }
            else if (today.DayOfWeek == DayOfWeek.Friday)
            {
                dates.Add(today.AddDays(-4));
                dates.Add(today.AddDays(-3));
                dates.Add(today.AddDays(-2));
                dates.Add(today.AddDays(-1));
                dates.Add(today);
                dates.Add(today.AddDays(1));
                dates.Add(today.AddDays(2));
            }
            else if (today.DayOfWeek == DayOfWeek.Saturday)
            {
                dates.Add(today.AddDays(-5));
                dates.Add(today.AddDays(-4));
                dates.Add(today.AddDays(-3));
                dates.Add(today.AddDays(-2));
                dates.Add(today.AddDays(-1));
                dates.Add(today);
                dates.Add(today.AddDays(1));
            }
            else if (today.DayOfWeek == DayOfWeek.Sunday)
            {
                dates.Add(today.AddDays(-6));
                dates.Add(today.AddDays(-5));
                dates.Add(today.AddDays(-4));
                dates.Add(today.AddDays(-3));
                dates.Add(today.AddDays(-2));
                dates.Add(today.AddDays(-1));
                dates.Add(today);
            }

            return dates;
        }
    }
}
