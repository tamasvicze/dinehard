﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DineHard.Logic
{
    public class GenerateRandomMeal
    {
        public static List<int> GenerateMealPlan(List<int> recipesList, int recipesCount)
        {
            if (recipesCount > recipesList.Count) {
                throw new ArgumentException("Can't generate menu because recipesCount is bigger than the total amount of meals available");
            }

            Random random = new Random();

            var i = 1;

            List<int> recipeIds = new List<int>();

            while (i <= recipesCount) {
                int randomNumber = random.Next(0, recipesList.Count);
                int randomRecipes = recipesList[randomNumber];
                if (recipeIds.All(x => x != randomRecipes)) {
                    recipeIds.Add(randomRecipes);
                    i++;
                }
            }

            return recipeIds;
        }
    }
}