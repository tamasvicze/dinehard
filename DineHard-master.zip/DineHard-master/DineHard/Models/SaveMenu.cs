﻿using System;

namespace DineHard.Models
{
    public class SaveMenu
    {
        public int Id { get; set; }

        public DateTime Date { get; set; }

        public int RecipeId { get; set; }

        public Recipe Recipe { get; set; }
    }
}