﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace DineHard.Models
{
    public class Recipe
    {

        public Recipe()
        {
            RecipeIngredients = new List<RecipeIngredient>();
        }

        public int Id { get; set; }

        [Required]
        [MinLength(2)]
        public string Title { get; set; }

        public bool Custom { get; set; }

        [MinLength(3)]
        public string Region { get; set; }

        public string HowTo { get; set; }

        public string Image { get; set; }

        public bool Wanted { get; set; }

        public Category Category { get; set; }

        public ICollection<RecipeIngredient> RecipeIngredients { get; set; }

        public ICollection<SaveMenu> SaveMenus { get; set; }

        public override string ToString()
        {
            return $"{Title}";
        }
    }
}
