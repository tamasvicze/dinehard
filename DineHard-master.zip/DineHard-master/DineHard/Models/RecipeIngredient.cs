﻿using System.ComponentModel.DataAnnotations;

namespace DineHard.Models
{
    public class RecipeIngredient
    {
        public int Id { get; set; }

        public int RecipeId { get; set; }

        public Recipe Recipe { get; set; }

        public int IngredientId { get; set; }

        public Ingredient Ingredient { get; set; }

        [Range(0, 10000)]
        public double Amount { get; set; }

        [Range(1, 20)]
        public string Unit { get; set; } 

    }
    
}