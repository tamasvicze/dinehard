﻿SET IDENTITY_INSERT [dbo].[Ingredient] ON
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (1, N'soy sauce')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (2, N'water')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (3, N'brown sugar')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (4, N'ground ginger')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (5, N'minced garlic')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (6, N'cornstarch')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (7, N'chicken breasts')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (8, N'stir-fry vegetables')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (9, N'brown rice')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (10, N'Chicken Thighs')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (11, N'Challots')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (12, N'Ginger')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (13, N'Garlic Clove')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (14, N'Cayenne Pepper')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (15, N'Turmeric')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (16, N'Cumin')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (17, N'Coriander')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (18, N'Fennel')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (19, N'Tamarind Paste')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (20, N'Coconut Milk')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (21, N'Sugar')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (22, N'chicken breast')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (23, N'plain flour')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (24, N'egg')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (25, N'breadcrumbs')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (26, N'vegetable oil')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (27, N'sunflower oil')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (28, N'onions')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (29, N'garlic')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (30, N'carrot')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (31, N'plain flour')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (32, N'curry powder')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (33, N'chicken stock')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (34, N'honey')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (35, N'bay leaf')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (36, N'garam masala')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (37, N'Chicken')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (38, N'Red Chilli')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (39, N'Dried Oregano')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (40, N'Paprika')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (41, N'Red Wine Vinegar')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (42, N'Oil')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (43, N'Red Onions')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (44, N'Carrots')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (45, N'Beetroot')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (46, N'Cabbage')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (47, N'Mayonnaise')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (48, N'Greek Yogurt')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (49, N'Red Wine Vinegar')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (50, N'Cumin Seeds')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (51, N'Beef Brisket')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (52, N'Small Potatoes')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (53, N'Enchilada sauce')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (54, N'shredded Monterey Jack cheese')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (55, N'corn tortillas')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (56, N'self raising flour')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (57, N'coco sugar')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (58, N'cacao')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (59, N'baking powder')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (60, N'flax eggs')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (61, N'almond milk')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (62, N'vanilla')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (63, N'Beef')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (64, N'Salt')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (65, N'Sesame Seed Oil')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (66, N'Pepper')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (67, N'Egg White')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (68, N'Starch')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (69, N'Onion')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (70, N'Green Pepper')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (71, N'Celery')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (72, N'Mushrooms')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (73, N'Cooking wine')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (74, N'Oyster Sauce')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (75, N'Hotsauce')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (76, N'Butter')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (77, N'Potatoes')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (78, N'Black Pepper')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (79, N'Olive Oil')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (80, N'Worcestershire Sauce')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (81, N'Tomato Puree')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (82, N'Turkey Mince')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (83, N'Eggs')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (84, N'Barbeque Sauce')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (85, N'Cannellini Beans')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (86, N'Parsley')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (87, N'Chicken thigh')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (88, N'Sake')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (89, N'Granulated sugar')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (90, N'Potato starch')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (91, N'Lemon')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (92, N'Tiger Prawns')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (93, N'Dry White Wine')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (94, N'Brandy')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (95, N'Chopped Tomatoes')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (96, N'Fish Stock')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (97, N'Double Cream')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (98, N'Prawns')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (99, N'Bacon')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (100, N'Kielbasa')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (101, N'Pork')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (102, N'Flour')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (103, N'Sauerkraut')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (104, N'Red Wine')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (105, N'Basil')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (106, N'Marjoram')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (107, N'Caraway Seed')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (108, N'Beef Stock')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (109, N'Diced Tomatoes')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (110, N'Salmon')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (111, N'Sesame Seed')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (112, N'Avocado')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (113, N'Cucumber')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (114, N'Spinach')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (115, N'Mint')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (116, N'Lime')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (117, N'Floury Potatoes')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (118, N'Spring Onions')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (119, N'Mustard')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (120, N'Ham')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (121, N'Ground Beef')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (122, N'Ground Pork')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (123, N'Rice')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (124, N'Sour Cream')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (125, N'Chopped Onion')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (126, N'Bread')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (127, N'Tomato')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (128, N'Mozzarella')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (129, N'Brussels Sprouts')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (130, N'Wood Ear Mushrooms')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (131, N'Tofu')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (132, N'Vinegar')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (133, N'Pickle Juice')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (134, N'Milk')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (135, N'Icing Sugar')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (136, N'Garlic Powder')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (137, N'Celery Salt')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (138, N'Sesame Seed Burger Buns')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (139, N'Peas')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (140, N'Vegetable Stock Cube')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (141, N'Leek')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (142, N'Celeriac')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (143, N'Sausages')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (144, N'Sardines')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (145, N'Rosemary')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (146, N'Corn Flour')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (147, N'Chilli Powder')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (148, N'Rice Vinegar')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (149, N'Water Chestnut')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (150, N'Peanuts')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (151, N'Scallions')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (152, N'onion salt')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (153, N'chili powder')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (154, N'sage')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (155, N'allspice')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (156, N'oregano')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (157, N'French Lentils')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (158, N'Thyme')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (159, N'Basmati Rice')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (160, N'Kidney Beans')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (161, N'Swede')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (162, N'Tomatoes')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (163, N'Red Pepper')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (164, N'Macaroni')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (165, N'Mustard Powder')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (166, N'Kosher salt')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (167, N'Whole Milk')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (168, N'Heavy Cream')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (169, N'Monterey Jack Cheese')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (170, N'Cheddar Cheese')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (171, N'Colby Jack Cheese')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (172, N'Cloves')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (173, N'Dill')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (174, N'English Mustard')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (175, N'Red Pepper Flakes')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (176, N'Toor dal')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (177, N'Ghee')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (178, N'Mustard Seeds')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (179, N'Green Chili')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (180, N'Cilantro')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (181, N'Lemon Juice')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (182, N'Roasted Vegetables')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (183, N'Mixed Grain')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (184, N'Tahini')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (185, N'Yellow Pepper')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (186, N'Green Beans')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (187, N'Courgettes')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (188, N'Kale')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (189, N'Lentils')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (190, N'Oxtail')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (191, N'Scotch Bonnet')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (192, N'Fresh Thyme')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (193, N'Broad Beans')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (194, N'Chilli')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (195, N'Chinese Broccoli')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (196, N'Noodles')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (197, N'Parmesan')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (198, N'Tarragon')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (199, N'Chives')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (200, N'Gruyère')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (201, N'Apples')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (202, N'Zucchini')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (203, N'Cinnamon Stick')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (204, N'Star Anise')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (205, N'Cardamom')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (206, N'Coconut Cream')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (207, N'Minced Beef')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (208, N'Minced Pork')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (209, N'Chicken Legs')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (210, N'Tomato Sauce')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (211, N'Butter Beans')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (212, N'Black Treacle')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (213, N'White Vinegar')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (214, N'Passata')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (215, N'Mulukhiyah')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (216, N'Udon Noodles')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (217, N'Shiitake Mushrooms')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (218, N'Mirin')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (219, N'Caster Sugar')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (220, N'horseradish')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (221, N'cherry tomatoes')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (222, N'Ginger Paste')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (223, N'Anchovy Fillet')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (224, N'Shallots')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (225, N'Anchovy Fillet')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (226, N'Lamb')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (227, N'Lamb Kidney')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (228, N'Bay Leaves')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (229, N'Saffron')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (230, N'Rapeseed Oil')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (231, N'Vegetable Stock')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (232, N'Broccoli')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (233, N'Stilton Cheese')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (234, N'Unsalted Butter')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (235, N'Bicarbonate Of Soda')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (236, N'whole wheat')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (237, N'lamb loin chops')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (238, N'turnips')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (239, N'charlotte potatoes')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (240, N'white wine')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (241, N'Herring')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (242, N'Egg Yolks')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (243, N'Tinned Tomatos')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (244, N'Black Olives')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (245, N'Gruyere cheese')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (246, N'rice stick noodles')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (247, N'dark soy sauce')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (248, N'peanut oil')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (249, N'Lettuce')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (250, N'Duck Sauce')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (251, N'Gochujang')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (252, N'cajun')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (253, N'white fish')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (254, N'flour tortilla')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (255, N'little gem lettuce')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (256, N'spring onion')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (257, N'salsa')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (258, N'fajita seasoning')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (259, N'Puff Pastry')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (260, N'Raw king prawns')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (261, N'Freshly chopped parsley')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (262, N'Cubed Feta cheese')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (263, N'Chorizo')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (264, N'Sun-Dried Tomatoes')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (265, N'Lemons')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (266, N'Veal')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (267, N'Orange Zest')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (268, N'Lemon Zest')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (269, N'Goat Meat')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (270, N'Green Chilli')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (271, N'Coriander Leaves')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (272, N'Egg Plants')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (273, N'Harissa')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (274, N'Chickpeas')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (275, N'Ground cumin')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (276, N'Aubergine')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (277, N'Linguine Pasta')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (278, N'Sugar Snap Peas')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (279, N'King Prawns')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (280, N'Basil Leaves')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (281, N'Fromage Frais')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (282, N'Cinnamon')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (283, N'Chopped Parsley')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (284, N'chestnut mushroom')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (285, N'Sea Salt')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (286, N'Iceberg Lettuce')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (287, N'Cheese')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (288, N'Dill Pickles')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (289, N'White Wine Vinegar')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (290, N'Clotted Cream')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (291, N'Parmesan Cheese')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (292, N'Nutmeg')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (293, N'Fettuccine')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (294, N'Yeast')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (295, N'Red Snapper')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (296, N'Malt Vinegar')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (297, N'Filo Pastry')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (298, N'red chili')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (299, N'Thai red curry paste')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (300, N'fish sauce')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (301, N'rice noodles')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (302, N'vine leaves')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (303, N'fennel bulb')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (304, N'lamb mince')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (305, N'potato')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (306, N'clove')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (307, N'Ginger Cordial')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (308, N'Capers')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (309, N'Tuna')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (310, N'Creme Fraiche')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (311, N'Chicken Stock Cube')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (312, N'Pita Bread')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (313, N'Stout')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (314, N'Oysters')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (315, N'Harissa Spice')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (316, N'Rocket')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (317, N'Feta')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (318, N'Pine nuts')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (319, N'mozzarella balls')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (320, N'baby plum tomatoes')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (321, N'fresh basil')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (322, N'farfalle')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (323, N'extra virgin olive oil')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (324, N'Green Olives')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (325, N'Peanut Butter')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (326, N'Cream Cheese')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (327, N'Smoked Haddock')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (328, N'Free-range Egg, Beaten')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (329, N'Cold Water')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (330, N'Free-range Egg, Beaten')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (331, N'Lamb Leg')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (332, N'Apricot')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (333, N'Butternut Squash')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (334, N'Couscous')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (335, N'Coriander seeds')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (336, N'Turmeric powder')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (337, N'Yogurt')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (338, N'Cream')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (339, N'fenugreek')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (340, N'Paneer')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (341, N'Naan Bread')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (342, N'Quinoa')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (343, N'Haddock')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (344, N'Bean Sprouts')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (345, N'lean minced beef')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (346, N'hot beef stock')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (347, N'spaghetti')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (348, N'Goose Fat')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (349, N'Fennel Seeds')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (350, N'Haricot Beans')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (351, N'Beef Fillet')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (352, N'Lard')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (353, N'Madras Paste')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (354, N'Tomato Purée')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (355, N'Red Chili Powder')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (356, N'Semi-skimmed Milk')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (357, N'White Fish Fillets')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (358, N'Jerusalem Artichokes')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (359, N'Pecorino')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (360, N'Lamb Shoulder')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (361, N'Garlic Sauce')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (362, N'Sushi Rice')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (363, N'Brown Lentils')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (364, N'All spice')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (365, N'Ancho Chillies')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (366, N'Balsamic Vinegar')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (367, N'Plum Tomatoes')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (368, N'Tomato Ketchup')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (369, N'Dark Brown Sugar')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (370, N'Borlotti Beans')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (371, N'green red lentils')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (372, N'lasagne sheets')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (373, N'vegan butter')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (374, N'soya milk')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (375, N'Beef Gravy')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (376, N'Cheese Curds')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (377, N'Apple Cider Vinegar')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (378, N'Brie')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (379, N'Prosciutto')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (380, N'Shortcrust Pastry')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (381, N'Pilchards')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (382, N'Beef Shin')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (383, N'Bouquet Garni')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (384, N'Ras el hanout')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (385, N'Pumpkin')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (386, N'Cod')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (387, N'Squid')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (388, N'Clams')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (389, N'Mussels')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (390, N'Baguette')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (391, N'Duck Legs')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (392, N'Paccheri Pasta')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (393, N'Pork Chops')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (394, N'Suet')
INSERT INTO [dbo].[Ingredient] ([Id], [Name]) VALUES (395, N'Orange')
SET IDENTITY_INSERT [dbo].[Ingredient] OFF
SET IDENTITY_INSERT [dbo].[Recipe] ON
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (1, N'Teriyaki Chicken Casserole', 0, N'Japanese', N'Preheat oven to 350° F. Spray a 9x13-inch baking pan with non-stick spray.
Combine soy sauce, ½ cup water, brown sugar, ginger and garlic in a small saucepan and cover. Bring to a boil over medium heat. Remove lid and cook for one minute once boiling.
Meanwhile, stir together the corn starch and 2 tablespoons of water in a separate dish until smooth. Once sauce is boiling, add mixture to the saucepan and stir to combine. Cook until the sauce starts to thicken then remove from heat.
Place the chicken breasts in the prepared pan. Pour one cup of the sauce over top of chicken. Place chicken in oven and bake 35 minutes or until cooked through. Remove from oven and shred chicken in the dish using two forks.
*Meanwhile, steam or cook the vegetables according to package directions.
Add the cooked vegetables and rice to the casserole dish with the chicken. Add most of the remaining sauce, reserving a bit to drizzle over the top when serving. Gently toss everything together in the casserole dish until combined. Return to oven and cook 15 minutes. Remove from oven and let stand 5 minutes before serving. Drizzle each serving with remaining sauce. Enjoy!', 1, 1)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (2, N'Ayam Percik', 0, N'Malaysian', N'In a blender, add the ingredients for the spice paste and blend until smooth.
Over medium heat, pour the spice paste in a skillet or pan and fry for 10 minutes until fragrant. Add water or oil 1 tablespoon at a time if the paste becomes too dry. Don''t burn the paste. Lower the fire slightly if needed.
Add the cloves, cardamom, tamarind pulp, coconut milk, water, sugar and salt. Turn the heat up and bring the mixture to boil. Turn the heat to medium low and simmer for 10 minutes. Stir occasionally. It will reduce slightly. This is the marinade/sauce, so taste and adjust seasoning if necessary. Don''t worry if it''s slightly bitter. It will go away when roasting.
When the marinade/sauce has cooled, pour everything over the chicken and marinate overnight to two days.
Preheat the oven to 425 F.
Remove the chicken from the marinade. Spoon the marinade onto a greased (or aluminum lined) baking sheet. Lay the chicken on top of the sauce (make sure the chicken covers the sauce and the sauce isn''t exposed or it''ll burn) and spread the remaining marinade on the chicken. Roast for 35-45 minutes or until internal temp of the thickest part of chicken is at least 175 F.
Let chicken rest for 5 minutes. Brush the chicken with some of the oil. Serve chicken with the sauce over steamed rice (or coconut rice).', 1, 1)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (3, N'Katsu Chicken curry', 0, N'Japanese', N'Prep:15min  ›  Cook:30min  ›  Ready in:45min 

For the curry sauce: Heat oil in medium non-stick saucepan, add onion and garlic and cook until softened. Stir in carrots and cook over low heat for 10 to 12 minutes.
Add flour and curry powder; cook for 1 minute. Gradually stir in stock until combined; add honey, soy sauce and bay leaf. Slowly bring to the boil.
Turn down heat and simmer for 20 minutes or until sauce thickens but is still of pouring consistency. Stir in garam masala. Pour the curry sauce through a sieve; return to saucepan and keep on low heat until ready to serve.
For the chicken: Season both sides of chicken breasts with salt and pepper. Place flour, egg and breadcrumbs in separate bowls and arrange in a row. Coat the chicken breasts in flour, then dip them into the egg, then coat in breadcrumbs, making sure you cover both sides.
Heat oil in large frying pan over medium-high heat. Place chicken into hot oil and cook until golden brown, about 3 or 4 minutes each side. Once cooked, place on kitchen paper to absorb excess oil.
Pour curry sauce over chicken, serve with white rice and enjoy!', 1, 1)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (4, N'Piri-piri chicken and slaw', 0, N'Portuguese', N'STEP 1

Whizz together all of the marinade ingredients in a small food processor. Rub the marinade onto the chicken and leave for 1 hour at room temperature.

STEP 2

Heat the oven to 190C/fan 170C/gas 5. Put the chicken in a roasting tray and cook for 1 hour 20 minutes. Rest under loose foil for 20 minutes. While the chicken is resting, mix together the slaw ingredients and season. Serve the chicken with slaw, fries and condiments.', 1, 1)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (5, N'Corned Beef and Cabbage', 0, N'Irish', N'1

Place corned beef in large pot or Dutch oven and cover with water. Add the spice packet that came with the corned beef. Cover pot and bring to a boil, then reduce to a simmer. Simmer approximately 50 minutes per pound or until tender.

2

Add whole potatoes and peeled and cut carrots, and cook until the vegetables are almost tender. Add cabbage and cook for 15 more minutes. Remove meat and let rest 15 minutes.

3

Place vegetables in a bowl and cover. Add as much broth (cooking liquid reserved in the Dutch oven or large pot) as you want. Slice meat across the grain.', 1, 2)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (6, N'Chicken Enchilada Casserole', 0, N'Mexican', N'Cut each chicken breast in about 3 pieces, so that it cooks faster and put it in a small pot. Pour Enchilada sauce over it and cook covered on low to medium heat until chicken is cooked through, about 20 minutes. No water is needed, the chicken will cook in the Enchilada sauce. Make sure you stir occasionally so that it doesn''t stick to the bottom.
Remove chicken from the pot and shred with two forks.
Preheat oven to 375 F degrees.
Start layering the casserole. Start with about ¼ cup of the leftover Enchilada sauce over the bottom of a baking dish. I used a longer baking dish, so that I can put 2 corn tortillas across. Place 2 tortillas on the bottom, top with ⅓ of the chicken and ⅓ of the remaining sauce. Sprinkle with ⅓ of the cheese and repeat starting with 2 more tortillas, then chicken, sauce, cheese. Repeat with last layer with the remaining ingredients, tortillas, chicken, sauce and cheese.
Bake for 20 to 30 minutes uncovered, until bubbly and cheese has melted and started to brown on top.
Serve warm.', 1, 1)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (7, N'Vegan Chocolate Cake', 0, N'American', N'Simply mix all dry ingredients with wet ingredients and blend altogether. Bake for 45 min on 180 degrees. Decorate with some melted vegan chocolate ', 1, 3)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (8, N'Szechuan Beef', 0, N'Chinese', N'STEP 1 - MARINATING THE BEEF
In a bowl, add the beef, salt, sesame seed oil, white pepper, egg white, 2 Tablespoon of corn starch and 1 Tablespoon of oil.
STEP 2 - STIR FRY
First Cook the beef by adding 2 Tablespoon of oil until the beef is golden brown.
Set the beef aside
In a wok add 1 Tablespoon of oil, minced ginger, minced garlic and stir-fry for few seconds.
Next add all of the vegetables and then add sherry cooking wine and 1 cup of water.
To make the sauce add oyster sauce, hot pepper sauce, and sugar.
add the cooked beef and 1 spoon of soy sauce
To thicken the sauce, whisk together 1 Tablespoon of cornstarch and 2 Tablespoon of water in a bowl and slowly add to your stir-fry until it''s the right thickness.', 1, 2)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (9, N'Rappie Pie', 0, N'Canadian', N'Preheat oven to 400 degrees F (200 degrees C). Grease a 10x14x2-inch baking pan.
Heat margarine in a skillet over medium heat; stir in onion. Cook and stir until onion has softened and turned translucent, about 5 minutes. Reduce heat to low and continue to cook and stir until onion is very tender and dark brown, about 40 minutes more.
Bring chicken broth to a boil in a large pot; stir in chicken breasts, reduce heat, and simmer until chicken is no longer pink at the center, about 20 minutes. Remove from heat. Remove chicken breasts to a plate using a slotted spoon; reserve broth.
Juice potatoes with an electric juicer; place dry potato flesh into a bowl and discard juice. Stir salt and pepper into potatoes; stir in enough reserved broth to make the mixture the consistency of oatmeal. Set remaining broth aside.
Spread half of potato mixture evenly into the prepared pan. Lay cooked chicken breast evenly over potatoes; scatter caramelized onion evenly over chicken. Spread remaining potato mixture over onions and chicken to cover.
Bake in the preheated oven until golden brown, about 1 hour. Reheat chicken broth; pour over individual servings as desired.', 1, 1)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (10, N'Turkey Meatloaf', 0, N'British', N'Heat oven to 180C/160C fan/gas 4. Heat the oil in a large frying pan and cook the onion for 8-10 mins until softened. Add the garlic, Worcestershire sauce and 2 tsp tomato purée, and stir until combined. Set aside to cool.

Put the turkey mince, egg, breadcrumbs and cooled onion mix in a large bowl and season well. Mix everything to combine, then shape into a rectangular loaf and place in a large roasting tin. Spread 2 tbsp barbecue sauce over the meatloaf and bake for 30 mins.

Meanwhile, drain 1 can of beans only, then pour both cans into a large bowl. Add the remaining barbecue sauce and tomato purée. Season and set aside.

When the meatloaf has had its initial cooking time, scatter the beans around the outside and bake for 15 mins more until the meatloaf is cooked through and the beans are piping hot. Scatter over the parsley and serve the meatloaf in slices.', 1, 4)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (11, N'Chicken Karaage', 0, N'Japanese', N'Add the ginger, garlic, soy sauce, sake and sugar to a bowl and whisk to combine. Add the chicken, then stir to coat evenly. Cover and refrigerate for at least 1 hour.

Add 1 inch of vegetable oil to a heavy bottomed pot and heat until the oil reaches 360 degrees F. Line a wire rack with 2 sheets of paper towels and get your tongs out. Put the potato starch in a bowl

Add a handful of chicken to the potato starch and toss to coat each piece evenly.

Fry the karaage in batches until the exterior is a medium brown and the chicken is cooked through. Transfer the fried chicken to the paper towel lined rack. If you want the karaage to stay crispy longer, you can fry the chicken a second time, until it''s a darker color after it''s cooled off once. Serve with lemon wedges.', 1, 1)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (12, N'Prawn & Fennel Bisque', 0, N'French', N'Shell the prawns, then fry the shells in the oil in a large pan for about 5 mins. Add the onion, fennel and carrots and cook for about 10 mins until the veg start to soften. Pour in the wine and brandy, bubble hard for about 1 min to drive off the alcohol, then add the tomatoes, stock and paprika. Cover and simmer for 30 mins. Meanwhile, chop the prawns.
Blitz the soup as finely as you can with a stick blender or food processor, then press through a sieve into a bowl. Spend a bit of time really working the mixture through the sieve as this will give the soup its velvety texture.
Tip back into a clean pan, add the prawns and cook for 10 mins, then blitz again until smooth. You can make and chill this a day ahead or freeze it for 1 month. Thaw ovenight in the fridge. To serve, gently reheat in a pan with the cream. If garnishing, cook the 8 prawns in a little butter. Spoon into small bowls and top with the prawns and snipped fennel fronds.', 1, 5)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (13, N'Bigos (Hunters Stew)', 0, N'Polish', N'Preheat the oven to 350 degrees F (175 degrees C).

Heat a large pot over medium heat. Add the bacon and kielbasa; cook and stir until the bacon has rendered its fat and sausage is lightly browned. Use a slotted spoon to remove the meat and transfer to a large casserole or Dutch oven.

Coat the cubes of pork lightly with flour and fry them in the bacon drippings over medium-high heat until golden brown. Use a slotted spoon to transfer the pork to the casserole. Add the garlic, onion, carrots, fresh mushrooms, cabbage and sauerkraut. Reduce heat to medium; cook and stir until the carrots are soft, about 10 minutes. Do not let the vegetables brown.

Deglaze the pan by pouring in the red wine and stirring to loosen all of the bits of food and flour that are stuck to the bottom. Season with the bay leaf, basil, marjoram, paprika, salt, pepper, caraway seeds and cayenne pepper; cook for 1 minute.

Mix in the dried mushrooms, hot pepper sauce, Worcestershire sauce, beef stock, tomato paste and tomatoes. Heat through just until boiling. Pour the vegetables and all of the liquid into the casserole dish with the meat. Cover with a lid.

Bake in the preheated oven for 2 1/2 to 3 hours, until meat is very tender.', 1, 6)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (14, N'Honey Teriyaki Salmon', 0, N'Japanese', N'Mix all the ingredients in the Honey Teriyaki Glaze together. Whisk to blend well. Combine the salmon and the Glaze together.

Heat up a skillet on medium-low heat. Add the oil, Pan-fry the salmon on both sides until it’s completely cooked inside and the glaze thickens.

Garnish with sesame and serve immediately.', 1, 7)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (15, N'Salmon Avocado Salad', 0, N'British', N'Season the salmon, then rub with oil. Mix the dressing ingredients together. Halve, stone, peel and slice the avocados. Halve and quarter the cucumber lengthways, then cut into slices. Divide salad, avocado and cucumber between four plates, then drizzle with half the dressing.

Heat a non-stick pan. Add the salmon and fry for 3-4 mins on each side until crisp but still moist inside. Put a salmon fillet on top of each salad and drizzle over the remaining dressing. Serve warm.', 1, 7)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (16, N'Ham hock colcannon', 0, N'Irish', N'STEP 1
Peel and cut the potatoes into even, medium-sized chunks. Put in a large pan filled with cold salted water, bring to the boil and cook for 10-15 mins until a knife can be inserted into the potatoes easily.

STEP 2
Meanwhile, melt the butter in a large sauté pan over a medium heat. Add the garlic, cabbage, spring onions and some seasoning. Stir occasionally until the cabbage is wilted but still retains a little bite, then set aside.

STEP 3
Drain the potatoes, leave to steam-dry for a couple of mins, then mash with the cream, mustard and seasoning in the same saucepan. Stir in the cabbage and ham hock. Keep warm over a low heat.

STEP 4
Reheat the pan you used to cook the cabbage (no need to wash first), add a splash of oil, crack in the eggs and fry to your liking. To serve, divide the colcannon between bowls and top each with a fried egg.', 1, 6)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (17, N'Gołąbki (cabbage roll)', 0, N'Polish', N'Bring a large pot of lightly salted water to a boil. Place cabbage head into water, cover pot, and cook until cabbage leaves are slightly softened enough to remove from head, 3 minutes. Remove cabbage from pot and let cabbage sit until leaves are cool enough to handle, about 10 minutes.

Remove 18 whole leaves from the cabbage head, cutting out any thick tough center ribs. Set whole leaves aside. Chop the remainder of the cabbage head and spread it in the bottom of a casserole dish.

Melt butter in a large skillet over medium-high heat. Cook and stir onion in hot butter until tender, 5 to 10 minutes. Cool.

Stir onion, beef, pork, rice, garlic, 1 teaspoon salt, and 1/4 teaspoon pepper together in a large bowl.

Preheat oven to 350 degrees F (175 degrees C).

Place about 1/2 cup beef mixture on a cabbage leaf. Roll cabbage around beef mixture, tucking in sides to create an envelope around the meat. Repeat with remaining leaves and meat mixture. Place cabbage rolls in a layer atop the chopped cabbage in the casserole dish; season rolls with salt and black pepper.

Whisk tomato soup, tomato juice, and ketchup together in a bowl. Pour tomato soup mixture over cabbage rolls and cover dish wish aluminum foil.

Bake in the preheated oven until cabbage is tender and meat is cooked through, about 1 hour.', 1, 2)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (18, N'Lasagna Sandwiches', 0, N'American', N'1. In a small bowl, combine the first four ingredients; spread on four slices of bread. Layer with bacon, tomato and cheese; top with remaining bread.

2. In a large skillet or griddle, melt 2 tablespoons butter. Toast sandwiches until lightly browned on both sides and cheese is melted, adding butter if necessary.

Nutrition Facts
1 sandwich: 445 calories, 24g fat (12g saturated fat), 66mg cholesterol, 1094mg sodium, 35g carbohydrate (3g sugars, 2g fiber), 21g protein.', 1, 8)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (19, N' Bubble & Squeak', 0, N'British', N'Melt the fat in a non-stick pan, allow it to get nice and hot, then add the bacon. As it begins to brown, add the onion and garlic. Next, add the sliced sprouts or cabbage and let it colour slightly. All this will take 5-6 mins.
Next, add the potato. Work everything together in the pan and push it down so that the mixture covers the base of the pan – allow the mixture to catch slightly on the base of the pan before turning it over and doing the same again. It’s the bits of potato that catch in the pan that define the term ‘bubble and squeak’, so be brave and let the mixture colour. Cut into wedges and serve.', 1, 6)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (20, N'Hot and Sour Soup', 0, N'Chinese', N'STEP 1 - MAKING THE SOUP
In a wok add chicken broth and wait for it to boil.
Next add salt, sugar, sesame seed oil, white pepper, hot pepper sauce, vinegar and soy sauce and stir for few seconds.
Add Tofu, mushrooms, black wood ear mushrooms to the wok.
To thicken the sauce, whisk together 1 Tablespoon of cornstarch and 2 Tablespoon of water in a bowl and slowly add to your soup until it''s the right thickness.
Next add 1 egg slightly beaten with a knife or fork and add it to the soup and stir for 8 seconds
Serve the soup in a bowl and add the bbq pork and sliced green onions on top.', 1, 6)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (21, N'Chick-Fil-A Sandwich', 0, N'American', N'Wrap the chicken loosely between plastic wrap and pound gently with the flat side of a meat tenderizer until about 1/2 inch thick all around.
Cut into two pieces, as even as possible.
Marinate in the pickle juice for 30 minutes to one hour (add a teaspoon of Tabasco sauce now for a spicy sandwich).
Beat the egg with the milk in a bowl.
Combine the flour, sugar, and spices in another bowl.
Dip the chicken pieces each into the egg on both sides, then coat in flour on both sides.
Heat the oil in a skillet (1/2 inch deep) to about 345-350.
Fry each cutlet for 2 minutes on each side, or until golden and cooked through.
Blot on paper and serve on toasted buns with pickle slices.', 1, 1)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (22, N'Snert (Dutch Split Pea Soup)', 0, N'Dutch', N'Gather the ingredients.

In a large soup pot, bring water, split peas, pork belly or bacon, pork chop, and bouillon cube to a boil. Reduce the heat to a simmer, cover and let cook for 45 minutes, stirring occasionally and skimming off any foam that rises to the top. 

Remove the pork chop, debone, and thinly slice the meat. Set aside.

Add the celery, carrots, potato, onion, leek, and celeriac to the soup. Return to the boil, reduce the heat to a simmer and let cook, uncovered, for another 30 minutes, adding a little extra water if the ingredients start to stick to the bottom of the pot.

Add the smoked sausage for the last 15 minutes of cooking time. When the vegetables are tender, remove the bacon and smoked sausage, slice thinly and set aside.

If you prefer a smooth consistency, purée the soup with a stick blender. Season to taste with salt and pepper. Add the meat back to the soup, setting some slices of rookworst aside.

Serve in heated bowls or soup plates, garnished with slices of rookworst and chopped celery leaf.

Enjoy!', 1, 5)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (23, N'Grilled Portuguese sardines', 0, N'Portuguese', N'STEP 1

Put all of the ingredients, except the sardines, into a bowl and mix together with some seasoning. Pour into a baking dish, add the sardines and toss really well. Cover and chill for a few hours.

STEP 2

Heat a BBQ or griddle pan until hot. Cook the sardines for 4-5 minutes on each side or until really caramelised and charred. Put onto a serving plate, drizzle with oil, sprinkle with a little more paprika and squeeze over the lemon wedges.', 1, 7)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (24, N'Kung Pao Chicken', 0, N'Chinese', N'Combine the sake or rice wine, soy sauce, sesame oil and cornflour dissolved in water. Divide mixture in half.
In a glass dish or bowl, combine half of the sake mixture with the chicken pieces and toss to coat. Cover dish and place in refrigerator for about 30 minutes.
In a medium frying pan, combine remaining sake mixture, chillies, vinegar and sugar. Mix together and add spring onion, garlic, water chestnuts and peanuts. Heat sauce slowly over medium heat until aromatic.
Meanwhile, remove chicken from marinade and sauté in a large frying pan until juices run clear. When sauce is aromatic, add sautéed chicken and let simmer together until sauce thickens.', 1, 1)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (25, N'Soy-Glazed Meatloaves with Wasabi Mashed Potatoes & Roasted Carrots', 0, N'American', N'1. Preheat oven to 425 degrees. Wash and dry all produce. Dice potatoes into 1/2-inch pieces. Trim, peel, and cut carrots on a diagonal into 1/2-inch-thick pieces. Trim and thinly slice scallions, separating whites from greens; finely chop whites. Peel and finely chop garlic.

2. In a medium bowl, soak bread with 2 TBSP water (4 TBSP for 4 servings); break up with your hands until pasty. Stir in beef, sriracha, scallion whites, half the garlic, salt (we used 3/4 tsp kosher salt; 11/2 tsp for 4), and pepper. Form into two 1-inch-tall loaves (four loaves for 4). Place on one side of a baking sheet. Toss carrots on empty side of same sheet with a drizzle of oil, salt, and pepper. (For 4, spread meatloaves out across whole sheet and add carrots to a second sheet.) Bake for 20 minutes (we''ll glaze the meatloaves then).

3. Meanwhile, place potatoes in a medium pot with enough salted water to cover by 2 inches. Bring to a boil and cook until very
tender, 12-15 minutes. Reserve 1/2 cup potato cooking liquid, then drain. While potatoes cook, in a small bowl, combine soy sauce, garlic powder, 1/4 cup ketchup (1/2 cup for 4 servings), and 2 tsp sugar (4 tsp for 4).

4. Once meatloaves and carrots have baked 20 minutes, remove from oven. Spoon half the ketchup glaze over meatloaves (save
the rest for serving); return to oven until carrots are browned and tender, meatloaves are cooked through, and glaze is tacky, 4-5 minutes more.

5. Meanwhile, melt 2 TBSP butter (4 TBSP for 4 servings) in pot used for potatoes over medium heat. Add remaining garlic and cook
until fragrant, 30 seconds. Add potatoes and 1/4 tsp wasabi. Mash, adding splashes of reserved potato cooking liquid as necessary until smooth. Season with salt and pepper. (If you like things spicy, stir in more wasabi!)

6. Divide meatloaves, mashed potatoes, and roasted carrots between plates. Sprinkle with scallion greens and serve with remaining ketchup glaze on the side for dipping.', 1, 2)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (26, N'Kentucky Fried Chicken', 0, N'American', N'Preheat fryer to 350°F. Thoroughly mix together all the spice mix ingredients.
Combine spice mix with flour, brown sugar and salt.
Dip chicken pieces in egg white to lightly coat them, then transfer to flour mixture. Turn a few times and make sure the flour mix is really stuck to the chicken. Repeat with all the chicken pieces.
Let chicken pieces rest for 5 minutes so crust has a chance to dry a bit.
Fry chicken in batches. Breasts and wings should take 12-14 minutes, and legs and thighs will need a few more minutes. Chicken pieces are done when a meat thermometer inserted into the thickest part reads 165°F.
Let chicken drain on a few paper towels when it comes out of the fryer. Serve hot.', 1, 1)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (27, N'French Lentils With Garlic and Thyme', 0, N'French', N'Place a large saucepan over medium heat and add oil. When hot, add chopped vegetables and sauté until softened, 5 to 10 minutes.
Add 6 cups water, lentils, thyme, bay leaves and salt. Bring to a boil, then reduce to a fast simmer.
Simmer lentils until they are tender and have absorbed most of the water, 20 to 25 minutes. If necessary, drain any excess water after lentils have cooked. Serve immediately, or allow them to cool and reheat later.
For a fuller taste, use some chicken stock and reduce the water by the same amount.', 1, 4)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (28, N'Jerk chicken with rice & peas', 0, N'Jamaican', N'To make the jerk marinade, combine all the ingredients in a food processor along with 1 tsp salt, and blend to a purée. If you’re having trouble getting it to blend, just keep turning off the blender, stirring the mixture, and trying again. Eventually it will start to blend up – don’t be tempted to add water, as you want a thick paste.

Taste the jerk mixture for seasoning – it should taste pretty salty, but not unpleasantly, puckering salty. You can now throw in more chillies if it’s not spicy enough for you. If it tastes too salty and sour, try adding in a bit more brown sugar until the mixture tastes well balanced.

Make a few slashes in the chicken thighs and pour the marinade over the meat, rubbing it into all the crevices. Cover and leave to marinate overnight in the fridge.

If you want to barbecue your chicken, get the coals burning 1 hr or so before you’re ready to cook. Authentic jerked meats are not exactly grilled as we think of grilling, but sort of smoke-grilled. To get a more authentic jerk experience, add some wood chips to your barbecue, and cook your chicken over slow, indirect heat for 30 mins. To cook in the oven, heat to 180C/160C fan/gas 4. Put the chicken pieces in a roasting tin with the lime halves and cook for 45 mins until tender and cooked through.

While the chicken is cooking, prepare the rice & peas. Rinse the rice in plenty of cold water, then tip it into a large saucepan with all the remaining ingredients except the kidney beans. Season with salt, add 300ml cold water and set over a high heat. Once the rice begins to boil, turn it down to a medium heat, cover and cook for 10 mins.

Add the beans to the rice, then cover with a lid. Leave off the heat for 5 mins until all the liquid is absorbed. Squeeze the roasted lime over the chicken and serve with the rice & peas, and some hot sauce if you like it really spicy.', 1, 1)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (29, N'Paszteciki (Polish Pasties)', 0, N'Polish', N'Sift flour and salt into a large mixing bowl.
Use a spoon to push the egg yolk through a fine sieve into the flour.
Add the raw egg and mix well.
Beat in butter 1 tablespoon at a time.
Place dough on a floured surface and knead until smooth and elastic, then wrap in waxed paper and refrigerate until firm (at least 30 minutes).
In a heavy skillet, melt 2 tablespoons butter over medium heat; saute the onion and rutabaga until the onion is soft and transparent (5 minutes).
Put the onions, rutabaga, and beef through a meat grinder twice if you have one, if not just chop them up as fine as possible.
Melt the remaining 4 tablespoons butter over medium heat, and add the meat mixture.
Cook over low heat, stirring occasionally, until all of the liquid has evaporated and the mixture is thick enough to hold its shape.
Remove from heat and let cool, then stir in 1 egg, and season with salt and pepper.
Preheat oven to 350°F.
On a lightly floured surface, roll the dough out into a 13x8" rectangle (1/8" thick).
Spoon the filling down the center of the rectangle lengthwise, leaving about an inch of space on each end.
Lightly brush the long sides with cold water, then fold one of the long sides over the filling and the other side over the top of that.
Brush the short ends with cold water and fold them over the top, enclosing the filling.
Place pastry seam side down on a baking sheet and brush the top evenly with the remaining scrambled egg.
Bake in preheated oven until rich golden brown (30 minutes).
Slice pastry diagonally into 1.5" long pieces and serve as an appetizer or with soup.', 1, 2)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (30, N'Chakchouka ', 0, N'Tunisian', N'In a large cast iron skillet or sauté pan with a lid, heat oil over medium high heat. Add the onion and sauté for 2-3 minutes, until softened. Add the peppers and garlic, and sauté for an additional 3-5 minutes. Add the tomatoes, cumin, paprika, salt, and chili powder. Mix well and bring the mixture to a simmer. Reduce the heat to medium low and continue to simmer, uncovered, 10-15 minutes until the mixture has thickened to your desired consistency. (Taste the sauce at this point and adjust for salt and spice, as desired.) Using the back of a spoon, make four craters in the mixture, large enough to hold an egg. Crack one egg into each of the craters. Cover the skillet and simmer for 5-7 minutes, until the eggs have set. Serve immediately with crusty bread or pita.', 1, 4)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (31, N'Grilled Mac and Cheese Sandwich', 0, N'American', N'Make the mac and cheese

1. Bring a medium saucepan of generously salted water (you want it to taste like seawater) to a boil. Add the pasta and cook, stirring occasionally, until al dente, 8 to 10 minutes, or according to the package directions. The pasta should be tender but still chewy.
2. While the pasta is cooking, in a small bowl, whisk together the flour, mustard powder, garlic powder, salt, black pepper, and cayenne pepper.
3. Drain the pasta in a colander. Place the empty pasta pan (no need to wash it) over low heat and add the butter. When the butter has melted, whisk in the flour mixture and continue to cook, whisking frequently, until the mixture is beginning to brown and has a pleasant, nutty aroma, about 1 minute. Watch carefully so it does not scorch on the bottom of the pan.
4. Slowly whisk the milk and cream into the flour mixture until everything is really well combined. Cook, whisking constantly, until the sauce is heated through and just begins to thicken, about 2 minutes. Remove from the heat. Gradually add the cheese while stirring constantly with a wooden spoon or silicone spatula and keep stirring until the cheese has melted into the sauce. Then stir in the drained cooked pasta.
5. Line a 9-by-13-inch (23-by-33-centimeter) rimmed baking sheet with parchment paper or aluminum foil. Coat the paper or foil with nonstick cooking spray or slick it with butter. Pour the warm mac and cheese onto the prepared baking sheet and spread it evenly with a spatula. Coat another piece of parchment paper with cooking spray or butter and place it, oiled or buttered side down, directly on the surface of the mac and cheese. Refrigerate until cool and firm, about 1 hour.

Make the grilled cheese
6. Heat a large cast-iron or nonstick skillet over medium-low heat.
7. In a small bowl, stir together the 4 tablespoons (55 grams) butter and garlic powder until well blended.
8. Remove the mac and cheese from the refrigerator and peel off the top layer of parchment paper. Carefully cut into 8 equal pieces. Each piece will make 1 grilled mac and cheese sandwich. (You can stash each individual portion in a double layer of resealable plastic bags and refrigerate for up to 3 days or freeze it for up to 1 month.)
9. Spread 3/4 teaspoon garlic butter on one side of each bread slice. Place half of the slices, buttered-side down, on a clean cutting board. Top each with one slice of Cheddar, then 1 piece of the mac and cheese. (Transfer from the baking sheet by scooting your hand or a spatula under each piece of mac and cheese and then flipping it over onto a sandwich.) Place 1 slice of Jack on top of each. Finish with the remaining bread slices, buttered-side up.
10. Using a wide spatula, place as many sandwiches in the pan as will fit without crowding it. Cover and cook until the bottoms are nicely browned, about 4 minutes. Turn and cook until the second sides are browned, the cheese is melted, and the mac and cheese is heated through, about 4 minutes more.
11. Repeat with the remaining ingredients. Cut the sandwiches in half, if desired, and serve.', 1, 8)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (32, N'Montreal Smoked Meat', 0, N'Canadian', N'To make the cure, in a small bowl mix together salt, pink salt, black pepper, coriander, sugar, bay leaf, and cloves. Coat entire brisket with the cure and place in an extra-large resealable plastic bag. Place in the coldest part of the refrigerator and cure for 4 days, flipping brisket twice a day.
Remove brisket from bag and wash as much cure off as possible under cold running water. Place brisket in a large container and fill with water and let soak for 2 hours, replacing water every 30 minutes. Remove from water and pat dry with paper towels.
To make the rub, mix together black pepper, coriander, paprika, garlic powder, onion powder, dill weed, mustard, celery seed, and crushed red papper in a small bowl. Coat entire brisket with the rub.
Fire up smoker or grill to 225 degrees, adding chunks of smoking wood chunks when at temperature. When wood is ignited and producing smoke, place brisket in, fat side up, and smoke until an instant read thermometer registers 165 degrees when inserted into thickest part of the brisket, about 6 hours.
Transfer brisket to large roasting pan with V-rack. Place roasting pan over two burners on stovetop and fill with 1-inch of water. Bring water to a boil over high heat, reduce heat to medium, cover roasting pan with aluminum foil, and steam brisket until an instant read thermometer registers 180 degrees when inserted into thickest part of the meat, 1 to 2 hours, adding more hot water as needed.
Transfer brisket to cutting board and let cool slightly. Slice and serve, preferably on rye with mustard.', 1, 2)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (33, N'Dal fry', 0, N'Indian', N'Wash and soak toor dal in approx. 3 cups of water, for at least one hours. Dal will be double in volume after soaking. Drain the water.
Cook dal with 2-1/2 cups water and add salt, turmeric, on medium high heat, until soft in texture (approximately 30 mins) it should be like thick soup.
In a frying pan, heat the ghee. Add cumin seeds, and mustard seeds. After the seeds crack, add bay leaves, green chili, ginger and chili powder. Stir for a few seconds.
Add tomatoes, salt and sugar stir and cook until tomatoes are tender and mushy.
Add cilantro and garam masala cook for about one minute.
Pour the seasoning over dal mix it well and cook for another minute.
Serve with Naan.', 1, 9)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (34, N'Moroccan Carrot Soup', 0, N'Moroccan', N'Step 1
Preheat oven to 180° C.
Step 2
Combine carrots, onion, garlic, cumin seeds, coriander seeds, salt and olive oil in a bowl and mix well. Transfer on a baking tray.
Step 3
Put the baking tray in preheated oven and roast for 10-12 minutes or till carrots soften. Remove from heat and cool.
Step 4
Grind the baked carrot mixture along with some water to make a smooth paste and strain in a bowl.
Step 5
Heat the carrot mixture in a non-stick pan. Add two cups of water and bring to a boil. Add garam masala powder and mix. Add salt and mix well.
Step 6
Remove from heat, add lemon juice and mix well.
Step 7
Serve hot.', 1, 9)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (35, N'Vegetarian Chilli', 0, N'British', N'Heat oven to 200C/180C fan/ gas 6. Cook the vegetables in a casserole dish for 15 mins. Tip in the beans and tomatoes, season, and cook for another 10-15 mins until piping hot. Heat the pouch in the microwave on High for 1 min and serve with the chilli.', 1, 9)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (36, N'Red Peas Soup', 0, N'Jamaican', N'Wash and rinse the dried kidney beans.. then cover with water in a deep bowl. Remember as they soak they will expand to at least triple the size they were originally so add a lot of water to the bowl. Soak them overnight or for at least 2 hrs to make the cooking step go quicker. I tossed out the water they were soaked in after it did the job.

Have your butcher cut the salted pigtail into 2 inch pieces as it will be very difficult to cut with an ordinary kitchen knife. Wash, then place a deep pot with water and bring to a boil. Cook for 20 minutes, then drain + rinse and repeat (boil again in water). The goal is to make the pieces of pig tails tender and to remove most of the salt it was cured in.

Time to start the soup. Place everything in the pot (except the flour and potato), then cover with water and place on a high flame to bring to a boil. As it comes to a boil, skim off any scum/froth at the top and discard. Reduce the heat to a gentle boil and allow it to cook for 1 hr and 15 mins.. basically until the beans are tender and start falling apart.

It’s now time to add the potato (and Yams etc if you’re adding it) as well as the coconut milk and continue cooking for 15 minutes.

Now is a good time to start making the basic dough for the spinner dumplings. Mix the flour and water (add a pinch of salt if you want) until you have a soft/smooth dough. allow it to rest for 5 minutes, then pinch of a tablespoon at a time and roll between your hands to form a cigarette shape.

Add them to the pot, stir well and continue cooking for another 15 minutes on a rolling boil.

You’ll notice that I didn’t add any salt to the pot as the remaining salt from the salted pigtails will be enough to properly season this dish. However you can taste and adjust accordingly. Lets recap the timing part of things so you’re not confused. Cook the base of the soup for 1 hr and 15 minute or until tender, then add the potatoes and cook for 15 minutes, then add the dumplings and cook for a further 15 minutes. Keep in mind that this soup will thicken quite a bit as it cools.

While this is not a traditional recipe to any one specific island, versions of this soup (sometimes called stewed peas) can be found throughout the Caribbean, Latin America and Africa. A hearty bowl of this soup will surely give you the sleepies (some may call it ethnic fatigue). You can certainly freeze the leftovers and heat it up another day.', 1, 2)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (37, N'Brown Stew Chicken', 0, N'Jamaican', N'Squeeze lime over chicken and rub well. Drain off excess lime juice.
Combine tomato, scallion, onion, garlic, pepper, thyme, pimento and soy sauce in a large bowl with the chicken pieces. Cover and marinate at least one hour.
Heat oil in a dutch pot or large saucepan. Shake off the seasonings as you remove each piece of chicken from the marinade. Reserve the marinade for sauce.
Lightly brown the chicken a few pieces at a time in very hot oil. Place browned chicken pieces on a plate to rest while you brown the remaining pieces.
Drain off excess oil and return the chicken to the pan. Pour the marinade over the chicken and add the carrots. Stir and cook over medium heat for 10 minutes.
Mix flour and coconut milk and add to stew, stirring constantly. Turn heat down to minimum and cook another 20 minutes or until tender.', 1, 1)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (38, N'Tahini Lentils', 0, N'Moroccan', N'In a jug, mix the tahini with the zest and juice of the lemon and 50ml of cold water to make a runny dressing. Season to taste, then set aside.
Heat the oil in a wok or large frying pan over a medium-high heat. Add the red onion, along with a pinch of salt, and fry for 2 mins until starting to soften and colour. Add the garlic, pepper, green beans and courgette and fry for 5 min, stirring frequently.
Tip in the kale, lentils and the tahini dressing. Keep the pan on the heat for a couple of mins, stirring everything together until the kale is wilted and it’s all coated in the creamy dressing.', 1, 9)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (39, N'Oxtail with broad beans', 0, N'Jamaican', N'Toss the oxtail with the onion, spring onion, garlic, ginger, chilli, soy sauce, thyme, salt and pepper. Heat the vegetable oil in a large frying pan over medium-high heat. Brown the oxtail in the pan until browned all over, about 10 minutes. Place into a pressure cooker, and pour in 375ml water. Cook at pressure for 25 minutes, then remove from heat, and remove the lid according to manufacturer''s directions.
Add the broad beans and pimento berries, and bring to a simmer over medium-high heat. Dissolve the cornflour in 2 tablespoons water, and stir into the simmering oxtail. Cook and stir a few minutes until the sauce has thickened, and the broad beans are tender.', 1, 2)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (40, N'Mee goreng mamak', 0, N'Malaysian', N'Heat oil in a pan at medium heat. Then, add peanuts, dried chilies, dried shrimps and dhal. Fry the aromatics until fragrant. Remove from pan and leave aside.

Blend fried ingredients with tamarind paste and water until fine. Then, sauté the blended ingredients in oil heated over low heat. Continue cooking until the oil separates from the paste and turns a darker shade.

Skin and cut potatoes into small chunks and boil them in a pot of water until knife-tender. Once ready, remove them from the pot and leave aside. Discard water.

Slice onion and fried tofu, mince garlic, cut some cabbage and Chinese flowering cabbage (choi sam). Prepare prawn fritters and cut them. Boil noodles to soften them if bought dried. Also mix black soy sauce with water.

To fry one portion of mee goreng mamak, heat oil and add 1/4 of the following ingredients in this order: garlic, onion, paste. Sauté until fragrant. Optionally, add prawns.

Add in 1/4 amount of tofu, boiled potatoes, cabbage, Chinese flowering cabbage and prawn fritters. Sauté for another 30 seconds.

Add noodles to the wok. Add 3 tablespoons of dark soy sauce mixture. Mix evenly for the next 1 minute. Then, move the noodles to the side of the wok. Stir in an egg. Garnish with a slice of lime and slices of green chilies. To cook another plate of noodles, repeat from step 5 onwards.', 1, 7)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (41, N'French Omelette', 0, N'French', N'Get everything ready. Warm a 20cm (measured across the top) non-stick frying pan on a medium heat. Crack the eggs into a bowl and beat them with a fork so they break up and mix, but not as completely as you would for scrambled egg. With the heat on medium-hot, drop one knob of butter into the pan. It should bubble and sizzle, but not brown. Season the eggs with the Parmesan and a little salt and pepper, and pour into the pan.
Let the eggs bubble slightly for a couple of seconds, then take a wooden fork or spatula and gently draw the mixture in from the sides of the pan a few times, so it gathers in folds in the centre. Leave for a few seconds, then stir again to lightly combine uncooked egg with cooked. Leave briefly again, and when partly cooked, stir a bit faster, stopping while there’s some barely cooked egg left. With the pan flat on the heat, shake it back and forth a few times to settle the mixture. It should slide easily in the pan and look soft and moist on top. A quick burst of heat will brown the underside.
Grip the handle underneath. Tilt the pan down away from you and let the omelette fall to the edge. Fold the side nearest to you over by a third with your fork, and keep it rolling over, so the omelette tips onto a plate – or fold it in half, if that’s easier. For a neat finish, cover the omelette with a piece of kitchen paper and plump it up a bit with your fingers. Rub the other knob of butter over to glaze. Serve immediately.', 1, 4)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (42, N'Skillet Apple Pork Chops with Roasted Sweet Potatoes & Zucchini', 0, N'American', N'
Serves 2


1. 

Adjust racks to top and middle positions and preheat oven to 450 degrees. Wash and dry all produce. Dice sweet potatoes into 1/2-inch pieces. Toss on a baking sheet with a drizzle of oil, salt, and pepper. Roast on top rack for 12 minutes (we''ll roast the zucchini then). 


2. 

Meanwhile, halve and core apple; thinly slice into half-moons. Peel and finely chop garlic. Quarter lemon. Trim and halve zucchini lengthwise; cut crosswise into 1/2-inch-thick half-moons. Toss on a second baking sheet with a drizzle of oil and a pinch of salt and pepper. Set aside. 


3. 

Pat pork dry with paper towels and season all over with salt and pepper. Heat a drizzle of oil in a large pan over medium-high heat. Add pork and cook until browned and cooked through, 4-5 minutes per side. Turn off heat; transfer to a plate. 


4. 

Once sweet potatoes have roasted 12 minutes, transfer baking sheet with zucchini to middle rack and continue roasting until both veggies are browned and softened, 12-15 minutes more. 


5. 

Meanwhile, melt 1 TBSP butter (2 TBSP for 4 servings) in pan used for pork over medium-high heat. Add apple and season with salt and pepper. Cook, scraping up any browned bits from bottom of pan, until apple is slightly softened, 2-3 minutes. Add garlic; cook until fragrant, 30 seconds. Add 1/z cup water (3/4 cup for 4), stock concentrate, and 11/2 tsp sugar (3 tsp for 4). Cook, stirring, until sauce has thickened and apple is very tender, 3-5 minutes. Season with salt and pepper. 


6. 

Remove pan with apple from heat; stir in 1 TBSP butter (2 TBSP for 4 servings) and a squeeze of lemon juice. Divide pork, zucchini, and sweet potatoes between plates. Top pork with glazed apple sauce. Top zucchini with a squeeze of lemon juice. ', 1, 6)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (43, N'Beef Rendang', 0, N'Malaysian', N'Chop the spice paste ingredients and then blend it in a food processor until fine.
Heat the oil in a stew pot, add the spice paste, cinnamon, cloves, star anise, and cardamom and stir-fry until aromatic. Add the beef and the pounded lemongrass and stir for 1 minute. Add the coconut milk, tamarind juice, water, and simmer on medium heat, stirring frequently until the meat is almost cooked. Add the kaffir lime leaves, kerisik (toasted coconut), sugar or palm sugar, stirring to blend well with the meat.
Lower the heat to low, cover the lid, and simmer for 1 to 1 1/2 hours or until the meat is really tender and the gravy has dried up. Add more salt and sugar to taste. Serve immediately with steamed rice and save some for overnight.', 1, 2)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (44, N'Cevapi Sausages', 0, N'Croatian', N'Place the ground meat in a bowl. Chop the onion very finely and grate the garlic cloves. Add to the bowl. Add the chopped parsley, all sorts of paprika, baking soda, dried breadcrumbs, water, Vegeta, salt, and pepper.
Mix well with the hand mixer fitted with the dough hooks. Cover the bowl with cling film/ plastic foil and leave to rest for 1 or 2 hours in the refrigerator.
Take portions of the meat mixture, about 50-55 g/ 1.7-1.9 oz/ ¼ cup portions, and form the cevapi. The rolls should be about as thick as your thumb and about 7-10 cm/ 3-4 inches long. I had 18 sausages. The recipe can be easily doubled.
Grill the cevapcici on the hot grill pan or on the barbecue for about 12-14 minutes, turning them several times in between, or until brown and cooked through. I checked by cutting one in the middle and then grilling the following batches for the same period of time.
Serve hot as suggested above. The cevapcici can be reheated in the oven at 180 degrees Celsius/ 350 degrees Fahrenheit for about 10 minutes or until heated through. Check one, if it is not hot enough, give the sausages a few more minutes.', 1, 2)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (45, N'Rosół (Polish Chicken Soup)', 0, N'Polish', N'Add chicken to a large Dutch oven or stock pot 
Cover with water
Bring to a boil and simmer for 2 to 2 1/2 hours, skimming any impurities off the top to insure a clear broth
If your pot is big enough, add the vegetables and spices for the last hour of the cooking time
My Dutch oven wasn’t big enough to hold everything, just the chicken and other bones filled the pot, so I cooked the meat/bones for the full cooking time, then removed them, and cooked the vegetables and spices separately
Strain everything out of the broth
Bone the chicken, pulling the meat into large chunks
Slice the carrots
Return the chicken and carrots to the broth
Cook noodles according to package instructions if you’re using them
Add noodles to bowl and then top with hot soup', 1, 1)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (46, N'Bean & Sausage Hotpot', 0, N'British', N'In a large casserole, fry the sausages until brown all over – about 10 mins.

Add the tomato sauce, stirring well, then stir in the beans, treacle or sugar and mustard. Bring to the simmer, cover and cook for 30 mins. Great served with crusty bread or rice.', 1, 4)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (47, N'Creamy Tomato Soup', 0, N'British', N'Put the oil, onions, celery, carrots, potatoes and bay leaves in a big casserole dish, or two saucepans. Fry gently until the onions are softened – about 10-15 mins. Fill the kettle and boil it.
Stir in the tomato purée, sugar, vinegar, chopped tomatoes and passata, then crumble in the stock cubes. Add 1 litre boiling water and bring to a simmer. Cover and simmer for 15 mins until the potato is tender, then remove the bay leaves. Purée with a stick blender (or ladle into a blender in batches) until very smooth. Season to taste and add a pinch more sugar if it needs it. The soup can now be cooled and chilled for up to 2 days, or frozen for up to 3 months.
To serve, reheat the soup, stirring in the milk – try not to let it boil. Serve in small bowls with cheesy sausage rolls.', 1, 10)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (48, N'Mulukhiyah', 0, N'Egyptian', N'Saute the onions in the 3-4 tablespoons olive oil
Add the beef cubes or the chicken cutlets, sear for 3-4 min on each side
Add 1 liter of water or just enough to cover the meat
Cook over medium heat until the meat is done (I usually do this in the pressure cooker and press them for 5 min)

Add the frozen mulukhyia and stir until it thaws completely and then comes to a boil

In another pan add the 1/4 to 1/2 cup of olive oil and the cloves of garlic and cook over medium low heat until you can smell the garlic (don’t brown it, it will become bitter)

Add the oil and garlic to the mulukhyia and lower the heat and simmer for 5-10 minutes
Add salt to taste

Serve with a generous amount of lemon juice.

You can serve it with some short grain rice or some pita bread', 1, 2)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (49, N'Yaki Udon', 0, N'Japanese', N'Boil some water in a large saucepan. Add 250ml cold water and the udon noodles. (As they are so thick, adding cold water helps them to cook a little bit slower so the middle cooks through). If using frozen or fresh noodles, cook for 2 mins or until al dente; dried will take longer, about 5-6 mins. Drain and leave in the colander.
Heat 1 tbsp of the oil, add the onion and cabbage and sauté for 5 mins until softened. Add the mushrooms and some spring onions, and sauté for 1 more min. Pour in the remaining sesame oil and the noodles. If using cold noodles, let them heat through before adding the ingredients for the sauce – otherwise tip in straight away and keep stir-frying until sticky and piping hot. Sprinkle with the remaining spring onions.', 1, 9)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (50, N'Toad In The Hole', 0, N'British', N'Preheat the oven to 200°C/fan180°C/gas 6. fry sausages in a non-stick pan until browned.
Drizzle vegetable oil in a 30cm x 25cm x 6cm deep roasting tray and heat in the oven for 5 minutes.
Put the plain flour in a bowl, crack in the medium free-range eggs, then stir in the grated horseradish. Gradually beat in the semi-skimmed milk. Season.
Put the sausages into the hot roasting tray and pour over the batter. Top with cherry tomatoes on the vine and cook for 30 minutes until puffed and golden.', 1, 6)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (51, N'Nasi lemak', 0, N'Malaysian', N'In a medium saucepan over medium heat, stir together coconut milk, water, ground ginger, ginger root, salt, bay leaf, and rice. Cover, and bring to a boil. Reduce heat, and simmer for 20 to 30 minutes, or until done.

 Step 2
Place eggs in a saucepan, and cover with cold water. Bring water to a boil, and immediately remove from heat. Cover, and let eggs stand in hot water for 10 to 12 minutes. Remove eggs from hot water, cool, peel and slice in half. Slice cucumber.

 Step 3
Meanwhile, in a large skillet or wok, heat 1 cup vegetable oil over medium-high heat. Stir in peanuts and cook briefly, until lightly browned. Remove peanuts with a slotted spoon and place on paper towels to soak up excess grease. Return skillet to stove. Stir in the contents of one package anchovies; cook briefly, turning, until crisp. Remove with a slotted spoon and place on paper towels. Discard oil. Wipe out skillet.

 Step 4
Heat 2 tablespoons oil in the skillet. Stir in the onion, garlic, and shallots; cook until fragrant, about 1 or 2 minutes. Mix in the chile paste, and cook for 10 minutes, stirring occasionally. If the chile paste is too dry, add a small amount of water. Stir in remaining anchovies; cook for 5 minutes. Stir in salt, sugar, and tamarind juice; simmer until sauce is thick, about 5 minutes.

 Step 5
Serve the onion and garlic sauce over the warm rice, and top with peanuts, fried anchovies, cucumbers, and eggs.', 1, 7)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (52, N'Lancashire hotpot', 0, N'British', N'Heat oven to 160C/fan 140C/gas 3. Heat some dripping or butter in a large shallow casserole dish, brown the lamb in batches, lift to a plate, then repeat with the kidneys.
Fry the onions and carrots in the pan with a little more dripping until golden. Sprinkle over the flour, allow to cook for a couple of mins, shake over the Worcestershire sauce, pour in the stock, then bring to the boil. Stir in the meat and bay leaves, then turn off the heat. Arrange the sliced potatoes on top of the meat, then drizzle with a little more dripping. Cover, then place in the oven for about 1½ hrs until the potatoes are cooked.
Remove the lid, brush the potatoes with a little more dripping, then turn the oven up to brown the potatoes, or finish under the grill for 5-8 mins until brown.', 1, 11)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (53, N'Keleya Zaara', 0, N'Tunisian', N'Heat the vegetable oil in a large frying pan over medium-high heat. Add the lamb and cook until browned on all sides, about 5 minutes. Season with saffron, salt and pepper to taste; stir in all but 4 tablespoons of the onion, and pour in the water. Bring to the boil, then cover, reduce heat to medium-low, and simmer until the lamb is tender, about 15 minutes.
Uncover the pan, stir in the butter and allow the sauce reduce 5 to 10 minutes to desired consistency. Season to taste with salt and pepper, then pour into a serving dish. Sprinkle with the remaining chopped onions and parsley. Garnish with lemon wedges to serve.
', 1, 11)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (54, N'Broccoli & Stilton soup', 0, N'British', N'Heat the rapeseed oil in a large saucepan and then add the onions. Cook on a medium heat until soft. Add a splash of water if the onions start to catch.

Add the celery, leek, potato and a knob of butter. Stir until melted, then cover with a lid. Allow to sweat for 5 minutes. Remove the lid.

Pour in the stock and add any chunky bits of broccoli stalk. Cook for 10 – 15 minutes until all the vegetables are soft.

Add the rest of the broccoli and cook for a further 5 minutes. Carefully transfer to a blender and blitz until smooth. Stir in the stilton, allowing a few lumps to remain. Season with black pepper and serve.', 1, 10)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (55, N'Feteer Meshaltet', 0, N'Egyptian', N'Mix the flour and salt then pour one cup of water and start kneading.
If you feel the dough is still not coming together or too dry, gradually add the remaining water until you get a dough that is very elastic so that when you pull it and it won’t be torn.
Let the dough rest for just 10 minutes then divide the dough into 6-8 balls depending on the size you want for your feteer.
Warm up the butter/ghee or oil you are using and pour into a deep bowl.
Immerse the dough balls into the warm butter. Let it rest for 15 to 20 minutes.
Preheat oven to 550F.
Stretch the first ball with your hands on a clean countertop. Stretch it as thin as you can, the goal here is to see your countertop through the dough.
Fold the dough over itself to form a square brushing in between folds with the butter mixture.
Set aside and start making the next ball.
Stretch the second one thin as we have done for the first ball.
Place the previous one on the middle seam side down. Fold the outer one over brushing with more butter mixture as you fold. Set aside.
Keep doing this for the third and fourth balls. Now we have one ready, place on a 10 inch baking/pie dish seam side down and brush the top with more butter.
Repeat for the remaining 4 balls to make a second one. With your hands lightly press the folded feteer to spread it on the baking dish.
Place in preheated oven for 10 minutes when the feteer starts puffing turn on the broiler to brown the top.
When it is done add little butter on top and cover so it won’t get dry.', 1, 5)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (56, N'Traditional Croatian Goulash', 0, N'Croatian', N'Clean the meat from the veins if there are some and cut it into smaller pieces, 3 × 3 cm. Marinate the meat in the mustard and spices and let it sit in the refrigerator for one hour
Heat one tablespoon of pork fat or vegetable oil in a pot and fry the meat on all sides until it gets browned. Once the meat is cooked, transfer it to a plate and add another tablespoon of fat to the pot
Cut the onions very fine, peel the carrots and shred it using a grater. Cook the onions and carrots over low heat for 15 minutes. You can salt the vegetables a little to make them soften faster
Once the vegetables have browned and become slightly mushy, add the meat and bay leaves and garlic. Pour over with wine and simmer for 10-15 minutes to allow the alcohol to evaporate. Now is the right time to add 2/3 the amount of liquid
Cover the pot and cook over low heat for an hour, stirring occasionally. After the first hour, pour over the rest of the water or stock and cook for another 30-45 minutes
Allow the stew to cool slightly and serve it with a sprinkle of chopped parsley and few slices of fresh hot pepper if you like to spice it up a bit
Slice ​​some fresh bread, season the salad and simply enjoying these wonderful flavors', 1, 2)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (57, N'French Onion Soup', 0, N'French', N'Melt the butter with the oil in a large heavy-based pan. Add the onions and fry with the lid on for 10 mins until soft. Sprinkle in the sugar and cook for 20 mins more, stirring frequently, until caramelised. The onions should be really golden, full of flavour and soft when pinched between your fingers. Take care towards the end to ensure that they don’t burn.
Add the garlic for the final few mins of the onions’ cooking time, then sprinkle in the flour and stir well. Increase the heat and keep stirring as you gradually add the wine, followed by the hot stock. Cover and simmer for 15-20 mins.
To serve, turn on the grill, and toast the bread. Ladle the soup into heatproof bowls. Put a slice or two of toast on top of the bowls of soup, and pile on the cheese. Grill until melted. Alternatively, you can complete the toasts under the grill, then serve them on top.', 1, 5)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (58, N'Boxty Breakfast', 0, N'Irish', N'STEP 1
Before you start, put your oven on its lowest setting, ready to keep things warm. Peel the potatoes, grate 2 of them, then set aside. Cut the other 2 into large chunks, then boil for 10-15 mins or until tender. Meanwhile, squeeze as much of the liquid from the grated potatoes as you can using a clean tea towel. Mash the boiled potatoes, then mix with the grated potato, spring onions and flour.

STEP 2
Whisk the egg white in a large bowl until it holds soft peaks. Fold in the buttermilk, then add the bicarbonate of soda. Fold into the potato mix.

STEP 3
Heat a large non-stick frying pan over a medium heat, then add 1 tbsp butter and some of the oil. Drop 3-4 spoonfuls of the potato mixture into the pan, then gently cook for 3-5 mins on each side until golden and crusty. Keep warm on a plate in the oven while you cook the next batch, adding more butter and oil to the pan before you do so. You will get 16 crumpet-size boxty from the mix. Can be made the day ahead, drained on kitchen paper, then reheated in a low oven for 20 mins.

STEP 4
Heat the grill to medium and put the tomatoes in a heavy-based pan. Add a good knob of butter and a little oil, then fry for about 5 mins until softened. Grill the bacon, then pile onto a plate and keep warm. Stack up the boxty, bacon and egg, and serve the tomatoes on the side.', 1, 6)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (59, N'Irish stew', 0, N'Irish', N'Heat the oven to 180C/350F/gas mark 4. Drain and rinse the soaked wheat, put it in a medium pan with lots of water, bring to a boil and simmer for an hour, until cooked. Drain and set aside.

Season the lamb with a teaspoon of salt and some black pepper. Put one tablespoon of oil in a large, deep sauté pan for which you have a lid; place on a medium-high heat. Add some of the lamb – don''t overcrowd the pan – and sear for four minutes on all sides. Transfer to a bowl, and repeat with the remaining lamb, adding oil as needed.

Lower the heat to medium and add a tablespoon of oil to the pan. Add the shallots and fry for four minutes, until caramelised. Tip these into the lamb bowl, and repeat with the remaining vegetables until they are all nice and brown, adding more oil as you need it.

Once all the vegetables are seared and removed from the pan, add the wine along with the sugar, herbs, a teaspoon of salt and a good grind of black pepper. Boil on a high heat for about three minutes.

Tip the lamb, vegetables and whole wheat back into the pot, and add the stock. Cover and boil for five minutes, then transfer to the oven for an hour and a half.

Remove the stew from the oven and check the liquid; if there is a lot, remove the lid and boil for a few minutes.', 1, 6)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (60, N'Sledz w Oleju (Polish Herrings)', 0, N'Polish', N'Soak herring in cold water for at least 1 hour. If very salty, repeat, changing the water each time.

Drain thoroughly and slice herring into bite-size pieces.

Place in a jar large enough to accommodate the pieces and cover with oil, allspice, peppercorns, and bay leaf. Close the jar.

Refrigerate for 2 to 3 days before eating. This will keep refrigerated up to 2 weeks.

Serve with finely chopped onion or onion slices, lemon, and parsley or dill.', 1, 7)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (61, N'Chicken Parmentier', 0, N'French', N'For the topping, boil the potatoes in salted water until tender. Drain and push through a potato ricer, or mash thoroughly. Stir in the butter, cream and egg yolks. Season and set aside.
For the filling, melt the butter in a large pan. Add the shallots, carrots and celery and gently fry until soft, then add the garlic. Pour in the wine and cook for 1 minute. Stir in the tomato purée, chopped tomatoes and stock and cook for 10–15 minutes, until thickened. Add the shredded chicken, olives and parsley. Season to taste with salt and pepper.
Preheat the oven to 180C/160C Fan/Gas 4.
Put the filling in a 20x30cm/8x12in ovenproof dish and top with the mashed potato. Grate over the Gruyère. Bake for 30–35 minutes, until piping hot and the potato is golden-brown.', 1, 1)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (62, N'Pad See Ew', 0, N'Thai', N'Mix Sauce in small bowl.
Mince garlic into wok with oil. Place over high heat, when hot, add chicken and Chinese broccoli stems, cook until chicken is light golden.
Push to the side of the wok, crack egg in and scramble. Don''t worry if it sticks to the bottom of the wok - it will char and which adds authentic flavour.
Add noodles, Chinese broccoli leaves and sauce. Gently mix together until the noodles are stained dark and leaves are wilted. Serve immediately!', 1, 1)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (63, N'Chivito uruguayo', 0, N'Unknown', N'Crush the meat so that it is finite and we put it on a griddle to brown. Put the eggs, bacon and ham to fry.
Cut the bread in half, put the beef brisket, the fried eggs, the bacon, the ham, the mozzarella, the tomato and the lettuce. Cover with the other half of the bread and serve.', 1, 2)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (64, N'General Tso''s Chicken', 0, N'Chinese', N'DIRECTIONS:
STEP 1 - SAUCE
In a bowl, add 2 Cups of water, 2 Tablespoon soy sauce, 2 Tablespoon white vinegar, sherry cooking wine, 1/4 Teaspoon white pepper, minced ginger, minced garlic, hot pepper, ketchup, hoisin sauce, and sugar.
Mix together well and set aside.
STEP 2 - MARINATING THE CHICKEN
In a bowl, add the chicken, 1 pinch of salt, 1 pinch of white pepper, 2 egg whites, and 3 Tablespoon of corn starch
STEP 3 - DEEP FRY THE CHICKEN
Deep fry the chicken at 350 degrees for 3-4 minutes or until it is golden brown and loosen up the chicken so that they don''t stick together.
Set the chicken aside.
STEP 4 - STIR FRY
Add the sauce to the wok and then the broccoli and wait until it is boiling.
To thicken the sauce, whisk together 2 Tablespoon of cornstarch and 4 Tablespoon of water in a bowl and slowly add to your stir-fry until it''s the right thickness.
Next add in the chicken and stir-fry for a minute and serve on a plate', 1, 1)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (65, N'Cajun spiced fish tacos', 0, N'Mexican', N'Cooking in a cajun spice and cayenne pepper marinade makes this fish super succulent and flavoursome. Top with a zesty dressing and serve in a tortilla for a quick, fuss-free main that''s delightfully summery.

On a large plate, mix the cajun spice and cayenne pepper with a little seasoning and use to coat the fish all over.

Heat a little oil in a frying pan, add in the fish and cook over a medium heat until golden. Reduce the heat and continue frying until the fish is cooked through, about 10 minutes. Cook in batches if you don’t have enough room in the pan.

Meanwhile, prepare the dressing by combining all the ingredients with a little seasoning.
Soften the tortillas by heating in the microwave for 5-10 seconds. Pile high with the avocado, lettuce and spring onion, add a spoonful of salsa, top with large flakes of fish and drizzle over the dressing.', 1, 7)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (66, N'Boulangère Potatoes', 0, N'French', N'Heat oven to 200C/fan 180C/gas 6. Fry the onions and thyme sprigs in the oil until softened and lightly coloured (about 5 mins).
Spread a layer of potatoes over the base of a 1.5-litre oiled gratin dish. Sprinkle over a few onions (see picture, above) and continue layering, finishing with a layer of potatoes. Pour over the stock and bake for 50-60 mins until the potatoes are cooked and the top is golden and crisp.', 1, 5)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (67, N'Chicken Fajita Mac and Cheese', 0, N'American', N'Fry your onion, peppers and garlic in olive oil until nicely translucent. Make a well in your veg and add your chicken. Add your seasoning and salt. Allow to colour slightly.
Add your cream, stock and macaroni.
Cook on low for 20 minutes. Add your cheeses, stir to combine.
Top with roasted peppers and parsley.', 1, 1)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (68, N'Beef and Mustard Pie', 0, N'British', N'Preheat the oven to 150C/300F/Gas 2.
Toss the beef and flour together in a bowl with some salt and black pepper.
Heat a large casserole until hot, add half of the rapeseed oil and enough of the beef to just cover the bottom of the casserole.
Fry until browned on each side, then remove and set aside. Repeat with the remaining oil and beef.
Return the beef to the pan, add the wine and cook until the volume of liquid has reduced by half, then add the stock, onion, carrots, thyme and mustard, and season well with salt and pepper.
Cover with a lid and place in the oven for two hours.
Remove from the oven, check the seasoning and set aside to cool. Remove the thyme.
When the beef is cool and you''re ready to assemble the pie, preheat the oven to 200C/400F/Gas 6.
Transfer the beef to a pie dish, brush the rim with the beaten egg yolks and lay the pastry over the top. Brush the top of the pastry with more beaten egg.
Trim the pastry so there is just enough excess to crimp the edges, then place in the oven and bake for 30 minutes, or until the pastry is golden-brown and cooked through.
For the green beans, bring a saucepan of salted water to the boil, add the beans and cook for 4-5 minutes, or until just tender.
Drain and toss with the butter, then season with black pepper.
To serve, place a large spoonful of pie onto each plate with some green beans alongside.', 1, 2)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (69, N'Garides Saganaki', 0, N'Greek', N'Place the prawns in a pot and add enough water to cover. Boil for 5 minutes. Drain, reserving the liquid, and set aside.
Heat 2 tablespoons of oil in a saucepan. Add the onion; cook and stir until soft. Mix in the parsley, wine, tomatoes, garlic and remaining olive oil. Simmer, stirring occasionally, for about 30 minutes, or until the sauce is thickened.
While the sauce is simmering, the prawns should become cool enough to handle. First remove the legs by pinching them, and then pull off the shells, leaving the head and tail on.
When the sauce has thickened, stir in the prawns. Bring to a simmer again if the sauce has cooled with the prawns, and cook for about 5 minutes. Add the feta and remove from the heat. Let stand until the cheese starts to melt. Serve warm with slices of crusty bread.
Though completely untraditional, you can add a few tablespoons of stock or passata to this recipe to make a delicious pasta sauce. Toss with pasta after adding the feta, and serve.', 1, 7)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (70, N'Chicken Basquaise', 0, N'French', N'Preheat the oven to 180°C/Gas mark 4. Have the chicken joints ready to cook. Heat the butter and 3 tbsp olive oil in a flameproof casserole or large frying pan. Brown the chicken pieces in batches on both sides, seasoning them with salt and pepper as you go. Don''t crowd the pan - fry the chicken in small batches, removing the pieces to kitchen paper as they are done.

Add a little more olive oil to the casserole and fry the onions over a medium heat for 10 minutes, stirring frequently, until softened but not browned. Add the rest of the oil, then the peppers and cook for another 5 minutes.

Add the chorizo, sun-dried tomatoes and garlic and cook for 2-3 minutes. Add the rice, stirring to ensure it is well coated in the oil. Stir in the tomato paste, paprika, bay leaves and chopped thyme. Pour in the stock and wine. When the liquid starts to bubble, turn the heat down to a gentle simmer. Press the rice down into the liquid if it isn''t already submerged and place the chicken on top. Add the lemon wedges and olives around the chicken.

Cover and cook in the oven for 50 minutes. The rice should be cooked but still have some bite, and the chicken should have juices that run clear when pierced in the thickest part with a knife. If not, cook for another 5 minutes and check again.', 1, 1)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (71, N'Osso Buco alla Milanese', 0, N'Italian', N'Heat the oven to 300 degrees.
Dredging the shanks: pour the flour into a shallow dish (a pie plate works nicely). Season the veal shanks on all sides with salt and pepper. One at a time, roll the shanks around in the flour coat, and shake and pat the shank to remove any excuses flour. Discard the remaining flour.
Browning the shanks: put the oil and 1 tablespoon of the butter in a wide Dutch oven or heavy braising pot (6 to 7 quart) and heat over medium-high heat. When the butter has melted and the oil is shimmering, lower the shanks into the pot, flat side down; if the shanks won’t fit without touching one another, do this in batches. Brown the shanks, turning once with tongs, until both flat sides are well caramelized, about 5 minutes per side. If the butter-oil mixture starts to burn, lower the heat just a bit. Transfer the shanks to a large platter or tray and set aside.
The aromatics: pour off and discard the fat from the pot. Wipe out any burnt bits with a damp paper towel, being careful not to remove any delicious little caramelized bits. Ad the remaining 2 tablespoons butter to the pot and melt it over medium heat. When the butter has stopped foaming, add the onion, carrot, celery, and fennel. Season with salt and pepper, stir, and cook the vegetables until they begin to soften but do not brown, about 6 minutes. Stir in the garlic, orange zest, marjoram, and bay leaf, and stew for another minute or two.
The braising liquid: add the wine, increase the heat to high, and bring to a boil. Boil, stirring occasionally, to reduce the wine by about half, 5 minutes. Add the stock and tomatoes, with their juice, and boil again to reduce the liquid to about 1 cup total, about 10 minutes.
The braise: Place the shanks in the pot so that they are sitting with the exposed bone facing up, and pour over any juices that accumulated as they sat. Cover with parchment paper, pressing down so the parchment nearly touches the veal and the edges hang over the sides of the pot by about an inch. Cover tightly with the lid, and slide into the lower part of the oven to braise at a gentle simmer. Check the pot after the first 15 minutes, and if the liquid is simmering too aggressively, lower the oven heat by 10 or 15 degrees. Continue braising, turning the shanks and spooning some pan juices over the top after the first 40 minutes, until the meat is completely tender and pulling away from the bone, about 2 hours.
The gremolata: While the shanks are braising, stir together the garlic, parsley, and lemon zest in a small bowl. Cover with plastic wrap and set aside in a cool place (or the refrigerator, if your kitchen is very warm.)
The finish: When the veal is fork-tender and falling away from the bone, remove the lid and sprinkle over half of the gremolata. Return the veal to the oven, uncovered, for another 15 minutes to caramelize it some.
Using a slotted spatula or spoon, carefully lift the shanks from the braising liquid, doing your best to keep them intact. The shanks will be very tender and threatening to fall into pieces, and the marrow will be wobbly inside the bones, so this can be a bit tricky. But if they do break apart, don’t worry, the flavor won’t suffer at all. Arrange the shanks on a serving platter or other large plate, without stacking, and cover with foil to keep warm.
Finishing the sauce: Set the braising pot on top of the stove and evaluate the sauce: if there is a visible layer of fat floating on the surface, use a large spoon to skim it off and discard it. Taste the sauce for concentration of flavor. If it tastes a bit weak or flat, bring it to a boil over high heat, and boil to reduce the volume and intensify the flavor for 5 to 10 minutes. Taste again for salt and pepper. If the sauce wants more zip, stir in a teaspoon or two of the remaining gremolata.
Portioning the veal shanks: if the shanks are reasonably sized, serve one per person. If the shanks are gargantuan or you’re dealing with modest appetites, pull apart the larger shanks, separating them at their natural seams, and serve smaller amounts. Be sure to give the marrow bones to whomever prizes them most.
Serving: Arrange the veal shanks on warm dinner plates accompanied by the risotto, if serving. Just before carrying the plates to the table, sprinkle on the remaining gremolata and then spoon over a generous amount of sauce – the contact with the hot liquid will aromatize the gremolata and perk up everyone’s appetite with the whiff of garlic and lemon.', 1, 4)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (72, N'Mbuzi Choma (Roasted Goat)', 0, N'Kenyan', N'1. Steps for the Meat: 
 Roast meat over medium heat for 50 minutes and salt it as you turn it.

2. Steps for Ugali:
Bring the water and salt to a boil in a heavy-bottomed saucepan. Stir in the cornmeal slowly, letting it fall through the fingers of your hand.

3. Reduce heat to medium-low and continue stirring regularly, smashing any lumps with a spoon, until the mush pulls away from the sides of the pot and becomes very thick, about 10 minutes.

4.Remove from heat and allow to cool.

5. Place the ugali into a large serving bowl. Wet your hands with water, form a ball and serve.

6. Steps for Kachumbari: Mix the tomatoes, onions, chili and coriander leaves in a bowl.

7. Serve and enjoy!

', 1, 12)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (73, N'Stovetop Eggplant With Harissa, Chickpeas, and Cumin Yogurt', 0, N'American', N'Heat the oil in a 12-inch skillet over high heat until shimmering. Add the eggplants and lower the heat to medium. Season with salt and pepper as you rotate the eggplants, browning them on all sides. Continue to cook, turning regularly, until a fork inserted into the eggplant meets no resistance (you may have to stand them up on their fat end to finish cooking the thickest parts), about 20 minutes, lowering the heat and sprinkling water into the pan as necessary if the eggplants threaten to burn or smoke excessively.

2.
Mix the harissa, chickpeas and tomatoes together, then add to the eggplants. Cook until the tomatoes have blistered and broken down, about 5 minutes more. Season with salt and pepper and add water as necessary to thin to a saucy consistency. Meanwhile, combine the yogurt and cumin in a serving bowl. Season with salt and pepper.

3.
Top the eggplant mixture with the parsley, drizzle with more extra virgin olive oil, and serve with the yogurt on the side.', 1, 9)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (74, N'Ratatouille', 0, N'French', N'Cut the aubergines in half lengthways. Place them on the board, cut side down, slice in half lengthways again and then across into 1.5cm chunks. Cut off the courgettes ends, then across into 1.5cm slices. Peel the peppers from stalk to bottom. Hold upright, cut around the stalk, then cut into 3 pieces. Cut away any membrane, then chop into bite-size chunks.
Score a small cross on the base of each tomato, then put them into a heatproof bowl. Pour boiling water over the tomatoes, leave for 20 secs, then remove. Pour the water away, replace the tomatoes and cover with cold water. Leave to cool, then peel the skin away. Quarter the tomatoes, scrape away the seeds with a spoon, then roughly chop the flesh.
Set a sauté pan over medium heat and when hot, pour in 2 tbsp olive oil. Brown the aubergines for 5 mins on each side until the pieces are soft. Set them aside and fry the courgettes in another tbsp oil for 5 mins, until golden on both sides. Repeat with the peppers. Don’t overcook the vegetables at this stage, as they have some more cooking left in the next step.
Tear up the basil leaves and set aside. Cook the onion in the pan for 5 mins. Add the garlic and fry for a further min. Stir in the vinegar and sugar, then tip in the tomatoes and half the basil. Return the vegetables to the pan with some salt and pepper and cook for 5 mins. Serve with basil.', 1, 9)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (75, N'Kung Po Prawns', 0, N'Chinese', N'Mix the cornflour and 1 tbsp soy sauce, toss in the prawns and set aside for 10 mins. Stir the vinegar, remaining soy sauce, tomato purée, sugar and 2 tbsp water together to make a sauce.

When you’re ready to cook, heat a large frying pan or wok until very hot, then add 1 tbsp oil. Fry the prawns until they are golden in places and have opened out– then tip them out of the pan.

Heat the remaining oil and add the peanuts, chillies and water chestnuts. Stir-fry for 2 mins or until the peanuts start to colour, then add the ginger and garlic and fry for 1 more min. Tip in the prawns and sauce and simmer for 2 mins until thickened slightly. Serve with rice.', 1, 7)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (76, N'Chilli prawn linguine', 0, N'Italian', N'Mix the dressing ingredients in a small bowl and season with salt and pepper. Set aside.

Cook the pasta according to the packet instructions. Add the sugar snap peas for the last minute or so of cooking time.

Meanwhile, heat the oil in a wok or large frying pan, toss in the garlic and chilli and cook over a fairly gentle heat for about 30 seconds without letting the garlic brown. Tip in the prawns and cook over a high heat, stirring frequently, for about 3 minutes until they turn pink.

Add the tomatoes and cook, stirring occasionally, for 3 minutes until they just start to soften. Drain the pasta and sugar snaps well, then toss into the prawn mixture. Tear in the basil leaves, stir, and season with salt and pepper.

Serve with salad leaves drizzled with the lime dressing, and warm crusty bread.', 1, 8)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (77, N'Steak and Kidney Pie', 0, N'British', N'Preheat the oven to 220C/425F/Gas 7
Heat the vegetable oil in a large frying pan, and brown the beef all over. (You may need to do this in batches.) Set aside, then brown the kidneys on both sides in the same pan. Add the onions and cook for 3-4 minutes.
Return the beef to the pan, sprinkle flour over and coat the meat and onions
Add the stock to the pan, stir well and bring to the boil.
Turn the heat down and simmer for 1½ hours without a lid. If the liquid evaporates too much, add more stock.
Remove from the heat. Add salt, pepper and Worcestershire sauce and allow to cool completely. Place the cooked meat mixture into a pie dish.
Roll out the pastry to 5mm/¼in thick and 5cm/2in larger than the dish you are using.
Using a rolling pin, lift the pastry and place it over the top of the pie dish. Trim and crimp the edges with your fingers and thumb.
Brush the surface with the beaten egg mixture and bake for 30-40 minutes until golden-brown and puffed.
Serve with creamy mash and steamed vegetables to soak up the gravy.', 1, 2)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (78, N'Stuffed Lamb Tomatoes', 0, N'Greek', N'Heat oven to 180C/160C fan/gas 4. Slice the tops off the tomatoes and reserve. Scoop out most of the pulp with a teaspoon, being careful not to break the skin. Finely chop the pulp, and keep any juices. Sprinkle the insides of the tomatoes with a little sugar to take away the acidity, then place them on a baking tray.

Heat 2 tbsp olive oil in a large frying pan, add the onion and garlic, then gently cook for about 10 mins until soft but not coloured. Add the lamb, cinnamon and tomato purée, turn up the heat, then fry until the meat is browned. Add the tomato pulp and juice, the rice and the stock. Season generously. Bring to the boil, then simmer for 15 mins or until the rice is tender and the liquid has been absorbed. Set aside to cool a little, then stir in the herbs.

Stuff the tomatoes up to the brim, top tomatoes with their lids, drizzle with 2 tbsp more olive oil, sprinkle 3 tbsp water into the tray, then bake for 35 mins. Serve with salad and crusty bread, hot or cold.', 1, 11)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (79, N'Coq au vin', 0, N'French', N'Heat 1 tbsp of the oil in a large, heavy-based saucepan or flameproof dish. Tip in the bacon and fry until crisp. Remove and drain on kitchen paper. Add the shallots to the pan and fry, stirring or shaking the pan often, for 5-8 mins until well browned all over. Remove and set aside with the bacon.
Pat the chicken pieces dry with kitchen paper. Pour the remaining oil into the pan, then fry half the chicken pieces, turning regularly, for 5-8 mins until well browned. Remove, then repeat with the remaining chicken. Remove and set aside.
Scatter in the garlic and fry briefly, then, with the heat medium-high, pour in the brandy or Cognac, stirring the bottom of the pan to deglaze. The alcohol should sizzle and start to evaporate so there is not much left.
Return the chicken legs and thighs to the pan along with any juices, then pour in a little of the wine, stirring the bottom of the pan again. Stir in the rest of the wine, the stock and tomato purée, drop in the bouquet garni, season with pepper and a pinch of salt, then return the bacon and shallots to the pan. Cover, lower the heat to a gentle simmer, add the chicken breasts and cook for 50 mins-1hr.
Just before ready to serve, heat the oil for the mushrooms in a large non-stick frying pan. Add the mushrooms and fry over a high heat for a few mins until golden. Remove and keep warm.
Lift the chicken, shallots and bacon from the pan and transfer to a warmed serving dish. Remove the bouquet garni. To make the thickener, mix the flour, olive oil and butter in a small bowl using the back of a teaspoon. Bring the wine mixture to a gentle boil, then gradually drop in small pieces of the thickener, whisking each piece in using a wire whisk. Simmer for 1-2 mins. Scatter the mushrooms over the chicken, then pour over the wine sauce. Garnish with chopped parsley.', 1, 1)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (80, N'Portuguese barbecued pork (Febras assadas)', 0, N'Portuguese', N'STEP 1

Cut the tenderloins into 5 equal-size pieces leaving the tail ends a little longer. Take a clear plastic bag and slip one of the pieces in. Bash it into an escalope the size of a side-plate with a rolling pin and repeat with the remaining pieces.

STEP 2

Put the wine, paprika, some salt and pepper and the juice of ½ a lemon in a bowl and add the pork. Leave to marinate for 20-30 minutes, while you get your barbecue to the stage where the coals are glowing but there are no flames.

STEP 3

To make the chips, fill a basin with cool water and cut the potatoes into 3cm-thick chips. Soak them in the water for 5 minutes and then change the water. Leave for 5 more minutes. Drain and then pat dry on a towel or with kitchen paper.

STEP 4

Heat the oil in a deep fryer or a deep heavy-based pan with a lid to 130C and lower the chips into the oil (in batches). Blanch for 8-10 minutes. Remove from the oil and drain well. Place on a tray to cool. Reheat the oil to 180C (make sure it’s hot or your chips will be soggy) and lower the basket of chips into the oil (again, do this in batches). Leave to cook for 2 minutes and then give them a little shake. Cook for another minute or so until they are well coloured and crisp to the touch. Drain well for a few minutes, tip into a bowl and sprinkle with sea salt.

STEP 5

The pork will cook quickly so do it in 2 batches. Take the pieces out of the marinade, rub them with oil, and drop them onto the barbecue (you could also use a chargrill). Cook for 1 minute on each side – they may flare up as you do so. This should really be enough time as they will keep on cooking. Take them off the barbecue and pile onto a plate. Repeat with the remaining batch.

STEP 6

Serve by piling a plate with chips, drop the pork on top of each pile and pouring the juices from the plate over so the chips take up the flavours. Top with a spoon of mayonnaise and a wedge of lemon.', 1, 6)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (81, N'Corba', 0, N'Turkish', N'Pick through your lentils for any foreign debris, rinse them 2 or 3 times, drain, and set aside.  Fair warning, this will probably turn your lentils into a solid block that you’ll have to break up later
In a large pot over medium-high heat, sauté the olive oil and the onion with a pinch of salt for about 3 minutes, then add the carrots and cook for another 3 minutes.
Add the tomato paste and stir it around for around 1 minute. Now add the cumin, paprika, mint, thyme, black pepper, and red pepper as quickly as you can and stir for 10 seconds to bloom the spices. Congratulate yourself on how amazing your house now smells.
Immediately add the lentils, water, broth, and salt. Bring the soup to a (gentle) boil.
After it has come to a boil, reduce heat to medium-low, cover the pot halfway, and cook for 15-20 minutes or until the lentils have fallen apart and the carrots are completely cooked.
After the soup has cooked and the lentils are tender, blend the soup either in a blender or simply use a hand blender to reach the consistency you desire. Taste for seasoning and add more salt if necessary.
Serve with crushed-up crackers, torn up bread, or something else to add some extra thickness.  You could also use a traditional thickener (like cornstarch or flour), but I prefer to add crackers for some texture and saltiness.  Makes great leftovers, stays good in the fridge for about a week.', 1, 5)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (82, N'Big Mac', 0, N'American', N'For the Big Mac sauce, combine all the ingredients in a bowl, season with salt and chill until ready to use.
2. To make the patties, season the mince with salt and pepper and form into 4 balls using about 1/3 cup mince each. Place each onto a square of baking paper and flatten to form into four x 15cm circles. Heat oil in a large frypan over high heat. In 2 batches, cook beef patties for 1-2 minutes each side until lightly charred and cooked through. Remove from heat and keep warm. Repeat with remaining two patties.
3. Carefully slice each burger bun into three acrossways, then lightly toast.
4. To assemble the burgers, spread a little Big Mac sauce over the bottom base. Top with some chopped onion, shredded lettuce, slice of cheese, beef patty and some pickle slices. Top with the middle bun layer, and spread with more Big Mac sauce, onion, lettuce, pickles, beef patty and then finish with more sauce. Top with burger lid to serve.
5. After waiting half an hour for your food to settle, go for a jog.', 1, 2)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (83, N'Fettucine alfredo', 0, N'Italian', N'In a medium saucepan, stir the clotted cream, butter and cornflour over a low-ish heat and bring to a low simmer. Turn off the heat and keep warm.
Meanwhile, put the cheese and nutmeg in a small bowl and add a good grinding of black pepper, then stir everything together (don’t add any salt at this stage).
Put the pasta in another pan with 2 tsp salt, pour over some boiling water and cook following pack instructions (usually 3-4 mins). When cooked, scoop some of the cooking water into a heatproof jug or mug and drain the pasta, but not too thoroughly.
Add the pasta to the pan with the clotted cream mixture, then sprinkle over the cheese and gently fold everything together over a low heat using a rubber spatula. When combined, splash in 3 tbsp of the cooking water. At first, the pasta will look wet and sloppy: keep stirring until the water is absorbed and the sauce is glossy. Check the seasoning before transferring to heated bowls. Sprinkle over some chives or parsley, then serve immediately.', 1, 8)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (84, N'Pizza Express Margherita', 0, N'Italian', N'1 Preheat the oven to 230°C.

2 Add the sugar and crumble the fresh yeast into warm water.

3 Allow the mixture to stand for 10 – 15 minutes in a warm place (we find a windowsill on a sunny day works best) until froth develops on the surface.

4 Sift the flour and salt into a large mixing bowl, make a well in the middle and pour in the yeast mixture and olive oil.

5 Lightly flour your hands, and slowly mix the ingredients together until they bind.

6 Generously dust your surface with flour.

7 Throw down the dough and begin kneading for 10 minutes until smooth, silky and soft.

8 Place in a lightly oiled, non-stick baking tray (we use a round one, but any shape will do!)

9 Spread the passata on top making sure you go to the edge.

10 Evenly place the mozzarella (or other cheese) on top, season with the oregano and black pepper, then drizzle with a little olive oil.

11 Cook in the oven for 10 – 12 minutes until the cheese slightly colours.

12 When ready, place the basil leaf on top and tuck in!', 1, 4)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (85, N'Escovitch Fish', 0, N'Jamaican', N'Rinse fish; rub with lemon or lime, seasoned with salt and pepper or use your favorite seasoning. I used creole seasoning. Set aside or place in the oven to keep it warm until sauce is ready.

In large skillet heat oil over medium heat, until hot, add the fish, cook each side- for about 5-7 minutes until cooked through and crispy on both sides. Remove fish and set aside. Drain oil and leave about 2-3 tablespoons of oil
Add, bay leave, garlic and ginger, stir-fry for about a minute making sure the garlic does not burn
Then add onion, bell peppers, thyme, scotch bonnet, sugar, all spice-continue stirring for about 2-3 minutes. Add vinegar, mix an adjust salt and pepper according to preference. Let it simmer for about 2 more minutes. 

Discard bay leave, thyme spring and serve over fish with a side of this bammy. You may make the sauce about 2 days in advance.', 1, 7)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (86, N'Burek', 0, N'Croatian', N'Fry the finely chopped onions and minced meat in oil. Add the salt and pepper. Grease a round baking tray and put a layer of pastry in it. Cover with a thin layer of filling and cover this with another layer of filo pastry which must be well coated in oil. Put another layer of filling and cover with pastry. When you have five or six layers, cover with filo pastry, bake at 200ºC/392ºF for half an hour and cut in quarters and serve.', 1, 5)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (87, N'Laksa King Prawn Noodles', 0, N'Malaysian', N'Heat the oil in a medium saucepan and add the chilli. Cook for 1 min, then add the curry paste, stir and cook for 1 min more. Dissolve the stock cube in a large jug in 700ml boiling water, then pour into the pan and stir to combine. Tip in the coconut milk and bring to the boil.
Add the fish sauce and a little seasoning. Toss in the noodles and cook for a further 3-4 mins until softening. Squeeze in the lime juice, add the prawns and cook through until warm, about 2-3 mins. Scatter over some of the coriander.
Serve in bowls with the remaining coriander and lime wedges on top for squeezing over.', 1, 7)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (88, N'Lamb tomato and sweet spices', 0, N'Moroccan', N'Use pickled vine leaves here, preserved in brine. Small delicate leaves are better than the large bristly ones but, if only large leaves are to hand, then trim them to roughly 12 by 12 cms so that you don''t get too many layers of leaves around the filling. And remove any stalks. Drain the preserved leaves, immerse them in boiling water for 10 minutes and then leave to dry on a tea towel before use. 
Basmati rice with butter and pine nuts is an ideal accompaniment. Couscous is great, too. Serves four.
First make the filling. Put all the ingredients, apart from the tomatoes, in a bowl. Cut the tomatoes in half, coarsely grate into the bowl and discard the skins. Add half a teaspoon of salt and some black pepper, and stir. Leave on the side, or in the fridge, for up to a day. Before using, gently squeeze with your hands and drain away any juices that come out.
To make the sauce, heat the oil in a medium pan. Add the ginger and garlic, cook for a minute or two, taking care not to burn them, then add the tomato, lemon juice and sugar. Season, and simmer for 20 minutes.
While the sauce is bubbling away, prepare the vine leaves. Use any torn or broken leaves to line the base of a wide, heavy saucepan. Trim any leaves from the fennel, cut it vertically into 0.5cm-thick slices and spread over the base of the pan to cover completely.
Lay a prepared vine leaf (see intro) on a work surface, veiny side up. Put two teaspoons of filling at the base of the leaf in a 2cm-long by 1cm-wide strip. Fold the sides of the leaf over the filling, then roll it tightly from bottom to top, in a cigar shape. Place in the pan, seam down, and repeat with the remaining leaves, placing them tightly next to each other in lines or circles (in two layers if necessary).
Pour the sauce over the leaves (and, if needed, add water just to cover). Place a plate on top, to weigh the leaves down, then cover with a lid. Bring to a boil, reduce the heat and cook on a bare simmer for 70 minutes. Most of the liquid should evaporate. Remove from the heat, and leave to cool a little - they are best served warm. When serving, bring to the table in the pan - it looks great. Serve a few vine leaves and fennel slices with warm rice. Spoon the braising juices on top and garnish with coriander.', 1, 11)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (89, N'Fresh sardines', 0, N'Croatian', N'Wash the fish under the cold tap. Roll in the flour and deep fry in oil until crispy. Lay on kitchen towel to get rid of the excess oil and serve hot or cold with a slice of lemon.', 1, 5)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (90, N'Chicken Congee', 0, N'Chinese', N'STEP 1 - MARINATING THE CHICKEN
In a bowl, add chicken, salt, white pepper, ginger juice and then mix it together well.
Set the chicken aside.
STEP 2 - RINSE THE WHITE RICE
Rinse the rice in a metal bowl or pot a couple times and then drain the water.
STEP 2 - BOILING THE WHITE RICE
Next add 8 cups of water and then set the stove on high heat until it is boiling. Once rice porridge starts to boil, set the stove on low heat and then stir it once every 8-10 minutes for around 20-25 minutes.
After 25 minutes, this is optional but you can add a little bit more water to make rice porridge to make it less thick or to your preference.
Next add the marinated chicken to the rice porridge and leave the stove on low heat for another 10 minutes.
After an additional 10 minutes add the green onions, sliced ginger, 1 pinch of salt, 1 pinch of white pepper and stir for 10 seconds.
Serve the rice porridge in a bowl
Optional: add Coriander on top of the rice porridge.', 1, 1)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (91, N'Tuna Nicoise', 0, N'French', N'Heat oven to 200C/fan 180C/gas 6. Toss the potatoes with 2 tsp oil and some seasoning. Tip onto a large baking tray, then roast for 20 mins, stirring halfway, until crisp, golden and cooked through.
Meanwhile, put eggs in a small pan of water, bring to the boil, then simmer for 8-10 mins, depending on how you like them cooked. Plunge into a bowl of cold water to cool for a few mins. Peel away the shells, then cut into halves.
In a large salad bowl, whisk together the remaining oil, red wine vinegar, capers and chopped tomatoes. Season, tip in the onion, spinach, tuna and potatoes, then gently toss together. Top with the eggs, then serve straight away.', 1, 7)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (92, N'Potato Gratin with Chicken', 0, N'Unknown', N'15 minute potato gratin with chicken and bacon greens: a gratin always seems more effort and more indulgent than ordinary boiled or roasts, but it doesn''t have to take 45mins, it''s nice for a change and you can control the calorie content by going with full fat to low fat creme fraiche. (It''s always tastes better full fat though obviously!) to serve 4: use 800g of potatoes, finely slice and boil in a pan for about 5-8 mins till firmish, not soft. Finely slice 3 onions and place in an oven dish with 2 tblsp of olive oil and 100ml of chicken stock. Cook till the onions are soft then drain the potatoes and pour onto the onions. Season and spoon over cream or creme fraiche till all is covered but not swimming. Grate Parmesan over the top then finish under the grill till nicely golden. serve with chicken and bacon, peas and spinach.', 1, 1)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (93, N'Egyptian Fatteh', 0, N'Egyptian', N'To prepare bread for bottom of dish: Take pita bread and rip into bite size pieces. In a frying pan, add about a 1/4 stick of butter, add bread pieces and fry until golden brown and crisp. Put these pieces in a glass baking dish, preferably a square sized dish. Set aside.
Then add to same pan, a little more butter, salt, approximately 2 cloves of crushed fresh garlic, and a teaspoon or so of cumin stir around a bit until you can smell aroma, then add fried bread pieces to this mixture, stir to coat bread and put back into glass baking dish. Set aside.
To prepare meat: put some butter in a pot, stir fry meat until brown, add 1 onion quartered, salt & pepper, 1 cube of chicken bouillon and water to cover meat. Bring to a boil, turn down to simmer, cover and cook until tender, approximately 2 hours. After meat has cooled, take out chunks of meat and put in a bowl, set aside. Reserve soup from the meat separately.
To prepare the rice: Put some butter into a pot, add shareya (fideo noodles) like a handful or so, keep stirring until golden brown, not too dark, but very golden. Then add two cups of rice, stir a little bit until some of the rice turns an opaque white. Add 2-1/4 cups of water and salt to taste. Bring to a boil, cover and turn down to simmer, cook until tender. Test the rice tenderness after about 35 minutes.
Now take some of the soup from meat and add to the top of the bread pieces in baking dish to saturate.Add cooked rice on top of bread pieces. Slowly spoon remainder of soup onto rice, looking at glass dish sides to see level of soup, should reach just to top of rice, don’t worry, this doesn’t have to be exact. Now you’re ready to make the sauce and fry the meat to put on top.
To prepare red sauce: In a pan, add a little oil or butter, crushed tomato, a half teaspoon of tomato paste, salt & pepper, 2 cloves of fresh crushed garlic and cumin. Add also approximately 3 tablespoons of vinegar, stir this until you smell aroma and it is a bit smooth. It should be a bit thick, not watery, but if too thick you can add a bit of water. Spread with a wooden spoon atop the rice to cover.
To fry meat: In a pan add a bit of butter or oil, the meat, just a touch of tomato paste, about a tablespoon of fresh crushed garlic, salt & pepper, a teaspoon of cumin. Cook until meat is golden fried.
Spoon this atop the rice and serve. Enjoy!', 1, 2)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (94, N'Beef and Oyster pie', 0, N'British', N'Season the beef cubes with salt and black pepper. Heat a tablespoon of oil in the frying pan and fry the meat over a high heat. Do this in three batches so that you don’t overcrowd the pan, transferring the meat to a large flameproof casserole dish once it is browned all over. Add extra oil if the pan seems dry.
In the same pan, add another tablespoon of oil and cook the shallots for 4-5 minutes, then add the garlic and fry for 30 seconds. Add the bacon and fry until slightly browned. Transfer the onion and bacon mixture to the casserole dish and add the herbs.
Preheat the oven to 180C/350F/Gas 4.
Pour the stout into the frying pan and bring to the boil, stirring to lift any stuck-on browned bits from the bottom of the pan. Pour the stout over the beef in the casserole dish and add the stock. Cover the casserole and place it in the oven for 1½-2 hours, or until the beef is tender and the sauce is reduced.
Skim off any surface fat, taste and add salt and pepper if necessary, then stir in the cornflour paste. Put the casserole dish on the hob – don’t forget that it will be hot – and simmer for 1-2 minutes, stirring, until thickened. Leave to cool.
Increase the oven to 200C/400F/Gas 6. To make the pastry, put the flour and salt in a very large bowl. Grate the butter and stir it into the flour in three batches. Gradually add 325ml/11fl oz cold water – you may not need it all – and stir with a round-bladed knife until the mixture just comes together. Knead the pastry lightly into a ball on a lightly floured surface and set aside 250g/9oz for the pie lid.
Roll the rest of the pastry out until about 2cm/¾in larger than the dish you’re using. Line the dish with the pastry then pile in the filling, tucking the oysters in as well. Brush the edge of the pastry with beaten egg.
Roll the remaining pastry until slightly larger than your dish and gently lift over the filling, pressing the edges firmly to seal, then trim with a sharp knife. Brush with beaten egg to glaze. Put the dish on a baking tray and bake for 25-30 minutes, or until the pastry is golden-brown and the filling is bubbling.', 1, 2)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (95, N'Spicy North African Potato Salad', 0, N'Moroccan', N'Cook potatoes - place potatoes in a pot of cold water, and bring to the boil. Boil 20 minutes, or until potatoes are tender. You know they are cooked when you can stick a knife in them and the knife goes straight through.
Combine harissa spice, olive oil, salt and pepper and lemon juice in a small bowl and whisk until combined.
Once potatoes are cooked, drain water and roughly chop potatoes in half.
Add harissa mix and spring onions/green onions to potatoes and stir.
In a large salad bowl, lay out arugula/rocket.
Top with potato mix and toss.
Add fetta, mint and sprinkle over pine nuts.
Adjust salt and pepper to taste.', 1, 9)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (96, N'Mediterranean Pasta Salad', 0, N'Italian', N'Bring a large saucepan of salted water to the boil
Add the pasta, stir once and cook for about 10 minutes or as directed on the packet.
Meanwhile, wash the tomatoes and cut into quarters. Slice the olives. Wash the basil.
Put the tomatoes into a salad bowl and tear the basil leaves over them. Add a tablespoon of olive oil and mix.
When the pasta is ready, drain into a colander and run cold water over it to cool it quickly.
Toss the pasta into the salad bowl with the tomatoes and basil.
Add the sliced olives, drained mozzarella balls, and chunks of tuna. Mix well and let the salad rest for at least half an hour to allow the flavours to mingle.
Sprinkle the pasta with a generous grind of black pepper and drizzle with the remaining olive oil just before serving.', 1, 7)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (97, N'Nutty Chicken Curry', 0, N'Indian', N'Finely slice a quarter of the chilli, then put the rest in a food processor with the ginger, garlic, coriander stalks and one-third of the leaves. Whizz to a rough paste with a splash of water if needed.
Heat the oil in a frying pan, then quickly brown the chicken chunks for 1 min. Stir in the paste for another min, then add the peanut butter, stock and yogurt. When the sauce is gently bubbling, cook for 10 mins until the chicken is just cooked through and sauce thickened. Stir in most of the remaining coriander, then scatter the rest on top with the chilli, if using. Eat with rice or mashed sweet potato.', 1, 1)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (98, N'Provençal Omelette Cake', 0, N'French', N'Break the eggs into two bowls, five in each. Whisk lightly and season with salt and pepper. Heat the oil in a pan, add the courgettes and spring onions, then fry gently for about 10 mins until softened. Cool, then stir into one bowl of eggs with a little salt and pepper. Add the roasted peppers to the other bowl of eggs with the garlic, chilli, salt and pepper.
Heat a little oil in a 20-23cm frying pan, preferably non-stick. Pour the eggs with courgette into a measuring jug, then pourabout one-third of the mixture into the pan, swirling it to cover the base of the pan. Cook until the egg is set and lightly browned underneath, then cover the pan with a plate and invert the omelette onto it. Slide it back into the pan to cook the other side. Repeat with the remaining mix to make two more omelettes, adding a little oil to the pan each time. Stack the omelettes onto a plate. Make three omelettes in the same way with the red pepper mixture, then stack them on a separate plate.
Now make the filling. Beat the cheese to soften it, then beat in the milk to make a spreadable consistency. Stir in the herbs, salt and pepper. Line a deep, 20-23cm round cake tin with cling film (use a tin the same size as the frying pan). Select the best red pepper omelette and place in the tin, prettiest side down. Spread with a thin layer of cheese filling, then cover with a courgette omelette. Repeat, alternating the layers, until all the omelettes and filling are in the tin, finishing with an omelette. Flip the cling film over the omelette, then chill for up to 24 hrs.
To serve, invert the omelette cake onto a serving plate and peel off the cling film. Pile rocket on the top and scatter over the cheese, a drizzle of olive oil and a little freshly ground black pepper. Serve cut into wedges.', 1, 9)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (99, N'Kedgeree', 0, N'British', N'For the rice, heat the oil in a large, lidded pan, add the onion, then gently fry for 5 mins until softened but not coloured. Add the spices, season with salt, then continue to fry until the mix start to go brown and fragrant; about 3 mins.
Add the rice and stir in well. Add 600ml water, stir, then bring to the boil. Reduce to a simmer, then cover for 10 mins. Take off the heat and leave to stand, covered, for 10-15 mins more. The rice will be perfectly cooked if you do not lift the lid before the end of the cooking.
Meanwhile, put the haddock and bay leaves in a frying pan, cover with the milk, then poach for 10 mins until the flesh flakes. Remove from the milk, peel away the skin, then flake the flesh into thumbsize pieces. Place the eggs in a pan, cover with water, bring to the boil, then reduce to a simmer. Leave for 4½-5 mins, plunge into cold water, then peel and cut the eggs into quarters. Gently mix the fish, eggs, parsley, coriander and rice together in the pan. Serve hot, sprinkled with a few extra herbs.', 1, 7)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (100, N'Chicken Ham and Leek Pie', 0, N'British', N'Heat the chicken stock in a lidded saucepan. Add the chicken breast and bring to a low simmer. Cover with a lid and cook for 10 minutes. Remove the chicken breasts from the water with tongs and place on a plate. Pour the cooking liquor into a large jug.
Melt 25g/1oz of the butter in a large heavy-based saucepan over a low heat. Stir in the leeks and fry gently for two minutes, stirring occasionally until just softened. Add the garlic and cook for a further minute. Add the remaining butter and stir in the flour as soon as the butter has melted. Cook for 30 seconds, stirring constantly.
Slowly pour the milk into the pan, just a little at a time, stirring well between each adding. Gradually add 250ml/10fl oz of the reserved stock and the wine, if using, stirring until the sauce is smooth and thickened slightly. Bring to a gentle simmer and cook for 3 minutes.
Season the mixture, to taste, with salt and freshly ground black pepper. Remove from the heat and stir in the cream. Pour into a large bowl and cover the surface of the sauce with cling ilm to prevent a skin forming. Set aside to cool.
Preheat the oven to 200C/400F/Gas 6. Put a baking tray in the oven to heat.
For the pastry, put the flour and butter in a food processor and blend on the pulse setting until the mixture resembles fine breadcrumbs. With the motor running, add the beaten egg and water and blend until the mixture forms a ball. Portion off 250g/10oz of pastry for the lid.
Roll the remaining pastry out on a lightly floured surface, turning the pastry frequently until around 5mm/¼in thick and 4cm/1½in larger than the pie dish. Lift the pastry over the rolling pin and place it gently into the pie dish. Press the pastry firmly up the sides, making sure there are no air bubbles. Leave the excess pastry overhanging the sides.
Cut the chicken breasts into 3cm/1¼in pieces. Stir the chicken, ham and leeks into the cooled sauce. Pour the chicken filling into the pie dish. Brush the rim of the dish with beaten egg. Roll out the reserved pastry for the lid.
Cover the pie with the pastry lid and press the edges together firmly to seal. Trim any excess pastry.
Make a small hole in the centre of the pie with the tip of a knife. Glaze the top of the pie with beaten egg. Bake on the preheated tray in the centre of the oven for 35-40 minutes or until the pie is golden-brown all over and the filling is piping hot.', 1, 1)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (101, N'Gigantes Plaki', 0, N'Greek', N'Soak the beans overnight in plenty of water. Drain, rinse, then place in a pan covered with water. Bring to the boil, reduce the heat, then simmer for approx 50 mins until slightly tender but not soft. Drain, then set aside.

Heat oven to 180C/160C fan/gas 4. Heat the olive oil in a large frying pan, tip in the onion and garlic, then cook over a medium heat for 10 mins until softened but not browned. Add the tomato purée, cook for a further min, add remaining ingredients, then simmer for 2-3 mins. Season generously, then stir in the beans. Tip into a large ovenproof dish, then bake for approximately 1 hr, uncovered and without stirring, until the beans are tender. The beans will absorb all the fabulous flavours and the sauce will thicken. Allow to cool, then scatter with parsley and drizzle with a little more olive oil to serve.', 1, 9)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (102, N'Lamb Tagine', 0, N'Moroccan', N'Heat the olive oil in a heavy-based pan and add the onion and carrot. Cook for 3- 4 mins until softened.

Add the diced lamb and brown all over. Stir in the garlic and all the spices and cook for a few mins more or until the aromas are released.

Add the honey and apricots, crumble in the stock cube and pour over roughly 500ml boiling water or enough to cover the meat. Give it a good stir and bring to the boil. Turn down to a simmer, put the lid on and cook for 1 hour.

Remove the lid and cook for a further 30 mins, then stir in the squash. Cook for 20 – 30 mins more until the squash is soft and the lamb is tender. Serve alongside rice or couscous and sprinkle with parsley and pine nuts, if using.', 1, 11)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (103, N'Chicken Handi', 0, N'Indian', N'Take a large pot or wok, big enough to cook all the chicken, and heat the oil in it. Once the oil is hot, add sliced onion and fry them until deep golden brown. Then take them out on a plate and set aside.
To the same pot, add the chopped garlic and sauté for a minute. Then add the chopped tomatoes and cook until tomatoes turn soft. This would take about 5 minutes.
Then return the fried onion to the pot and stir. Add ginger paste and sauté well.
Now add the cumin seeds, half of the coriander seeds and chopped green chillies. Give them a quick stir.
Next goes in the spices – turmeric powder and red chilli powder. Sauté the spices well for couple of minutes.
Add the chicken pieces to the wok, season it with salt to taste and cook the chicken covered on medium-low heat until the chicken is almost cooked through. This would take about 15 minutes. Slowly sautéing the chicken will enhance the flavor, so do not expedite this step by putting it on high heat.
When the oil separates from the spices, add the beaten yogurt keeping the heat on lowest so that the yogurt doesn’t split. Sprinkle the remaining coriander seeds and add half of the dried fenugreek leaves. Mix well.
Finally add the cream and give a final mix to combine everything well.
Sprinkle the remaining kasuri methi and garam masala and serve the chicken handi hot with naan or rotis. Enjoy!', 1, 1)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (104, N'Tunisian Lamb Soup', 0, N'Tunisian', N'Add the lamb to a casserole and cook over high heat. When browned, remove from the heat and set aside.
Keep a tablespoon of fat in the casserole and discard the rest. Reduce to medium heat then add the garlic, onion and spinach and cook until the onion is translucent and the spinach wilted or about 5 minutes.
Return the lamb to the casserole with the onion-spinach mixture, add the tomato puree, cumin, harissa, chicken, chickpeas, lemon juice, salt and pepper in the pan. Simmer over low heat for about 20 minutes.
Add the pasta and cook for 15 minutes or until pasta is cooked.', 1, 11)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (105, N'Matar Paneer', 0, N'Indian', N'Heat the oil in a frying pan over high heat until it’s shimmering hot. Add the paneer, then turn the heat down a little. Fry until it starts to brown at the edges, then turn it over and brown on each side – the paneer will brown faster than you think, so don’t walk away. Remove the paneer from the pan and drain on kitchen paper.
Put the ginger, cumin, turmeric, ground coriander and chilli in the pan, and fry everything for 1 min. Add the tomatoes, mashing them with the back of a spoon and simmer everything for 5 mins until the sauce smells fragrant. Add a splash of water if it’s too thick. Season well. Add the peas and simmer for a further 2 mins, then stir in the paneer and sprinkle over the garam masala. Divide between two bowls, top with coriander leaves and serve with naan bread, roti or rice.', 1, 9)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (106, N'Chicken Quinoa Greek Salad', 0, N'Greek', N'Cook the quinoa following the pack instructions, then rinse in cold water and drain thoroughly.

Meanwhile, mix the butter, chilli and garlic into a paste. Toss the chicken fillets in 2 tsp of the olive oil with some seasoning. Lay in a hot griddle pan and cook for 3-4 mins each side or until cooked through. Transfer to a plate, dot with the spicy butter and set aside to melt.

Next, tip the tomatoes, olives, onion, feta and mint into a bowl. Toss in the cooked quinoa. Stir through the remaining olive oil, lemon juice and zest, and season well. Serve with the chicken fillets on top, drizzled with any buttery chicken juices.', 1, 1)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (107, N'Fish fofos', 0, N'Portuguese', N'STEP 1

Put the fish into a lidded pan and pour over enough water to cover. Bring to a simmer and gently poach for 10 minutes over a low heat with the lid on. Drain and flake the fish.

STEP 2

Put the fish, potato, green chilli, coriander, cumin, black pepper, garlic and ginger in a large bowl. Season, add the rice flour, mix well and break in 1 egg. Stir the mixture and divide into 15, then form into small logs. Break the remaining eggs into a bowl and whisk lightly. Put the breadcrumbs into another bowl. Dip each fofo in the beaten egg followed by the breadcrumb mixture. Chill for 20 minutes.

STEP 3

Heat 1cm of oil in a large frying pan over a medium heat. Fry the fofos in batches for 2 minutes on each side, turning gently to get an even golden brown colour all over. Drain on kitchen paper and repeat with the remaining fofos.

STEP 4

For the onion salad, mix together the onion, coriander and lemon juice with a pinch of salt. Serve with the fofos and mango chutney.', 1, 7)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (108, N'Beef Lo Mein', 0, N'Chinese', N'STEP 1 - MARINATING THE BEEF
In a bowl, add the beef, salt, 1 pinch white pepper, 1 Teaspoon sesame seed oil, 1/2 egg, corn starch,1 Tablespoon of oil and mix together.
STEP 2 - BOILING THE THE NOODLES
In a 6 qt pot add your noodles to boiling water until the noodles are submerged and boil on high heat for 10 seconds. After your noodles is done boiling strain and cool with cold water.
STEP 3 - STIR FRY
Add 2 Tablespoons of oil, beef and cook on high heat untill beef is medium cooked.
Set the cooked beef aside
In a wok add 2 Tablespoon of oil, onions, minced garlic, minced ginger, bean sprouts, mushrooms, peapods and 1.5 cups of water or until the vegetables are submerged in water.
Add the noodles to wok
To make the sauce, add oyster sauce, 1 pinch white pepper, 1 teaspoon sesame seed oil, sugar, and 1 Teaspoon of soy sauce.
Next add the beef to wok and stir-fry', 1, 2)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (109, N'Tamiya', 0, N'Egyptian', N'oak the beans in water to cover overnight.Drain. If skinless beans are unavailable, rub to loosen the skins, then discard the skins. Pat the beans dry with a towel.
Grind the beans in a food mill or meat grinder.If neither appliance is available, process them in a food processor but only until the beans form a paste. (If blended too smoothly, the batter tends to fall apart during cooking.) Add the scallions, garlic, cilantro, cumin, baking powder, cayenne, salt, pepper, and coriander, if using.  Refrigerate for at least 30 minutes.
Shape the bean mixture into 1-inch balls.Flatten slightly and coat with flour.
Heat at least 1½-inches of oil over medium heat to 365 degrees.
Fry the patties in batches, turning once, until golden brown on all sides, about 5 minutes.Remove with a wire mesh skimmer or slotted spoon. Serve as part of a meze or in pita bread with tomato-cucumber salad and tahina sauce.', 1, 9)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (110, N'Spaghetti Bolognese', 0, N'Italian', N'Put the onion and oil in a large pan and fry over a fairly high heat for 3-4 mins. Add the garlic and mince and fry until they both brown. Add the mushrooms and herbs, and cook for another couple of mins.

Stir in the tomatoes, beef stock, tomato ketchup or purée, Worcestershire sauce and seasoning. Bring to the boil, then reduce the heat, cover and simmer, stirring occasionally, for 30 mins.

Meanwhile, cook the spaghetti in a large pan of boiling, salted water, according to packet instructions. Drain well, run hot water through it, put it back in the pan and add a dash of olive oil, if you like, then stir in the meat sauce. Serve in hot bowls and hand round Parmesan cheese, for sprinkling on top.', 1, 2)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (111, N'Pork Cassoulet', 0, N'French', N'Heat oven to 140C/120C fan/gas 1. Put a large ovenproof pan (with a tight-fitting lid) on a high heat. Add your fat and diced meat, cook for a few mins to seal the edges, giving it a quick stir to cook evenly. Reduce the heat to low, add the sliced onion, whole garlic cloves, carrot and fennel seeds, and cook gently to soften the veg for a few mins.
Pour over the red wine vinegar, scraping any meaty bits off the bottom of the pan. Add the stock, tomato purée, and half the rosemary and parsley. Bring to the boil and simmer for 10 mins, then season, cover with a lid and put into the oven for 2 hrs, removing the lid for the final hour of cooking. Stir occasionally and add the beans with 30 mins to go.
Remove the pan from the oven and heat the grill. Scatter the top with the remaining herbs and breadcrumbs, drizzle a little oil over the top, and return to the oven for 5-10 mins, until the breadcrumbs are golden. Serve with crusty bread and green veg.', 1, 6)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (112, N'Beef stroganoff', 0, N'Russian', N'Heat the olive oil in a non-stick frying pan then add the sliced onion and cook on a medium heat until completely softened, so around 15 mins, adding a little splash of water if they start to stick at all. Crush in the garlic and cook for a 2-3 mins further, then add the butter. Once the butter is foaming a little, add the mushrooms and cook for around 5 mins until completely softened. Season everything well, then tip onto a plate.
Tip the flour into a bowl with a big pinch of salt and pepper, then toss the steak in the seasoned flour. Add the steak pieces to the pan, splashing in a little oil if the pan looks particularly dry, and fry for 3-4 mins, until well coloured. Tip the onions and mushrooms back into the pan. Whisk the crème fraîche, mustard and beef stock together, then pour into the pan. Cook over a medium heat for around 5 mins. Scatter with parsley, then serve with pappardelle or rice.', 1, 2)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (113, N'Sweet and Sour Pork', 0, N'Chinese', N'Preparation
1. Crack the egg into a bowl. Separate the egg white and yolk.

Sweet and Sour Pork
2. Slice the pork tenderloin into strips.

3. Prepare the marinade using a pinch of salt, one teaspoon of starch, two teaspoons of light soy sauce, and an egg white.

4. Marinade the pork strips for about 20 minutes.

5. Put the remaining starch in a bowl. Add some water and vinegar to make a starchy sauce.

Sweet and Sour Pork
Cooking Instructions
1. Pour the cooking oil into a wok and heat to 190°C (375°F). Add the marinated pork strips and fry them until they turn brown. Remove the cooked pork from the wok and place on a plate.

2. Leave some oil in the wok. Put the tomato sauce and white sugar into the wok, and heat until the oil and sauce are fully combined.

3. Add some water to the wok and thoroughly heat the sweet and sour sauce before adding the pork strips to it.

4. Pour in the starchy sauce. Stir-fry all the ingredients until the pork and sauce are thoroughly mixed together.

5. Serve on a plate and add some coriander for decoration.', 1, 6)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (114, N'Chicken Marengo', 0, N'French', N'Heat the oil in a large flameproof casserole dish and stir-fry the mushrooms until they start to soften. Add the chicken legs and cook briefly on each side to colour them a little.
Pour in the passata, crumble in the stock cube and stir in the olives. Season with black pepper – you shouldn’t need salt. Cover and simmer for 40 mins until the chicken is tender. Sprinkle with parsley and serve with pasta and a salad, or mash and green veg, if you like.', 1, 1)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (115, N'Flamiche', 0, N'French', N'For the pastry, sift the flour and salt into the bowl of a food processor, add the butter and lard, then whizz together briefly until the mixture looks like fine breadcrumbs. Tip the mixture into a bowl, then stir in the cheese and enough of the water for the mixture to come together. Tip out onto a lightly floured surface and knead briefly until smooth. Roll out thinly and line a 23cm x 4cm loose-?bottomed fluted flan tin. Prick the base with a fork. Chill for 20 minutes.
02.Melt the 75g butter in a saucepan over a low heat, then add the leeks and the salt. Cover and cook for ?10 minutes until soft. Uncover the pan, increase the heat and cook ?for 2 minutes, stirring occasionally, until the liquid has evaporated. Spoon onto a plate and leave to cool.
03.Preheat the oven to 200°C/fan180°C/gas 6. Line the pastry case with baking paper and baking beans or rice and blind bake for 15-20 minutes until the edges are biscuit-coloured. Remove the paper and beans/rice and return the case to the oven for 7-10 minutes until the base is crisp and lightly golden. Remove and set aside. Reduce the oven temperature to 190°C/fan170°C/gas 5.
04.Put the crème fraîche into a bowl with the whole egg, egg yolks and nutmeg. Lightly beat together, then season. Stir in the leeks. Spoon ?the mixture into the tart case and bake for 35-40 minutes until set ?and lightly golden. Remove from ?the oven and leave for 10 minutes. Take out of the tin and serve.', 1, 9)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (116, N'Tandoori chicken', 0, N'Indian', N'Mix the lemon juice with the paprika and red onions in a large shallow dish. Slash each chicken thigh three times, then turn them in the juice and set aside for 10 mins.
Mix all of the marinade ingredients together and pour over the chicken. Give everything a good mix, then cover and chill for at least 1 hr. This can be done up to a day in advance.
Heat the grill. Lift the chicken pieces onto a rack over a baking tray. Brush over a little oil and grill for 8 mins on each side or until lightly charred and completely cooked through.', 1, 1)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (117, N'Squash linguine', 0, N'Italian', N'Heat oven to 200C/180C fan/gas 6. Put the squash and garlic on a baking tray and drizzle with the olive oil. Roast for 35-40 mins until soft. Season.
Cook the pasta according to pack instructions. Drain, reserving the water. Use a stick blender to whizz the squash with 400ml cooking water. Heat some oil in a frying pan, fry the sage until crisp, then drain on kitchen paper. Tip the pasta and sauce into the pan and warm through. Scatter with sage.', 1, 9)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (118, N'Shrimp Chow Fun', 0, N'Chinese', N'STEP 1 - SOAK THE RICE NOODLES
Soak the rice noodles overnight untill they are soft
STEP 2 - BOIL THE RICE NOODLES
Boil the noodles for 10-15 minutes and then rinse with cold water to stop the cooking process of the noodles.
STEP 3 -MARINATING THE SHRIMP
In a bowl add the shrimp, egg, 1 pinch of white pepper, 1 Teaspoon of sesame seed oil, 1 Tablespoon corn starch and 1 tablespoon of oil
Mix together well
STEP 4 - STIR FRY
In a wok add 2 Tablespoons of oil, shrimp and stir fry them until it is golden brown
Set the shrimp aside
Add 1 Tablespoon of oil to the work and then add minced garlic, ginger and all of the vegetables.
Add the noodles to the wok
Next add sherry cooking wine, oyster sauce, sugar, vinegar, sesame seed oil, 1 pinch white pepper, and soy sauce
Add back in the shrimp
To thicken the sauce, whisk together 1 Tablespoon of corn starch and 2 Tablespoon of water in a bowl and slowly add to your stir-fry until it''s the right thickness.', 1, 7)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (119, N'Lamb Rogan josh', 0, N'Indian', N'
Put the onions in a food processor and whizz until very finely chopped. Heat the oil in a large heavy-based pan, then fry the onion with the lid on, stirring every now and then, until it is really golden and soft. Add the garlic and ginger, then fry for 5 mins more.
Tip the curry paste, all the spices and the bay leaves into the pan, with the tomato purée. Stir well over the heat for about 30 secs, then add the meat and 300ml water. Stir to mix, turn down the heat, then add the yogurt.
Cover the pan, then gently simmer for 40-60 mins until the meat is tender and the sauce nice and thick. Serve scattered with coriander, with plain basmati or pilau rice.', 1, 11)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (120, N'Baingan Bharta', 0, N'Indian', N'Rinse the baingan (eggplant or aubergine) in water. Pat dry with a kitchen napkin. Apply some oil all over and
keep it for roasting on an open flame. You can also grill the baingan or roast in the oven. But then you won''t get
the smoky flavor of the baingan. Keep the eggplant turning after a 2 to 3 minutes on the flame, so that its evenly
cooked. You could also embed some garlic cloves in the baingan and then roast it.
2. Roast the aubergine till its completely cooked and tender. With a knife check the doneness. The knife should slid
easily in aubergines without any resistance. Remove the baingan and immerse in a bowl of water till it cools
down.
3. You can also do the dhungar technique of infusing charcoal smoky flavor in the baingan. This is an optional step.
Use natural charcoal for this method. Heat a small piece of charcoal on flame till it becomes smoking hot and red.
4. Make small cuts on the baingan with a knife. Place the red hot charcoal in the same plate where the roasted
aubergine is kept. Add a few drops of oil on the charcoal. The charcoal would begin to smoke.
5. As soon as smoke begins to release from the charcoal, cover the entire plate tightly with a large bowl. Allow the
charcoal smoke to get infused for 1 to 2 minutes. The more you do, the more smoky the baingan bharta will
become. I just keep for a minute. Alternatively, you can also do this dhungar method once the baingan bharta is
cooked, just like the way we do for Dal Tadka.
6. Peel the skin from the roasted and smoked eggplant.
7. Chop the cooked eggplant finely or you can even mash it.
8. In a kadai or pan, heat oil. Then add finely chopped onions and garlic.
9. Saute the onions till translucent. Don''t brown them.
10. Add chopped green chilies and saute for a minute.
11. Add the chopped tomatoes and mix it well.
12. Bhuno (saute) the tomatoes till the oil starts separating from the mixture.
13. Now add the red chili powder. Stir and mix well.
14. Add the chopped cooked baingan.
15. Stir and mix the chopped baingan very well with the onion­tomato masala mixture.
16. Season with salt. Stir and saute for some more 4 to 5 minutes more.
17. Finally stir in the coriander leaves with the baingan bharta or garnish it with them. Serve Baingan Bharta with
phulkas, rotis or chapatis. It goes well even with bread, toasted or grilled bread and plain rice or jeera rice.', 1, 9)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (121, N'Fish pie', 0, N'British', N'01.Put the potatoes in a large pan of cold salted water and bring to the boil. Lower the heat, cover, then simmer gently for 15 minutes until tender. Drain, then return to the pan over a low heat for 30 seconds to drive off any excess water. Mash with 1 tbsp olive oil, then season.
02.Meanwhile put the milk in a large sauté pan, add the fish and bring to the boil. Remove from the heat, cover and stand for 3 minutes. Remove the fish (reserving the milk) and pat dry with kitchen paper, then gently flake into an ovenproof dish, discarding the skin and any bones.
03.Heat the remaining oil in a pan, stir in the flour and cook for 30 seconds. Gradually stir in 200-250ml of the reserved milk (discard the rest). Grate in nutmeg, season, then bubble until thick. Stir in the cream.
04.Preheat the oven to 190°C/fan170°C/gas 5. Grate the artichokes and add to the dish with the leek, prawns and herbs. Stir the lemon zest and juice into the sauce, then pour over. Mix gently with a wooden spoon.
05.Spoon the mash onto the fish mixture, then use a fork to make peaks, which will crisp and brown as it cooks. Sprinkle over the cheese, then bake for 35-40 minutes until golden and bubbling. Serve with wilted greens.', 1, 7)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (122, N'Spaghetti alla Carbonara', 0, N'Italian', N'STEP 1
Put a large saucepan of water on to boil.

STEP 2
Finely chop the 100g pancetta, having first removed any rind. Finely grate 50g pecorino cheese and 50g parmesan and mix them together.

STEP 3
Beat the 3 large eggs in a medium bowl and season with a little freshly grated black pepper. Set everything aside.

STEP 4
Add 1 tsp salt to the boiling water, add 350g spaghetti and when the water comes back to the boil, cook at a constant simmer, covered, for 10 minutes or until al dente (just cooked).

STEP 5
Squash 2 peeled plump garlic cloves with the blade of a knife, just to bruise it.

STEP 6
While the spaghetti is cooking, fry the pancetta with the garlic. Drop 50g unsalted butter into a large frying pan or wok and, as soon as the butter has melted, tip in the pancetta and garlic.

STEP 7
Leave to cook on a medium heat for about 5 minutes, stirring often, until the pancetta is golden and crisp. The garlic has now imparted its flavour, so take it out with a slotted spoon and discard.

STEP 8
Keep the heat under the pancetta on low. When the pasta is ready, lift it from the water with a pasta fork or tongs and put it in the frying pan with the pancetta. Don’t worry if a little water drops in the pan as well (you want this to happen) and don’t throw the pasta water away yet.

STEP 9
Mix most of the cheese in with the eggs, keeping a small handful back for sprinkling over later.

STEP 10
Take the pan of spaghetti and pancetta off the heat. Now quickly pour in the eggs and cheese. Using the tongs or a long fork, lift up the spaghetti so it mixes easily with the egg mixture, which thickens but doesn’t scramble, and everything is coated.

STEP 11
Add extra pasta cooking water to keep it saucy (several tablespoons should do it). You don’t want it wet, just moist. Season with a little salt, if needed.

STEP 12
Use a long-pronged fork to twist the pasta on to the serving plate or bowl. Serve immediately with a little sprinkling of the remaining cheese and a grating of black pepper. If the dish does get a little dry before serving, splash in some more hot pasta water and the glossy sauciness will be revived.', 1, 8)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (123, N'Croatian lamb peka', 0, N'Croatian', N'Preheat oven to 200°C fan / 220°C / 425°F / Gas mark 7
If you have not bought diced lamb, cut your lamb shoulder or leg into large chunks and place to one side.
Chunks of chopped lamb of a red chopping board
Make oil marinade -
Mix 80ml of olive oil in a bowl with garlic puree, sundried tomato puree ,black pepper and salt.
olive oil, gia sundried tomato puree and gia garlic puree and black pepper mixed together in a silver bowl to make Croatian peka
Add potatoes and vegetables into a large lidded casserole dish.
Chopped up vegetables which consist of chopped up red onion, courgette, potatoes red peppers in a cast iron pan
Place diced lamb on top of the vegetables, pour the marinade and wine over the top.
Chunks of lamb covered in in a sundried tomato oil sauce which is on top of chopped red onion, aubergine, courgette and potatoes in a cast iron pan
Add the rosemary, thyme and sage, trying to keep the herbs on top.
So you can easily remove the herb stalks once cooked.
Chunks of lamb coated in a sundried tomato oil sauce and covered with thyme, rosemary and sage which is on top of chopped red onion, aubergine, courgette and potatoes in a cast iron pan
Place lid on the casserole dish and cook for 1hr 30 minute
If you do not have a lid cover very well with kitchen foil
Cast iron dish with lid on in the oven
Take the lid off, remove any thick herb stems. Stir in 2 tbsp of olive oil.
Cook for a further 20-30 mins.
Cooked Croatian Lamb Peka in a cast iron pan in the oven
Serve with fresh homemade bread to dip into the juices.', 1, 2)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (124, N'Egg Drop Soup', 0, N'Chinese', N'In a wok add chicken broth and wait for it to boil.
Next add salt, sugar, white pepper, sesame seed oil.
When the chicken broth is boiling add the vegetables to the wok.
To thicken the sauce, whisk together 1 Tablespoon of cornstarch and 2 Tablespoon of water in a bowl and slowly add to your soup until it''s the right thickness.
Next add 1 egg slightly beaten with a knife or fork and add it to the soup slowly and stir for 8 seconds
Serve the soup in a bowl and add the green onions on top.', 1, 9)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (125, N'Japanese gohan rice', 0, N'Japanese', N'STEP 1
Rinsing and soaking your rice is key to achieving the perfect texture. Measure the rice into a bowl, cover with cold water, then use your fingers to massage the grains of rice – the water will become cloudy. Drain and rinse again with fresh water. Repeat five more times until the water stays clear.

STEP 2
Tip the rinsed rice into a saucepan with 400ml water, or 200ml dashi and 200ml water, bring to the boil, then turn down the heat to a low simmer, cover with a tight-fitting lid with a steam hole and cook for 15 mins. Remove from the heat and leave to sit for another 15 mins, then stir through the mirin. Remove the lid and give it a good stir. Serve with any or all of the optional toppings.', 1, 5)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (126, N'Koshari', 0, N'Egyptian', N'Cook the lentils. Bring lentils and 4 cups of water to a boil in a medium pot or saucepan over high heat. Reduce the heat to low and cook until lentils are just tender (15-17 minutes). Drain from water and season with a little salt. (Note: when the lentils are ready, they should not be fully cooked. They should be only par-cooked and still have a bite to them as they need to finish cooking with the rice).
Now, for the rice. Drain the rice from its soaking water. Combine the par-cooked lentils and the rice in the saucepan over medium-high heat with 1 tbsp cooking oil, salt, pepper, and coriander. Cook for 3 minutes, stirring regularly. Add warm water to cover the rice and lentil mixture by about 1 1/2 inches (you’ll probably use about 3 cups of water here). Bring to a boil; the water should reduce a bit. Now cover and cook until all the liquid has been absorbed and both the rice and lentils are well cooked through (about 20 minutes).  Keep covered and undisturbed for 5 minutes or so.
Now make the pasta. While the rice and lentils are cooking, make the pasta according to package instructions by adding the elbow pasta to boiling water with a dash of salt and a little oil. Cook until the pasta is al dente. Drain.
Cover the chickpeas and warm in the microwave briefly before serving.

Make the crispy onion topping. 

Sprinkle the onion rings with salt, then toss them in the flour to coat. Shake off excess flour.
In a large skillet, heat the cooking oil over medium-high heat, cook the onion rings, stirring often, until they turn a nice caramelized brown. Onions must be crispy, but not burned (15-20 minutes).', 1, 9)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (127, N'Braised Beef Chilli', 0, N'Mexican', N'Preheat the oven to 120C/225F/gas mark 1.

Take the meat out of the fridge to de-chill. Pulse the onions and garlic in a food processor until finely chopped. Heat 2 tbsp olive oil in a large casserole and sear the meat on all sides until golden.

Set to one side and add another small slug of oil to brown the chorizo. Remove and add the onion and garlic, spices, herbs and chillies then cook until soft in the chorizo oil. Season with salt and pepper and add the vinegar, tomatoes, ketchup and sugar.

Put all the meat back into the pot with 400ml water (or red wine if you prefer), bring up to a simmer and cook, covered, in the low oven.

After 2 hours, check the meat and add the beans. Cook for a further hour and just before serving, pull the meat apart with a pair of forks.', 1, 2)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (128, N'Vegetarian Casserole', 0, N'British', N'Heat the oil in a large, heavy-based pan. Add the onions and cook gently for 5 – 10 mins until softened.
Add the garlic, spices, dried thyme, carrots, celery and peppers and cook for 5 minutes.
Add the tomatoes, stock, courgettes and fresh thyme and cook for 20 - 25 minutes.
Take out the thyme sprigs. Stir in the lentils and bring back to a simmer. Serve with wild and white basmati rice, mash or quinoa.', 1, 9)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (129, N'Pierogi (Polish Dumplings)', 0, N'Polish', N'To prepare the sauerkraut filling, melt the butter in a skillet over medium heat. Stir in the onion, and cook until translucent, about 5 minutes. Add the drained sauerkraut and cook for an additional 5 minutes. Season to taste with salt and pepper, then remove to a plate to cool.

For the mashed potato filling, melt the butter in a skillet over medium heat. Stir in the onion, and cook until translucent, about 5 minutes. Stir into the mashed potatoes, and season with salt and white pepper.

To make the dough, beat together the eggs and sour cream until smooth. Sift together the flour, salt, and baking powder; stir into the sour cream mixture until dough comes together. Knead the dough on a lightly floured surface until firm and smooth. Divide the dough in half, then roll out one half to 1/8 inch thickness. Cut into 3 inch rounds using a biscuit cutter.

Place a small spoonful of the mashed potato filling into the center of each round. Moisten the edges with water, fold over, and press together with a fork to seal. Repeat procedure with the remaining dough and the sauerkraut filling.

Bring a large pot of lightly salted water to a boil. Add perogies and cook for 3 to 5 minutes or until pierogi float to the top. Remove with a slotted spoon.', 1, 5)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (130, N'Vegan Lasagna', 0, N'Italian', N'1) Preheat oven to 180 degrees celcius. 
2) Boil vegetables for 5-7 minutes, until soft. Add lentils and bring to a gentle simmer, adding a stock cube if desired. Continue cooking and stirring until the lentils are soft, which should take about 20 minutes. 
3) Blanch spinach leaves for a few minutes in a pan, before removing and setting aside. 
4) Top up the pan with water and cook the lasagne sheets. When cooked, drain and set aside.
5) To make the sauce, melt the butter and add the flour, then gradually add the soya milk along with the mustard and the vinegar. Cook and stir until smooth and then assemble the lasagne as desired in a baking dish. 
6) Bake in the preheated oven for about 25 minutes.', 1, 3)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (131, N'Poutine', 0, N'Canadian', N'Heat oil in a deep fryer or deep heavy skillet to 365°F (185°C).
Warm gravy in saucepan or microwave.
Place the fries into the hot oil, and cook until light brown, about 5 minutes.
Remove to a paper towel lined plate to drain.
Place the fries on a serving platter, and sprinkle the cheese over them.
Ladle gravy over the fries and cheese, and serve immediately.', 1, 4)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (132, N'Roasted Eggplant With Tahini, Pine Nuts, and Lentils', 0, N'American', N'
For the Lentils: Adjust oven rack to center position and preheat oven to 450°F to prepare for roasting eggplant. Meanwhile, heat 2 tablespoons olive oil in a medium saucepan over medium heat until shimmering. Add carrots, celery, and onion and cook, stirring, until softened but not browned, about 4 minutes. Add garlic and cook, stirring, until fragrant, about 30 seconds. Add lentils, bay leaves, stock or water, and a pinch of salt. Bring to a simmer, cover with the lid partially ajar, and cook until lentils are tender, about 30 minutes. (Top up with water if lentils are at any point not fully submerged.) Remove lid, stir in vinegar, and reduce until lentils are moist but not soupy. Season to taste with salt and pepper, cover, and keep warm until ready to serve.

2.
For the Eggplant: While lentils cook, cut each eggplant in half. Score flesh with the tip of a paring knife in a cross-hatch pattern at 1-inch intervals. Transfer to a foil-lined rimmed baking sheet, cut side up, and brush each eggplant half with 1 tablespoon oil, letting each brushstroke be fully absorbed before brushing with more. Season with salt and pepper. Place a rosemary sprig on top of each one. Transfer to oven and roast until completely tender and well charred, 25 to 35 minutes. Remove from oven and discard rosemary.

3.
To Serve: Heat 2 tablespoons olive oil and pine nuts in a medium skillet set over medium heat. Cook, tossing nuts frequently, until golden brown and aromatic, about 4 minutes. Transfer to a bowl to halt cooking. Stir half of parsley and rosemary into lentils and transfer to a serving platter. Arrange eggplant halves on top. Spread a few tablespoons of tahini sauce over each eggplant half and sprinkle with pine nuts. Sprinkle with remaining parsley and rosemary, drizzle with additional olive oil, and serve.', 1, 9)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (133, N'Bitterballen (Dutch meatballs)', 0, N'Dutch', N'Melt the butter in a skillet or pan. When melted, add the flour little by little and stir into a thick paste. Slowly stir in the stock, making sure the roux absorbs the liquid. Simmer for a couple of minutes on a low heat while you stir in the onion, parsley and the shredded meat. The mixture should thicken and turn into a heavy, thick sauce.

Pour the mixture into a shallow container, cover and refrigerate for several hours, or until the sauce has solidified.

Take a heaping tablespoon of the cold, thick sauce and quickly roll it into a small ball. Roll lightly through the flour, then the egg and finally the breadcrumbs. Make sure that the egg covers the whole surface of the bitterbal. When done, refrigerate the snacks while the oil in your fryer heats up to 190C (375F). Fry four bitterballen at a time, until golden.

Serve on a plate with a nice grainy or spicy mustard. 
', 1, 2)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (134, N'Brie wrapped in prosciutto & brioche', 0, N'French', N'Mix the flour, 1 tsp salt, caster sugar, yeast, milk and eggs together in a mixer using the dough attachment for 5 mins until the dough is smooth. Add the butter and mix for a further 4 mins on medium speed. Scrape the dough bowl and mix again for 1 min. Place the dough in a container, cover with cling film and leave in the fridge for at least 6 hrs before using.
Wrap the Brie in the prosciutto and set aside. Turn out the dough onto a lightly floured surface. Roll into a 25cm circle. Place the wrapped Brie in the middle of the circle and fold the edges in neatly. Put the parcel onto a baking tray lined with baking parchment and brush with beaten egg. Chill in the fridge for 30 mins, then brush again with beaten egg and chill for a further 30 mins. Leave to rise for 1 hr at room temperature. Heat oven to 200C/180C fan/gas 6, then bake for 22 mins. Serve warm.', 1, 5)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (135, N'Minced Beef Pie', 0, N'British', N'Preheat the oven to 200C/400F/Gas 6.
Heat the oil in a deep frying pan and fry the beef mince for 4-5 minutes, breaking it up with a wooden spoon as it browns.
Add the onion and cook for 2-3 minutes, then stir in the tomato purée and cook for 2-3 more minutes. Stir in the flour and cook for a further minute, then add the chopped mushrooms, the stout or beef stock and a couple of dashes of Worcestershire sauce. Bring to the boil, then reduce the heat, cover the pan with a lid and leave to simmer for 20 minutes. Set aside and leave to cool, then turn the meat mixture into a one litre pie dish.
Roll out the pastry on a floured work surface until it is slightly larger than the pie dish. Gently drape the pastry over the dish, pressing firmly onto the edges. Trim, then shape the edges into a fluted shape.
Cut some leaf shapes out of the pastry trimmings and decorate the top of the pie, sticking them to the pastry with the beaten egg yolk.
Make three or four slits in the pastry to allow the steam to escape, then brush the pie with the rest of the beaten egg yolk and bake in the oven for 20-25 minutes, or until golden-brown.
To serve, slice into wedges.', 1, 2)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (136, N'Beef Brisket Pot Roast', 0, N'American', N'1 Prepare the brisket for cooking: On one side of the brisket there should be a layer of fat, which you want. If there are any large chunks of fat, cut them off and discard them. Large pieces of fat will not be able to render out completely.
Using a sharp knife, score the fat in parallel lines, about 3/4-inch apart. Slice through the fat, not the beef. Repeat in the opposite direction to make a cross-hatch pattern.
Salt the brisket well and let it sit at room temperature for 30 minutes.
 
2 Sear the brisket: You''ll need an oven-proof, thick-bottomed pot with a cover, or Dutch oven, that is just wide enough to hold the brisket roast with a little room for the onions.
Pat the brisket dry and place it, fatty side down, into the pot and place it on medium high heat. Cook for 5-8 minutes, lightly sizzling, until the fat side is nicely browned. (If the roast seems to be cooking too fast, turn the heat down to medium. You want a steady sizzle, not a raging sear.)
Turn the brisket over and cook for a few minutes more to brown the other side.

3 Sauté the onions and garlic: When the brisket has browned, remove it from the pot and set aside. There should be a couple tablespoons of fat rendered in the pot, if not, add some olive oil.
Add the chopped onions and increase the heat to high. Sprinkle a little salt on the onions. Sauté, stirring often, until the onions are lightly browned, 5-8 minutes. Stir in the garlic and cook 1-2 more minutes.
 
4 Return brisket to pot, add herbs, stock, bring to simmer, cover, cook in oven: Preheat the oven to 300°F. Use kitchen twine to tie together the bay leaves, rosemary and thyme.
Move the onions and garlic to the sides of the pot and nestle the brisket inside. Add the beef stock and the tied-up herbs. Bring the stock to a boil on the stovetop.
Cover the pot, place the pot in the 300°F oven and cook for 3 hours. Carefully flip the brisket every hour so it cooks evenly.
 
5 Add carrots, continue to cook: After 3 hours, add the carrots. Cover the pot and cook for 1 hour more, or until the carrots are cooked through and the brisket is falling-apart tender.
6 Remove brisket to cutting board, tent with foil: When the brisket is falling-apart tender, take the pot out of the oven and remove the brisket to a cutting board. Cover it with foil. Pull out and discard the herbs.
7 Make sauce (optional): At this point you have two options. You can serve as is, or you can make a sauce with the drippings and some of the onions. If you serve as is, skip this step.
To make a sauce, remove the carrots and half of the onions, set aside and cover them with foil. Pour the ingredients that are remaining into the pot into a blender, and purée until smooth. If you want, add 1 tablespoon of mustard to the mix. Put into a small pot and keep warm.
8 Slice the meat across the grain: Notice the lines of the muscle fibers of the roast. This is the "grain" of the meat. Slice the meat perpendicular to these lines, or across the grain (cutting this way further tenderizes the meat), in 1/4-inch to 1/2-inch slices.
Serve with the onions, carrots and gravy. Serve with mashed, roasted or boiled potatoes, egg noodles or polenta.', 1, 2)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (137, N'Lamb and Lemon Souvlaki', 0, N'Greek', N'Pound the garlic with sea salt in a pestle and mortar (or use a small food processor), until the garlic forms a paste. Whisk together the oil, lemon juice, zest, dill and garlic. Mix in the lamb and combine well. Cover and marinate for at least 2 hrs or overnight in the fridge. If you’re going to use bamboo skewers, soak them in cold water.

If you’ve prepared the lamb the previous day, take it out of the fridge 30 mins before cooking. Thread the meat onto the soaked or metal skewers. Heat the grill to high or have a hot griddle pan or barbecue ready. Cook the skewers for 2-3 mins on each side, basting with the remaining marinade. Heat the pitta or flatbreads briefly, then stuff with the souvlaki. Add Greek salad (see ''Goes well with'', right) and Tzatziki (below), if you like.', 1, 11)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (138, N'Chickpea Fajitas', 0, N'Mexican', N'Heat oven to 200C/180C fan/gas 6 and line a baking tray with foil. Drain the chickpeas, pat dry and tip onto the prepared baking tray. Add the oil and paprika, toss to coat, then roast for 20-25 mins until browned and crisp, shaking halfway through cooking.

Meanwhile, put the tomatoes and onion in a small bowl with the vinegar and set aside to pickle. Put the avocado in another bowl and mash with a fork, leaving some larger chunks. Stir in the lime juice and season well. Mix the soured cream with the harissa and set aside until ready to serve.

Heat a griddle pan until nearly smoking. Add the tortillas , one at a time, charring each side until hot with griddle lines. 

Put everything on the table and build the fajitas : spread a little of the harissa cream over the tortilla, top with roasted chickpeas, guacamole, pickled salsa and coriander, if you like. Serve with the lime wedges for squeezing over.', 1, 9)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (139, N'Pilchard puttanesca', 0, N'Italian', N'Cook the pasta following pack instructions. Heat the oil in a non-stick frying pan and cook the onion, garlic and chilli for 3-4 mins to soften. Stir in the tomato purée and cook for 1 min, then add the pilchards with their sauce. Cook, breaking up the fish with a wooden spoon, then add the olives and continue to cook for a few more mins.

Drain the pasta and add to the pan with 2-3 tbsp of the cooking water. Toss everything together well, then divide between plates and serve, scattered with Parmesan.', 1, 8)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (140, N'Beef Bourguignon', 0, N'French', N'Heat a large casserole pan and add 1 tbsp goose fat. Season the beef and fry until golden brown, about 3-5 mins, then turn over and fry the other side until the meat is browned all over, adding more fat if necessary. Do this in 2-3 batches, transferring the meat to a colander set over a bowl when browned.
In the same pan, fry the bacon, shallots or pearl onions, mushrooms, garlic and bouquet garni until lightly browned. Mix in the tomato purée and cook for a few mins, stirring into the mixture. This enriches the bourguignon and makes a great base for the stew. Then return the beef and any drained juices to the pan and stir through.
Pour over the wine and about 100ml water so the meat bobs up from the liquid, but isn’t completely covered. Bring to the boil and use a spoon to scrape the caramelised cooking juices from the bottom of the pan – this will give the stew more flavour.
Heat oven to 150C/fan 130C/gas 2. Make a cartouche: tear off a square of foil slightly larger than the casserole, arrange it in the pan so it covers the top of the stew and trim away any excess foil. Then cook for 3 hrs. If the sauce looks watery, remove the beef and veg with a slotted spoon, and set aside. Cook the sauce over a high heat for a few mins until the sauce has thickened a little, then return the beef and vegetables to the pan.
To make the celeriac mash, peel the celeriac and cut into cubes. Heat the olive oil in a large frying pan. Tip in the celeriac and fry for 5 mins until it turns golden. Season well with salt and pepper. Stir in the rosemary, thyme, bay and cardamom pods, then pour over 200ml water, enough to nearly cover the celeriac. Turn the heat to low, partially cover the pan and leave to simmer for 25-30 mins.
After 25-30 mins, the celeriac should be soft and most of the water will have evaporated. Drain away any remaining water, then remove the herb sprigs, bay and cardamom pods. Lightly crush with a potato masher, then finish with a glug of olive oil and season to taste. Spoon the beef bourguignon into serving bowls and place a large spoonful of the celeriac mash on top. Garnish with one of the bay leaves, if you like.', 1, 2)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (141, N'Leblebi Soup', 0, N'Tunisian', N'Heat the oil in a large pot. Add the onion and cook until translucent.
Drain the soaked chickpeas and add them to the pot together with the vegetable stock. Bring to the boil, then reduce the heat and cover. Simmer for 30 minutes.
In the meantime toast the cumin in a small ungreased frying pan, then grind them in a mortar. Add the garlic and salt and pound to a fine paste.
Add the paste and the harissa to the soup and simmer until the chickpeas are tender, about 30 minutes.
Season to taste with salt, pepper and lemon juice and serve hot.', 1, 9)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (142, N'Kafteji', 0, N'Tunisian', N'Peel potatoes and cut into 5cm cubes.
Pour 1-2 cm of olive oil into a large pan and heat up very hot. Fry potatoes until golden brown for 20 minutes, turning from time to time. Place on kitchen paper to drain.
Cut the peppers in half and remove seeds. Rub a little olive oil on them and place the cut side down on a baking tray. Place them under the grill. Grill until the skin is dark and bubbly. While the peppers are still hot, put them into a plastic sandwich bag and seal it. Take them out after 15 minutes and remove skins.
In the meantime, heat more olive oil another pan. Peel the onions and cut into thin rings. Fry for 15 minutes until golden brown, turning them often. Add the Ras el hanout at the end.
Cut the pumpkin into 5cm cubes and fry in the same pan you used for the potatoes for 10-15 minutes until it is soft and slightly browned. Place on kitchen paper.
Pour the remaining olive oil out of the pan and put all the cooked vegetables into the pan and mix. Whisk eggs and pour them over the vegetables. Put the lid on the pan so that the eggs cook. Put the contents of the pan onto a large chopping board, add salt and pepper and chopped and mix everything with a big knife.', 1, 9)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (143, N'Portuguese fish stew (Caldeirada de peixe)', 0, N'Portuguese', N'STEP 1

Heat a drizzle of oil in a large, deep-sided frying pan, and fry the onion and pepper on a medium heat until softened but not browned. Finely chop the coriander stalks (keep the leaves for later), and add to the pan with the chilli and chopped garlic. Fry for another few minutes. Add the wine, saffron and bay leaf and let it simmer until reduced by half.

STEP 2

Add the potatoes, tomatoes, and 300ml water and bring to a gentle boil. Break up the tomatoes with a spoon on the side of the pan and simmer for 20-25 minutes until the potatoes are just tender, and the tomatoes have broken down.

STEP 3

Season well, then gently push the fish into the sauce, and arrange the squid, prawns, clams and mussels on the surface. Put the lid on and cook for 6-8 minutes until the mussel and clam shells have opened, the prawns are cooked and the fish is flaky. Toast the bread, rub lightly with the halved garlic clove and drizzle with olive oil. Serve the stew scatted with chopped coriander leaves, and the toasts for dunking.', 1, 7)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (144, N'Duck Confit', 0, N'French', N'The day before you want to make the dish, scatter half the salt, half the garlic and half of the herbs over the base of a small shallow dish. Lay the duck legs, skin-side up, on top, then scatter over the remaining salt, garlic and herbs. Cover the duck and refrigerate overnight. This can be done up to 2 days ahead.
Pour the wine into a saucepan that will snugly fit the duck legs in a single layer. Brush the salt off the duck legs and place them, skin-side down, in the wine. Cover the pan with a lid and place over a medium heat. As soon as the wine starts to bubble, turn the heat down to the lowest setting and cook for 2 hours, checking occasionally that the liquid is just barely simmering. (If you own a heat diffuser, it would be good to use it here.) After 2 hours, the duck legs should be submerged in their own fat and the meat should feel incredibly tender when prodded. Leave to cool.
The duck legs are now cooked and can be eaten immediately – or you can follow the next step if you like them crisp. If you are preparing ahead, pack the duck legs tightly into a plastic container or jar and pour over the fat, but not the liquid at the bottom of the pan. Cover and leave in the fridge for up to a month, or freeze for up to 3 months. The liquid you are left with makes a tasty gravy, which can be chilled or frozen until needed.
To reheat and crisp up the duck legs, heat oven to 220C/fan 200C/gas 7. Remove the legs from the fat and place them, skin-side down, in an ovenproof frying pan. Roast for 30-40 mins, turning halfway through, until brown and crisp. Serve with the reheated gravy, a crisp salad and some crisp golden ptoatoes.', 1, 4)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (145, N'Venetian Duck Ragu', 0, N'Italian', N'Heat the oil in a large pan. Add the duck legs and brown on all sides for about 10 mins. Remove to a plate and set aside. Add the onions to the pan and cook for 5 mins until softened. Add the garlic and cook for a further 1 min, then stir in the cinnamon and flour and cook for a further min. Return the duck to the pan, add the wine, tomatoes, stock, herbs, sugar and seasoning. Bring to a simmer, then lower the heat, cover with a lid and cook for 2 hrs, stirring every now and then.
Carefully lift the duck legs out of the sauce and place on a plate – they will be very tender so try not to lose any of the meat. Pull off and discard the fat, then shred the meat with 2 forks and discard the bones. Add the meat back to the sauce with the milk and simmer, uncovered, for a further 10-15 mins while you cook the pasta.
Cook the pasta following pack instructions, then drain, reserving a cup of the pasta water, and add the pasta to the ragu. Stir to coat all the pasta in the sauce and cook for 1 min more, adding a splash of cooking liquid if it looks dry. Serve with grated Parmesan, if you like.', 1, 8)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (146, N'Tonkatsu pork', 0, N'Japanese', N'STEP 1
Remove the large piece of fat on the edge of each pork loin, then bash each of the loins between two pieces of baking parchment until around 1cm in thickness – you can do this using a meat tenderiser or a rolling pin. Once bashed, use your hands to reshape the meat to its original shape and thickness – this step will ensure the meat is as succulent as possible.

STEP 2
Put the flour, eggs and panko breadcrumbs into three separate wide-rimmed bowls. Season the meat, then dip first in the flour, followed by the eggs, then the breadcrumbs.

STEP 3
In a large frying or sauté pan, add enough oil to come 2cm up the side of the pan. Heat the oil to 180C – if you don’t have a thermometer, drop a bit of panko into the oil and if it sinks a little then starts to fry, the oil is ready. Add two pork chops and cook for 1 min 30 secs on each side, then remove and leave to rest on a wire rack for 5 mins. Repeat with the remaining pork chops.

STEP 4
While the pork is resting, make the sauce by whisking the ingredients together, adding a splash of water if it’s particularly thick. Slice the tonkatsu and serve drizzled with the sauce.', 1, 8)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (147, N'Spring onion and prawn empanadas', 0, N'Portuguese', N'STEP 1

To make the dough, rub the butter into the flour and then add the egg white and half the yolk (keep the rest), vinegar, a pinch of salt and enough cold water to make a soft dough. Knead on a floured surface until smooth and then wrap and rest for 30 minutes.

STEP 2

Heat the oven to 180c/fan 160c/gas 4. Trim the green ends of the spring onions and then finely slice the rest. Heat a little oil in a pan and fry them gently until soft but not browned. Add the chilli and garlic, stir and then add the prawns and cook until they are opaque. Season well. Scoop out the prawns and bubble the juices until they thicken, then add back the prawns.

STEP 3

Divide the empanada dough into eight balls and roll out to thin circles on a floured surface. Put some filling on one half of the dough, sprinkle the feta on top and fold the other half over. Trim the edge and then fold and crimp the dough together so the empanada is tightly sealed, put it on an oiled baking sheet either on its side or sitting on its un-crimped edge like a cornish pasty. Repeat with the remaining dough and mixture. Mix the leftover egg yolk with a splash of water and brush the top of the empanadas.

STEP 4

Bake for 30 minutes or until golden and slightly crisp around the edges.', 1, 7)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (148, N'Beef Dumpling Stew', 0, N'British', N'Preheat the oven to 180C/350F/Gas 4.

For the beef stew, heat the oil and butter in an ovenproof casserole and fry the beef until browned on all sides.

Sprinkle over the flour and cook for a further 2-3 minutes.

Add the garlic and all the vegetables and fry for 1-2 minutes.

Stir in the wine, stock and herbs, then add the Worcestershire sauce and balsamic vinegar, to taste. Season with salt and freshly ground black pepper.

Cover with a lid, transfer to the oven and cook for about two hours, or until the meat is tender.

For the dumplings, sift the flour, baking powder and salt into a bowl.
Add the suet and enough water to form a thick dough.

With floured hands, roll spoonfuls of the dough into small balls.

After two hours, remove the lid from the stew and place the balls on top of the stew. Cover, return to the oven and cook for a further 20 minutes, or until the dumplings have swollen and are tender. (If you prefer your dumplings with a golden top, leave the lid off when returning to the oven.)

To serve, place a spoonful of mashed potato onto each of four serving plates and top with the stew and dumplings. Sprinkle with chopped parsley.', 1, 2)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (149, N'Jamaican Beef Patties', 0, N'Jamaican', N'Make the Pastry Dough

To a large bowl, add flour, 1 teaspoon salt, and turmeric and mix thoroughly.
Rub shortening into flour until there are small pieces of shortening completely covered with flour.
Pour in 1/2 cup of the ice water and mix with your hands to bring the dough together. Keep adding ice water 2 to 3 tablespoons at a time until the mixture forms a dough.
At this stage, you can cut the dough into 2 large pieces, wrap in plastic and refrigerate for 30 minutes before using it.
Alternatively, cut the dough into 10 to 12 equal pieces, place on a platter or baking sheet, cover securely with plastic wrap and let chill for 30 minutes while you make the filling.
Make the Filling

Add ground beef to a large bowl. Sprinkle in allspice and black pepper. Mix together and set aside.
Heat oil in a skillet until hot.
Add onions and sauté until translucent. Add hot pepper, garlic and thyme and continue to sauté for another minute. Add 1/4 teaspoon salt.
Add seasoned ground beef and toss to mix, breaking up any clumps, and let cook until the meat is no longer pink.
Add ketchup and more salt to taste.
Pour in 2 cups of water and stir. Bring the mixture to a boil then reduce heat and let simmer until most of the liquid has evaporated and whatever is remaining has reduced to a thick sauce.
Fold in green onions. Remove from heat and let cool completely.
Assemble the Patties

Beat the egg and water together to make an egg wash. Set aside.
Now you can prepare the dough in two ways.
First Method: Flour the work surface and rolling pin. If you had cut it into 2 large pieces, then take one of the large pieces and roll it out into a very large circle. Take a bowl with a wide rim (about 5 inches) and cut out three circles.

Place about 3 heaping tablespoons of the filling onto 1/2 of each circle. Dip a finger into the water and moisten the edges of the pastry. Fold over the other half and press to seal. 

Take a fork and crimp the edges. Cut off any extra to make it look neat and uniform. Place on a parchment-lined baking sheet and continue to work until you have rolled all the dough and filled the patties.
Second Method: If you had pre-cut the dough into individual pieces, work with one piece of dough at a time. Roll it out on a floured surface into a 5-inch circle or a little larger. Don’t worry if the edges are not perfect.

Place 3 heaping tablespoons of the filling on one side of the circle. Dip a finger into the water and moisten the edges of the pastry. Fold over the other half and press to seal.

Take a fork and crimp the edges. Cut off any extra to make it look neat and uniform. Place on a parchment-lined baking sheet and continue work until you have rolled all the dough and filled the patties.

Frying and Serving the Patties

After forming the patties, place the pans in the refrigerator while you heat the oven to 350 F.
Just before adding the pans with the patties to the oven, brush the patties with egg wash.
Bake patties for 30 minutes or until golden brown.
Cool on wire racks.
Serve warm.', 1, 2)
INSERT INTO [dbo].[Recipe] ([Id], [Title], [Custom], [Region], [HowTo], [Wanted], [Category]) VALUES (150, N'Fish Stew with Rouille', 0, N'French', N'Twist the heads from the prawns, then peel away the legs and shells, but leave the tails intact. Devein each prawn. Fry the shells in 1 tbsp oil for 5 mins, until dark pink and golden in patches. Add the wine, boil down by two thirds, then pour in the stock. Strain into a jug, discarding the shells.
Heat the rest of the oil in a deep frying pan or casserole. Add the fennel, onion and garlic, season, then cover and gently cook for 10 mins until softened. Meanwhile, peel the potato and cut into 2cm-ish chunks. Put into a pan of cold water, bring to the boil and cook for 5 mins until almost tender. Drain in a colander.
Peel a strip of zest from the orange. Put the zest, star anise, bay and ½ tsp harissa into the pan. Fry gently, uncovered, for 5-10 mins, until the vegetables are soft, sweet and golden.
Stir in the tomato purée, cook for 2 mins, then add the tomatoes and stock. Simmer for 10 mins until the sauce thickens slightly. Season to taste. The sauce can be made ahead, then reheated later in the day. Meantime, scrub the mussels or clams and pull away any stringy beards. Any that are open should be tapped sharply on the worktop – if they don’t close after a few seconds, discard them.
Reheat the sauce if necessary, then stir the potato, chunks of fish and prawns very gently into the stew. Bring back to the boil, then cover and gently simmer for 3 mins. Scatter the mussels or clams over the stew, then cover and cook for 2 mins more or until the shells have opened wide. Discard any that remain closed. The chunks of fish should flake easily and the prawns should be pink through. Scatter with the thyme leaves.
To make the quick rouille, stir the rest of the harissa through the mayonnaise. Serve the stew in bowls, topped with spoonfuls of rouille, which will melt into the sauce and enrich it. Have some good bread ready, as you’ll definitely want to mop up the juices.', 1, 7)
SET IDENTITY_INSERT [dbo].[Recipe] OFF
SET IDENTITY_INSERT [dbo].[RecipeIngredient] ON
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (1, 1, 1, 2, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (2, 1, 2, 1, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (3, 1, 3, 0.5, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (4, 1, 4, 0.5, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (5, 1, 5, 0.5, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (6, 1, 6, 4, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (7, 1, 7, 2, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (8, 1, 8, 340, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (9, 1, 9, 7, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (10, 2, 10, 6, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (11, 2, 11, 16, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (12, 2, 12, 1.5, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (13, 2, 13, 6, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (14, 2, 14, 8, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (15, 2, 15, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (16, 2, 16, 1.5, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (17, 2, 17, 1.5, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (18, 2, 18, 1.5, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (19, 2, 19, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (20, 2, 20, 1, N'can')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (21, 2, 21, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (22, 2, 2, 2.5, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (23, 3, 22, 4, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (24, 3, 23, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (25, 3, 24, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (26, 3, 25, 100, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (27, 3, 26, 230, N'ml')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (28, 3, 27, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (29, 3, 28, 2, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (30, 3, 29, 5, N'cloves')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (31, 3, 30, 2, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (32, 3, 31, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (33, 3, 32, 4, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (34, 3, 33, 600, N'ml')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (35, 3, 34, 2, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (36, 3, 1, 4, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (37, 3, 35, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (38, 3, 36, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (39, 4, 37, 1.5, N'kg')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (40, 4, 48, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (41, 4, 47, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (42, 4, 46, 4, N'leaves')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (43, 4, 45, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (44, 4, 44, 2, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (45, 4, 43, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (46, 4, 49, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (47, 4, 42, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (48, 4, 40, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (49, 4, 17, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (50, 4, 39, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (51, 4, 12, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (52, 4, 29, 2, N'cloves')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (53, 4, 38, 3, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (54, 4, 41, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (55, 4, 50, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (56, 5, 51, 1364, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (57, 5, 52, 10, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (58, 5, 44, 5, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (59, 5, 46, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (60, 6, 53, 397, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (61, 6, 54, 7, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (62, 6, 55, 6, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (63, 6, 7, 2, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (64, 7, 56, 3, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (65, 7, 57, 1, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (66, 7, 58, 1, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (67, 7, 59, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (68, 7, 60, 2, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (69, 7, 61, 1, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (70, 7, 62, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (71, 7, 2, 1, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (72, 8, 63, 227, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (73, 8, 75, 0.5, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (74, 8, 74, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (75, 8, 2, 2.5, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (76, 8, 73, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (77, 8, 72, 2.5, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (78, 8, 71, 2.5, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (79, 8, 70, 2, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (80, 8, 44, 1, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (81, 8, 69, 2, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (82, 8, 29, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (83, 8, 12, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (84, 8, 42, 4, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (85, 8, 68, 3, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (86, 8, 67, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (87, 8, 66, 1, N'pinch')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (88, 8, 65, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (89, 8, 64, 0.5, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (90, 8, 21, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (91, 8, 1, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (92, 9, 76, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (93, 9, 28, 2, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (94, 9, 33, 38, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (95, 9, 22, 1.5, N'kg')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (96, 9, 77, 4, N'kg')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (97, 9, 64, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (98, 9, 78, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (99, 10, 79, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (100, 10, 69, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (101, 10, 29, 1, N'clove')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (102, 10, 80, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (103, 10, 81, 3, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (104, 10, 82, 500, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (105, 10, 83, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (106, 10, 25, 85, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (107, 10, 84, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (108, 10, 85, 800, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (109, 10, 86, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (110, 11, 87, 450, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (111, 11, 12, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (112, 11, 29, 1, N'clove')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (113, 11, 1, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (114, 11, 88, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (115, 11, 89, 2, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (116, 11, 90, 1, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (117, 11, 26, 1, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (118, 11, 91, 1, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (119, 12, 92, 450, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (120, 12, 79, 4, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (121, 12, 69, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (122, 12, 18, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (123, 12, 44, 2, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (124, 12, 93, 150, N'ml')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (125, 12, 94, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (126, 12, 95, 400, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (127, 12, 96, 1, N'l')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (128, 12, 40, 2, N'pinches')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (129, 12, 97, 150, N'ml')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (130, 12, 98, 8, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (131, 13, 99, 2, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (132, 13, 81, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (133, 13, 108, 12, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (134, 13, 75, 1, N'dash')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (135, 13, 107, 0.125, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (136, 13, 40, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (137, 13, 106, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (138, 13, 105, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (139, 13, 35, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (140, 13, 104, 0.5, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (141, 13, 103, 1, N'jar')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (142, 13, 46, 9.5, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (143, 13, 72, 3.5, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (144, 13, 69, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (145, 13, 29, 3, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (146, 13, 102, 33, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (147, 13, 101, 455, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (148, 13, 100, 455, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (149, 13, 109, 2.5, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (150, 13, 80, 1, N'dash')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (151, 14, 110, 455, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (152, 14, 79, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (153, 14, 1, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (154, 14, 88, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (155, 14, 111, 4, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (156, 15, 110, 400, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (157, 15, 112, 3, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (158, 15, 113, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (159, 15, 114, 400, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (160, 15, 115, 4, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (161, 15, 116, 1, N'zest')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (162, 15, 34, 2, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (163, 15, 79, 3, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (164, 16, 117, 800, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (165, 16, 76, 50, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (166, 16, 13, 3, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (167, 16, 46, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (168, 16, 118, 8, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (169, 16, 97, 100, N'ml')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (170, 16, 119, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (171, 16, 120, 180, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (172, 16, 83, 4, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (173, 17, 46, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (174, 17, 76, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (175, 17, 69, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (176, 17, 121, 455, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (177, 17, 122, 227, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (178, 17, 123, 3.5, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (179, 17, 29, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (180, 17, 64, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (181, 17, 78, 0.25, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (182, 17, 81, 3, N'cans')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (183, 18, 124, 0.5, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (184, 18, 125, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (185, 18, 39, 0.5, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (186, 18, 64, 0.25, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (187, 18, 126, 8, N'slices')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (188, 18, 99, 8, N'slices')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (189, 18, 127, 8, N'slices')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (190, 18, 128, 4, N'slices')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (191, 18, 76, 2.5, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (192, 19, 76, 1, N' tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (193, 19, 99, 4, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (194, 19, 69, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (195, 19, 13, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (196, 19, 129, 20, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (197, 19, 77, 400, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (198, 20, 72, 30.5, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (199, 20, 130, 1, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (200, 20, 131, 1.5, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (201, 20, 101, 1, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (202, 20, 33, 6, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (203, 20, 64, 0.5, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (204, 20, 21, 0.25, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (205, 20, 65, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (206, 20, 66, 0.25, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (207, 20, 75, 0.5, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (208, 20, 132, 3.5, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (209, 20, 1, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (210, 20, 6, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (211, 20, 2, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (212, 20, 118, 0.5, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (213, 21, 22, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (214, 21, 133, 0.5, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (215, 21, 24, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (216, 21, 134, 0.5, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (217, 21, 102, 1, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (218, 21, 135, 1, N' tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (219, 21, 40, 0.5, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (220, 21, 64, 0.5, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (221, 21, 78, 0.25, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (222, 21, 136, 0.25, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (223, 21, 137, 0.25, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (224, 21, 14, 0.5, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (225, 21, 79, 2.5, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (226, 21, 138, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (227, 22, 2, 2, N'l')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (228, 22, 139, 300, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (229, 22, 101, 100, N'g ')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (230, 22, 140, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (231, 22, 71, 2, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (232, 22, 44, 2, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (233, 22, 77, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (234, 22, 69, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (235, 22, 141, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (236, 22, 142, 2.5, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (237, 22, 143, 455, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (238, 23, 144, 8, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (239, 23, 79, 2, N' tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (240, 23, 29, 3, N' cloves')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (241, 23, 40, 1, N' tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (242, 23, 91, 0.5, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (243, 23, 145, 4, N' sprigs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (244, 23, 38, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (245, 24, 88, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (246, 24, 1, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (247, 24, 65, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (248, 24, 146, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (249, 24, 2, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (250, 24, 37, 500, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (251, 24, 147, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (252, 24, 148, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (253, 24, 3, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (254, 24, 118, 4, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (255, 24, 13, 6, N'cloves')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (256, 24, 149, 220, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (257, 24, 150, 100, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (258, 25, 77, 5, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (259, 25, 44, 5455, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (260, 25, 151, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (261, 25, 29, 2, N' cloves')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (262, 25, 126, 1, N'slice')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (263, 25, 136, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (264, 25, 1, 2, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (265, 25, 121, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (266, 25, 26, 1, N' tsp ')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (267, 25, 21, 2, N' tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (268, 25, 76, 2, N' tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (269, 26, 37, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (270, 26, 156, 0.5, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (271, 26, 155, 0.5, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (272, 26, 136, 0.5, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (273, 26, 154, 0.5, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (274, 26, 137, 0.5, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (275, 26, 78, 1, N' tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (276, 26, 105, 0.5, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (277, 26, 153, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (278, 26, 40, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (279, 26, 64, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (280, 26, 3, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (281, 26, 102, 3.5, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (282, 26, 67, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (283, 26, 42, 19, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (284, 26, 152, 2, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (285, 26, 106, 0.5, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (286, 27, 79, 3, N' tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (287, 27, 69, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (288, 27, 29, 2, N' cloves')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (289, 27, 30, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (290, 27, 157, 5.5, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (291, 27, 158, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (292, 27, 35, 3, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (293, 27, 64, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (294, 27, 71, 2, N'sticks')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (295, 28, 10, 12, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (296, 28, 29, 2, N'cloves')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (297, 28, 158, 2, N'sprigs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (298, 28, 118, 1, N'bunch')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (299, 28, 20, 400, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (300, 28, 159, 200, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (301, 28, 155, 1, N' tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (302, 28, 3, 3, N' tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (303, 28, 26, 2, N' tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (304, 28, 1, 2, N' tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (305, 28, 116, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (306, 28, 158, 0.5, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (307, 28, 38, 3, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (308, 28, 69, 0.5, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (309, 28, 29, 3, N' cloves')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (310, 28, 12, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (311, 28, 118, 1, N'bunch')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (312, 28, 116, 0.5, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (313, 28, 155, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (314, 28, 160, 800, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (315, 29, 102, 2.5, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (316, 29, 64, 0.25, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (317, 29, 24, 1, N' yolk')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (318, 29, 24, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (319, 29, 76, 5, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (320, 29, 76, 6, N' tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (321, 29, 69, 1, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (322, 29, 161, 1, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (323, 29, 51, 227, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (324, 29, 83, 2, N'beaten')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (325, 29, 64, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (326, 29, 66, 0.25, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (327, 30, 162, 4, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (328, 30, 79, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (329, 30, 69, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (330, 30, 163, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (331, 30, 70, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (332, 30, 29, 3, N'cloves')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (333, 30, 16, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (334, 30, 40, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (335, 30, 64, 0.75, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (336, 30, 153, 0.5, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (337, 30, 83, 4, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (338, 31, 164, 230, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (339, 31, 170, 8, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (340, 31, 126, 16, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (341, 31, 136, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (342, 31, 76, 4, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (343, 31, 169, 455, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (344, 31, 168, 240, N'ml')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (345, 31, 171, 8, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (346, 31, 167, 60, N'ml')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (347, 31, 14, 0.125, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (348, 31, 78, 0.5, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (349, 31, 166, 0.5, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (350, 31, 136, 0.5, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (351, 31, 165, 0.75, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (352, 31, 23, 1, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (353, 31, 76, 85, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (354, 31, 76, 55, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (355, 32, 51, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (356, 32, 64, 3, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (357, 32, 78, 3, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (358, 32, 17, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (359, 32, 21, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (360, 32, 35, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (361, 32, 172, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (362, 32, 78, 3, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (363, 32, 17, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (364, 32, 40, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (365, 32, 29, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (366, 32, 69, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (367, 32, 173, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (368, 32, 174, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (369, 32, 137, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (370, 32, 175, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (371, 33, 176, 2.5, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (372, 33, 2, 500.5, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (373, 33, 64, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (374, 33, 15, 14, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (375, 33, 177, 3, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (376, 33, 95, 2.5, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (377, 33, 50, 0.5, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (378, 33, 178, 0.5, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (379, 33, 35, 2, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (380, 33, 179, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (381, 33, 12, 2, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (382, 33, 180, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (383, 33, 163, 0.5, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (384, 33, 64, 0.5, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (385, 33, 21, 1, N' tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (386, 33, 36, 0.25, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (387, 34, 44, 6, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (388, 34, 69, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (389, 34, 13, 4, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (390, 34, 16, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (391, 34, 17, 0.5, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (392, 34, 79, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (393, 34, 36, 0.25, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (394, 34, 181, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (395, 35, 182, 400, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (396, 35, 160, 1, N'can')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (397, 35, 95, 1, N'can')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (398, 35, 183, 1, N'packet')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (399, 36, 160, 4.5, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (400, 36, 44, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (401, 36, 118, 2, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (402, 36, 158, 4, N'sprigs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (403, 36, 69, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (404, 36, 78, 0.5, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (405, 36, 163, 2, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (406, 36, 13, 4, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (407, 36, 155, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (408, 36, 63, 909, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (409, 36, 2, 2, N'l')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (410, 36, 77, 4, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (411, 36, 23, 2.5, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (412, 36, 2, 0.5, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (413, 36, 20, 2.5, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (414, 37, 37, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (415, 37, 127, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (416, 37, 28, 2, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (417, 37, 13, 2, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (418, 37, 163, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (419, 37, 44, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (420, 37, 116, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (421, 37, 158, 2, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (422, 37, 155, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (423, 37, 1, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (424, 37, 6, 2, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (425, 37, 20, 4.5, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (426, 37, 26, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (427, 38, 184, 50, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (428, 38, 91, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (429, 38, 79, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (430, 38, 43, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (431, 38, 29, 1, N'clove')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (432, 38, 185, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (433, 38, 186, 200, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (434, 38, 187, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (435, 38, 188, 100, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (436, 38, 189, 250, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (437, 39, 190, 450, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (438, 39, 69, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (439, 39, 118, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (440, 39, 29, 2, N'cloves')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (441, 39, 12, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (442, 39, 191, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (443, 39, 1, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (444, 39, 192, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (445, 39, 26, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (446, 39, 2, 350, N'ml')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (447, 39, 193, 200, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (448, 39, 146, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (449, 39, 2, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (450, 40, 150, 50, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (451, 40, 194, 15, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (452, 40, 98, 10, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (453, 40, 42, 5, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (454, 40, 2, 750, N'ml')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (455, 40, 19, 0.5, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (456, 40, 77, 250, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (457, 40, 43, 2, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (458, 40, 13, 4, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (459, 40, 46, 30, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (460, 40, 195, 30, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (461, 40, 131, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (462, 40, 1, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (463, 40, 196, 4, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (464, 40, 24, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (465, 41, 83, 3, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (466, 41, 76, 2, N'knobs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (467, 41, 197, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (468, 41, 198, 3, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (469, 41, 86, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (470, 41, 199, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (471, 41, 200, 4, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (472, 42, 77, 2, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (473, 42, 201, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (474, 42, 29, 2, N'cloves')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (475, 42, 91, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (476, 42, 101, 2, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (477, 42, 202, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (478, 42, 33, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (479, 42, 26, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (480, 42, 21, 1.5, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (481, 42, 76, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (482, 43, 63, 455, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (483, 43, 26, 5, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (484, 43, 203, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (485, 43, 172, 3, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (486, 43, 204, 3, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (487, 43, 205, 3, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (488, 43, 206, 2.5, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (489, 43, 2, 2.5, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (490, 43, 19, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (491, 43, 116, 6, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (492, 43, 21, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (493, 43, 11, 5, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (494, 44, 207, 500, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (495, 44, 208, 250, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (496, 44, 69, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (497, 44, 29, 4, N'cloves')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (498, 44, 86, 3, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (499, 44, 40, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (500, 44, 59, 0.75, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (501, 44, 25, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (502, 44, 2, 3, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (503, 44, 140, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (504, 44, 64, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (505, 44, 66, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (506, 45, 209, 4, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (507, 45, 28, 2, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (508, 45, 44, 5, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (509, 45, 141, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (510, 45, 71, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (511, 45, 46, 0.25, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (512, 45, 172, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (513, 45, 155, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (514, 45, 35, 2, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (515, 45, 86, 4, N'sprigs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (516, 45, 173, 4, N'sprigs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (517, 45, 66, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (518, 45, 64, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (519, 46, 143, 8, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (520, 46, 210, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (521, 46, 211, 1200, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (522, 46, 212, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (523, 46, 174, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (524, 47, 79, 3, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (525, 47, 28, 2, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (526, 47, 71, 2, N'sticks')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (527, 47, 44, 300, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (528, 47, 77, 500, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (529, 47, 35, 4, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (530, 47, 81, 5, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (531, 47, 21, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (532, 47, 213, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (533, 47, 95, 1.5, N'kg')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (534, 47, 214, 500, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (535, 47, 140, 3, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (536, 47, 167, 400, N'ml')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (537, 48, 215, 800, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (538, 48, 69, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (539, 48, 63, 300, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (540, 48, 64, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (541, 48, 2, 1, N'l')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (542, 48, 13, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (543, 48, 79, 1, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (544, 49, 216, 250, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (545, 49, 65, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (546, 49, 69, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (547, 49, 46, 0.25, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (548, 49, 217, 10, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (549, 49, 118, 4, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (550, 49, 218, 4, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (551, 49, 1, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (552, 49, 219, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (553, 49, 80, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (554, 50, 143, 8, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (555, 50, 26, 3, N'tbsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (556, 50, 23, 100, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (557, 50, 83, 2, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (558, 50, 220, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (559, 50, 134, 225, N'ml')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (560, 50, 221, 200, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (561, 51, 20, 4.5, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (562, 51, 225, 113, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (563, 51, 147, 2, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (564, 51, 224, 3, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (565, 51, 29, 3, N'cloves')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (566, 51, 69, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (567, 51, 26, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (568, 51, 223, 113, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (569, 51, 150, 2.5, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (570, 51, 113, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (571, 51, 83, 4, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (572, 51, 123, 4.5, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (573, 51, 35, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (574, 51, 12, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (575, 51, 222, 0.25, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (576, 51, 2, 4.5, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (577, 51, 21, 3, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (578, 51, 19, 1, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (579, 52, 76, 100, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (580, 52, 226, 900, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (581, 52, 227, 3, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (582, 52, 28, 2, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (583, 52, 44, 4, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (584, 52, 23, 25, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (585, 52, 80, 2, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (586, 52, 33, 500, N'ml')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (587, 52, 228, 2, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (588, 52, 77, 900, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (589, 53, 79, 4, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (590, 53, 226, 750, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (591, 53, 229, 1.5, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (592, 53, 69, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (593, 53, 2, 25, N'ml')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (594, 53, 86, 30, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (595, 53, 76, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (596, 53, 91, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (597, 54, 230, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (598, 54, 69, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (599, 54, 71, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (600, 54, 141, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (601, 54, 77, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (602, 54, 76, 1, N'knob')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (603, 54, 231, 1, N'l')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (604, 54, 232, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (605, 54, 233, 140, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (606, 55, 102, 9.5, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (607, 55, 2, 264.5, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (608, 55, 64, 0.25, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (609, 55, 234, 2.5, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (610, 55, 79, 0.5, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (611, 56, 63, 500, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (612, 56, 28, 2, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (613, 56, 44, 2, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (614, 56, 29, 2, N'cloves')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (615, 56, 35, 2, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (616, 56, 104, 200, N'ml')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (617, 56, 2, 2, N'l')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (618, 56, 119, 3, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (619, 56, 64, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (620, 56, 66, 0.5, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (621, 56, 40, 0.5, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (622, 56, 26, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (623, 57, 76, 50, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (624, 57, 79, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (625, 57, 69, 1, N'kg')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (626, 57, 21, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (627, 57, 13, 4, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (628, 57, 23, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (629, 57, 93, 250, N'ml')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (630, 57, 108, 1, N'l')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (631, 57, 126, 4, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (632, 57, 200, 140, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (633, 58, 77, 4, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (634, 58, 118, 1, N'bunch')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (635, 58, 23, 100, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (636, 58, 67, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (637, 58, 134, 150, N'ml')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (638, 58, 235, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (639, 58, 76, 3, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (640, 58, 26, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (641, 58, 221, 6, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (642, 58, 99, 12, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (643, 58, 24, 6, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (644, 59, 236, 300, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (645, 59, 237, 23, N'kg')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (646, 59, 79, 120, N'ml')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (647, 59, 224, 24, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (648, 59, 44, 4, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (649, 59, 238, 2, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (650, 59, 142, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (651, 59, 239, 350, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (652, 59, 240, 150, N'ml')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (653, 59, 219, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (654, 59, 192, 4, N'sprigs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (655, 59, 156, 4, N'sprigs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (656, 59, 33, 450, N'ml')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (657, 60, 241, 8, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (658, 60, 69, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (659, 60, 79, 1, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (660, 60, 155, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (661, 60, 66, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (662, 60, 35, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (663, 61, 77, 1.5, N'kg')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (664, 61, 244, 16, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (665, 61, 37, 600, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (666, 61, 33, 350, N'ml')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (667, 61, 243, 400, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (668, 61, 81, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (669, 61, 240, 4, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (670, 61, 86, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (671, 61, 13, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (672, 61, 44, 3, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (673, 61, 224, 7, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (674, 61, 76, 30, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (675, 61, 242, 2, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (676, 61, 97, 5, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (677, 61, 76, 30, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (678, 61, 71, 2, N'sticks')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (679, 61, 245, 50, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (680, 62, 246, 180, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (681, 62, 247, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (682, 62, 74, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (683, 62, 1, 2, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (684, 62, 213, 2, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (685, 62, 21, 2, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (686, 62, 2, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (687, 62, 248, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (688, 62, 29, 2, N'cloves')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (689, 62, 37, 2.5, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (690, 62, 24, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (691, 62, 195, 9.5, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (692, 63, 51, 2, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (693, 63, 126, 2, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (694, 63, 249, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (695, 63, 127, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (696, 63, 120, 100, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (697, 63, 128, 100, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (698, 63, 99, 100, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (699, 63, 24, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (700, 63, 69, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (701, 63, 66, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (702, 64, 22, 1.5, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (703, 64, 29, 1, N'clove')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (704, 64, 68, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (705, 64, 251, 0.5, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (706, 64, 65, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (707, 64, 148, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (708, 64, 34, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (709, 64, 1, 3, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (710, 64, 250, 0.5, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (711, 64, 33, 1, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (712, 64, 2, 2, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (713, 64, 136, 0.25, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (714, 64, 152, 0.5, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (715, 64, 64, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (716, 64, 59, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (717, 64, 68, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (718, 64, 24, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (719, 64, 23, 2, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (720, 64, 118, 2, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (721, 64, 12, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (722, 65, 252, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (723, 65, 14, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (724, 65, 253, 4, N'fillets')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (725, 65, 26, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (726, 65, 254, 8, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (727, 65, 112, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (728, 65, 255, 2, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (729, 65, 256, 4, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (730, 65, 257, 1300, N'ml')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (731, 65, 124, 300, N'ml')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (732, 65, 91, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (733, 65, 29, 1, N'clove')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (734, 66, 28, 2, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (735, 66, 158, 1, N'sprig')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (736, 66, 79, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (737, 66, 77, 1.5, N'kg')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (738, 66, 231, 425, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (739, 67, 164, 500, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (740, 67, 33, 4.5, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (741, 67, 168, 1, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (742, 67, 258, 1, N'packet')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (743, 67, 64, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (744, 67, 22, 3, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (745, 67, 79, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (746, 67, 69, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (747, 67, 163, 2, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (748, 67, 29, 2, N'cloves')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (749, 67, 170, 2.5, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (750, 67, 86, 0, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (751, 68, 63, 1, N'kg')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (752, 68, 23, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (753, 68, 230, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (754, 68, 104, 200, N'ml')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (755, 68, 108, 400, N'ml')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (756, 68, 69, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (757, 68, 44, 2, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (758, 68, 158, 3, N'sprigs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (759, 68, 119, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (760, 68, 242, 2, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (761, 68, 259, 400, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (762, 68, 186, 300, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (763, 68, 76, 25, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (764, 68, 64, 0, N'pinch')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (765, 68, 66, 0, N'pinch')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (766, 69, 260, 500, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (767, 69, 79, 3, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (768, 69, 125, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (769, 69, 261, 0, N'pinch')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (770, 69, 240, 250, N'ml')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (771, 69, 95, 1.4, N'kg')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (772, 69, 5, 0.5, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (773, 69, 262, 1.2, N'kg')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (774, 70, 37, 1.5, N'kg')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (775, 70, 244, 100, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (776, 70, 265, 2, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (777, 70, 93, 180, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (778, 70, 33, 350, N'ml')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (779, 70, 158, 0, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (780, 70, 228, 4, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (781, 70, 40, 0.5, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (782, 70, 64, 0, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (783, 70, 81, 0, N'drizzle')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (784, 70, 29, 6, N'cloves')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (785, 70, 264, 8, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (786, 70, 263, 130, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (787, 70, 163, 3, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (788, 70, 43, 2, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (789, 70, 79, 6, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (790, 70, 76, 25, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (791, 70, 159, 300, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (792, 70, 66, 0, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (793, 71, 266, 4, N'meaty shanks')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (794, 71, 86, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (795, 71, 162, 2.5, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (796, 71, 33, 1, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (797, 71, 93, 2.5, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (798, 71, 35, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (799, 71, 106, 1.5, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (800, 71, 267, 2, N'strips')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (801, 71, 29, 3, N'cloves')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (802, 71, 18, 1, N'bulb')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (803, 71, 71, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (804, 71, 30, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (805, 71, 69, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (806, 71, 76, 3, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (807, 71, 79, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (808, 71, 102, 1, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (809, 71, 29, 1, N'clove')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (810, 71, 268, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (811, 72, 269, 1, N'kg')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (812, 72, 146, 1, N'kg')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (813, 72, 162, 2, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (814, 72, 64, 0, N'pinch')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (815, 72, 69, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (816, 72, 270, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (817, 72, 271, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (818, 73, 79, 4, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (819, 73, 272, 6, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (820, 73, 273, 0.5, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (821, 73, 274, 1, N'can')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (822, 73, 221, 4.5, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (823, 73, 48, 264.5, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (824, 73, 275, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (825, 73, 86, 1, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (826, 74, 276, 2, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (827, 74, 187, 4, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (828, 74, 185, 2, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (829, 74, 127, 4, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (830, 74, 79, 5, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (831, 74, 105, 0, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (832, 74, 69, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (833, 74, 13, 3, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (834, 74, 41, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (835, 74, 21, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (836, 75, 98, 400, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (837, 75, 1, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (838, 75, 81, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (839, 75, 146, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (840, 75, 219, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (841, 75, 27, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (842, 75, 150, 85, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (843, 75, 194, 3, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (844, 75, 3, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (845, 75, 13, 6, N'cloves')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (846, 75, 149, 450, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (847, 75, 12, 0, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (848, 76, 277, 280, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (849, 76, 278, 200, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (850, 76, 79, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (851, 76, 13, 2, N'cloves')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (852, 76, 38, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (853, 76, 279, 24, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (854, 76, 221, 12, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (855, 76, 280, 0, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (856, 76, 249, 0, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (857, 76, 126, 0, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (858, 76, 281, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (859, 76, 116, 2, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (860, 76, 219, 2, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (861, 77, 259, 300, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (862, 77, 67, 0, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (863, 77, 242, 0, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (864, 77, 26, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (865, 77, 63, 70, N'ml')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (866, 77, 227, 200, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (867, 77, 28, 2, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (868, 77, 23, 30, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (869, 77, 108, 85, N'ml')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (870, 77, 64, 0, N'pinch')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (871, 77, 66, 0, N'pinch')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (872, 77, 80, 0, N'dash')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (873, 78, 162, 4, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (874, 78, 21, 0, N'pinch')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (875, 78, 79, 4, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (876, 78, 69, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (877, 78, 13, 2, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (878, 78, 226, 200, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (879, 78, 282, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (880, 78, 81, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (881, 78, 123, 50, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (882, 78, 33, 100, N'ml')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (883, 78, 173, 4, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (884, 78, 283, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (885, 78, 115, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (886, 79, 79, 1.5, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (887, 79, 284, 250, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (888, 79, 86, 0, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (889, 79, 228, 2, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (890, 79, 145, 2, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (891, 79, 158, 3, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (892, 79, 81, 2, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (893, 79, 33, 150, N'ml')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (894, 79, 104, 600, N'ml')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (895, 79, 94, 3, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (896, 79, 29, 3, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (897, 79, 7, 2280, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (898, 79, 10, 4650, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (899, 79, 209, 2460, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (900, 79, 224, 12, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (901, 79, 99, 100, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (902, 79, 23, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (903, 79, 76, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (904, 80, 101, 2, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (905, 80, 240, 200, N'ml')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (906, 80, 40, 0.5, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (907, 80, 91, 2, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (908, 80, 181, 0.5, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (909, 80, 79, 0, N'dash')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (910, 80, 47, 0, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (911, 80, 77, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (912, 80, 26, 0, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (913, 81, 189, 2.5, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (914, 81, 69, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (915, 81, 44, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (916, 81, 81, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (917, 81, 16, 2, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (918, 81, 40, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (919, 81, 115, 0.5, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (920, 81, 158, 0.5, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (921, 81, 78, 0.25, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (922, 81, 175, 0.25, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (923, 81, 231, 9.5, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (924, 81, 2, 2.5, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (925, 81, 285, 0, N'pinch')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (926, 82, 207, 400, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (927, 82, 79, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (928, 82, 138, 2, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (929, 82, 69, 0, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (930, 82, 286, 0.25, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (931, 82, 287, 2, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (932, 82, 288, 2, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (933, 82, 47, 2.5, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (934, 82, 289, 2, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (935, 82, 66, 0, N'pinch')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (936, 82, 119, 2, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (937, 82, 152, 1.5, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (938, 82, 136, 1.5, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (939, 82, 40, 0.5, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (940, 83, 290, 227, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (941, 83, 76, 25, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (942, 83, 146, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (943, 83, 291, 100, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (944, 83, 292, 0, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (945, 83, 293, 250, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (946, 83, 86, 0, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (947, 84, 2, 150, N'ml')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (948, 84, 21, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (949, 84, 294, 15, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (950, 84, 23, 225, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (951, 84, 64, 1.5, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (952, 84, 79, 0, N'drizzle')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (953, 84, 214, 80, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (954, 84, 128, 70, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (955, 84, 156, 0, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (956, 84, 105, 0, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (957, 84, 78, 0, N'pinch')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (958, 85, 295, 909, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (959, 85, 116, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (960, 85, 191, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (961, 85, 80, 1, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (962, 85, 155, 0.5, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (963, 85, 21, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (964, 85, 44, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (965, 85, 296, 2, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (966, 85, 69, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (967, 85, 163, 0.5, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (968, 85, 35, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (969, 85, 158, 2, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (970, 85, 12, 0.5, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (971, 85, 29, 1, N'clove')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (972, 85, 26, 1, N'dl')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (973, 85, 185, 0.5, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (974, 85, 66, 0, N'pinch')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (975, 86, 297, 1, N'packet')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (976, 86, 207, 150, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (977, 86, 69, 150, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (978, 86, 42, 40, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (979, 86, 64, 0, N'dash')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (980, 86, 66, 0, N'dash')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (981, 87, 79, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (982, 87, 298, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (983, 87, 299, 2.5, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (984, 87, 140, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (985, 87, 20, 400, N'ml')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (986, 87, 300, 2, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (987, 87, 301, 100, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (988, 87, 116, 3, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (989, 87, 279, 150, N'g')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (990, 87, 17, 0.5, N'pack')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (991, 88, 79, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (992, 88, 306, 0.5, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (993, 88, 29, 2, N'cloves')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (994, 88, 181, 1, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (995, 88, 17, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (996, 88, 283, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (997, 88, 159, 2, N'tbs')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (998, 88, 305, 1, N'')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (999, 88, 282, 0.5, N'tsp')
INSERT INTO [dbo].[RecipeIngredient] ([Id], [RecipeId], [IngredientId], [Amount], [Unit]) VALUES (1000, 88, 69, 1, N'')
SET IDENTITY_INSERT [dbo].[RecipeIngredient] OFF
