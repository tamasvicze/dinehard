using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using DineHard.Data;
using DineHard.Models;
using GetFromAPI.GetAPI;
using Microsoft.EntityFrameworkCore;
using Meal = GetFromAPI.GetAPI.Meals;
using System.Linq;
using System.Threading.Channels;
using DineHard;

namespace GetFromAPI
{
    public class Program
    {
        public static async Task Main(string[] args)
        {
            var contextOptions = new DbContextOptionsBuilder<DineHardContext>()
                .UseSqlServer(@"Server=(localdb)\mssqllocaldb;" +
                                            "Database=DineHardContext-afd9c204-e427-45dd-a289-d6e138060237;" +
                                            "Trusted_Connection=True;MultipleActiveResultSets=true")
                .Options;


            var api = new GetRecipe(new HttpClient
            {
                BaseAddress = new Uri("https://www.themealdb.com/api/json/v1/1/")
            });
            //for (var i = 0; i < 50; i++)
            //{
            //    var dataFromApi = await api.GetRepository();
            //    await AddOneMeal(dataFromApi, contextOptions);
            //}
            await using DineHardContext db = new(contextOptions);

            List<RecipeIngredient> getIngredientRecipes = await db.RecipeIngredient.ToListAsync();

            foreach (var n in getIngredientRecipes)
            {
                if (n.Unit == "cup")
                {
                    double deciliter = ConvertUnit.CupToDeciliter(n.Amount);
                    double dlRounded = Math.Round(deciliter * 2) / 2;
                    RecipeIngredient updateCup = await db.RecipeIngredient.SingleAsync(x => x.Id == n.Id);

                    updateCup.Amount = dlRounded;
                    updateCup.Unit = "dl";
                }
                else if (n.Unit == "lbs" || n.Unit == "lbss")
                {
                    int gram = Convert.ToInt32(ConvertUnit.PoundToGram(n.Amount));
                    RecipeIngredient updateLbs = await db.RecipeIngredient.SingleAsync(x => x.Id == n.Id);

                    updateLbs.Amount = gram;
                    updateLbs.Unit = "g";
                }
                else if (n.Unit == "oz")
                {
                    int gram = Convert.ToInt32(ConvertUnit.OunceToGram(n.Amount));
                    RecipeIngredient updateLbs = await db.RecipeIngredient.SingleAsync(x => x.Id == n.Id);

                    updateLbs.Amount = gram;
                    updateLbs.Unit = "g";
                }
            }
            await db.SaveChangesAsync();

        }
        public static async Task AddOneMeal(MealRoot mealRoot, DbContextOptions<DineHardContext> contextOptions)
        {
            await using DineHardContext db = new(contextOptions);
            foreach (var meal in mealRoot.Meals)
            {
                var mealExists = db.Recipe.FirstOrDefault(i => i.Title == meal.StrMeal);
                if (meal.StrCategory != "Dessert" && meal.StrCategory != "Breakfast"&& mealExists == null)
                {


                    Recipe recipe = new()
                    {
                        Title = meal.StrMeal,
                        HowTo = meal.StrInstructions,
                        Wanted = true,
                        Category = (Category)Enum.Parse(typeof(Category), meal.StrCategory),
                        Region = meal.StrArea,
                        Image = meal.StrMealThumb,
                    };

                    CreateIngredientIfExists(recipe, meal.StrIngredient1, meal.StrMeasure1, db);
                    CreateIngredientIfExists(recipe, meal.StrIngredient2, meal.StrMeasure2, db);
                    CreateIngredientIfExists(recipe, meal.StrIngredient3, meal.StrMeasure3, db);
                    CreateIngredientIfExists(recipe, meal.StrIngredient4, meal.StrMeasure4, db);
                    CreateIngredientIfExists(recipe, meal.StrIngredient5, meal.StrMeasure5, db);
                    CreateIngredientIfExists(recipe, meal.StrIngredient6, meal.StrMeasure6, db);
                    CreateIngredientIfExists(recipe, meal.StrIngredient7, meal.StrMeasure7, db);
                    CreateIngredientIfExists(recipe, meal.StrIngredient8, meal.StrMeasure8, db);
                    CreateIngredientIfExists(recipe, meal.StrIngredient9, meal.StrMeasure9, db);
                    CreateIngredientIfExists(recipe, meal.StrIngredient10, meal.StrMeasure10, db);
                    CreateIngredientIfExists(recipe, meal.StrIngredient11, meal.StrMeasure11, db);
                    CreateIngredientIfExists(recipe, meal.StrIngredient12, meal.StrMeasure12, db);
                    CreateIngredientIfExists(recipe, meal.StrIngredient13, meal.StrMeasure13, db);
                    CreateIngredientIfExists(recipe, meal.StrIngredient14, meal.StrMeasure14, db);
                    CreateIngredientIfExists(recipe, meal.StrIngredient15, meal.StrMeasure15, db);
                    CreateIngredientIfExists(recipe, meal.StrIngredient16, meal.StrMeasure16, db);
                    CreateIngredientIfExists(recipe, meal.StrIngredient17, meal.StrMeasure17, db);
                    CreateIngredientIfExists(recipe, meal.StrIngredient18, meal.StrMeasure18, db);
                    CreateIngredientIfExists(recipe, meal.StrIngredient19, meal.StrMeasure19, db);
                    CreateIngredientIfExists(recipe, meal.StrIngredient20, meal.StrMeasure20, db);

                
                db.Recipe.Add(recipe);
                }
            }

            await db.SaveChangesAsync();
        }

        private static void CreateIngredientIfExists(Recipe recipe, string ingredient, string measure, DineHardContext db)
        {
            if (!string.IsNullOrWhiteSpace(ingredient))
            {
                List<char> measurements = new(measure);
                List<char> amounts = new();
                List<char> units = new();

                foreach (var n in measurements)
                {
                    if (char.IsDigit(n))
                    {
                        amounts.Add(n);
                    }
                    else
                    {
                        units.Add(n);
                    }
                }

                string unit = "";
                try
                {
                    unit = string.Join("", units);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }

                double amount = 0;

                if (amounts.Any())
                {
                    amount = Convert.ToDouble(string.Join("", amounts));
                }

                Ingredient ingredientExsists = db.Ingredient.FirstOrDefault(i => ingredient.Equals(i.Name));
                if (ingredientExsists == null)
                {
                    recipe.RecipeIngredients.Add(new RecipeIngredient()
                    {
                        Ingredient = new Ingredient()
                        {
                            Name = ingredient
                        },
                        Amount = amount,
                        Unit = unit ?? "",
                    });
                }
                else
                {
                    recipe.RecipeIngredients.Add(new RecipeIngredient()
                    {
                        Ingredient = ingredientExsists,
                        Amount = amount,
                        Unit = unit ?? "",
                    });
                }

                //Tester
                //recipe.RecipeIngredients.Add(new RecipeIngredient()
                //{
                //    Ingredient = ingredientExsists
                //                 ?? new Ingredient()
                //                 {
                //                     Name = ingredient
                //                 },
                //    Amount = amount,
                //    Unit = unit ?? "",
                //});
            }
        }

        private static async void ConvertToMetric(DbContextOptions<DineHardContext> contextOptions)
        {
            await using DineHardContext db = new(contextOptions);
            List<RecipeIngredient> getIngredientRecipes = await db.RecipeIngredient.ToListAsync();

            foreach (var n in getIngredientRecipes)
            {
                if (n.Unit == "cup")
                {
                    double deciliter = ConvertUnit.CupToDeciliter(n.Amount);
                    double dlRounded = Math.Round(deciliter * 2) / 2;
                    RecipeIngredient updateCup = await db.RecipeIngredient.SingleAsync(x => x.Id == n.Id);

                    updateCup.Amount = dlRounded;
                    updateCup.Unit = "dl";
                }
                else if (n.Unit == "lbs" || n.Unit == "lbss")
                {
                    int gram = Convert.ToInt32(ConvertUnit.PoundToGram(n.Amount));
                    RecipeIngredient updateLbs = await db.RecipeIngredient.SingleAsync(x => x.Id == n.Id);

                    updateLbs.Amount = gram;
                    updateLbs.Unit = "g";
                }
                else if (n.Unit == "oz")
                {
                    int gram = Convert.ToInt32(ConvertUnit.OunceToGram(n.Amount));
                    RecipeIngredient updateLbs = await db.RecipeIngredient.SingleAsync(x => x.Id == n.Id);

                    updateLbs.Amount = gram;
                    updateLbs.Unit = "g";
                }
            }
            await db.SaveChangesAsync();
        }
    }
}
