﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;

namespace GetFromAPI.GetAPI
{
    public interface IGetRecipe
    {
        Task<MealRoot> GetRepository();
    }
    public class GetRecipe : IGetRecipe
    {
        private readonly HttpClient _client;

        public GetRecipe(HttpClient client)
        {
            _client = client;
        }

        public async Task<MealRoot> GetRepository()
        {
            var response = await _client.GetAsync("random.php");
            var mystring = await response.Content.ReadAsStreamAsync();
            var repos = await JsonSerializer.DeserializeAsync<MealRoot>(mystring, new JsonSerializerOptions
            {
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase
            });
            return repos;
        }
    }
}
