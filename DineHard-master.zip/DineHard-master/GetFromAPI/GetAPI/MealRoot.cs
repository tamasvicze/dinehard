﻿namespace GetFromAPI.GetAPI
{
    public class MealRoot
    {
        public Meals[] Meals { get; set; }
    }
}