﻿namespace GetFromAPI
{
    public static class ConvertUnit
    {
        // Retrieved from: https://www.math-salamanders.com/measure-conversion-chart.html

        public static double OunceToGram(double ounce)
        {
            return ounce * 28.350;
        }

        public static double PoundToGram(double ounce)
        {
            return ounce * 454.59;
        }

        public static double PoundToKilogram(double pound)
        {
            return pound * 0.454;
        }

        public static double FluidOunceToMillilitre(double ounce)
        {
            return ounce * 28.41;
        }

        public static double PintToMillilitre(double pint)
        {
            return pint * 568.26;
        }

        public static double PintToLitre(double pint)
        {
            return pint * 0.568;
        }

        public static double GallonToLitre(double gallon)
        {
            return gallon * 4.546;
        }

        public static double BarrelToLitre(double barrel)
        {
            return barrel * 163.66;
        }

        public static double CupToDeciliter(double cup)
        {
            return cup * 2.36;
        }

        public static double CupToMililiter(double cup)
        {
            return cup * 236.58;
        }
    }
}