﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DineHard.Data;
using GetFromAPI.GetAPI;
using Microsoft.EntityFrameworkCore;
using NUnit.Framework;

namespace DineHardTests
{
    public class AddOneMealTests
    {
        [Test]
        public async Task Test()
        {
            var contextOptions = new DbContextOptionsBuilder<DineHardContext>()
                .UseInMemoryDatabase("DineHard")
                .Options;

            var meal = new MealRoot
            {
                Meals = new Meals[]
                {
                    new Meals
                    {
                        IdMeal = "52797",
                        StrMeal = "Spicy North African Potato Salad",
                        StrCategory = "Vegetarian",
                        StrArea = "Moroccan",
                        StrInstructions =
                            "Cook potatoes - place potatoes in a pot of cold water, and bring to the boil. Boil 20 minutes, or until potatoes are tender. You know they are cooked when you can stick a knife in them and the knife goes straight through.\r\nCombine harissa spice, olive oil, salt and pepper and lemon juice in a small bowl and whisk until combined.\r\nOnce potatoes are cooked, drain water and roughly chop potatoes in half.\r\nAdd harissa mix and spring onions/green onions to potatoes and stir.\r\nIn a large salad bowl, lay out arugula/rocket.\r\nTop with potato mix and toss.\r\nAdd fetta, mint and sprinkle over pine nuts.\r\nAdjust salt and pepper to taste.",
                        StrIngredient1 = "Small Potatoes",
                        StrIngredient2 = "Harissa Spice",
                        StrIngredient3 = "olive oil",
                        StrIngredient4 = "Lemon",
                        StrIngredient5 = "Spring onions",
                        StrIngredient6 = "Rocket",
                        StrIngredient7 = "Feta",
                        StrIngredient8 = "Mint",
                        StrIngredient9 = "Pine nuts",
                        StrIngredient10 = "Salt",
                        StrIngredient11 = "Pepper",
                        StrIngredient12 = "",
                        StrIngredient13 = "",
                        StrIngredient14 = "",
                        StrIngredient15 = "",
                        StrIngredient16 = "",
                        StrIngredient17 = "",
                        StrIngredient18 = "",
                        StrIngredient19 = "",
                        StrIngredient20 = "",
                        StrMeasure1 = "650g/1lb 8 oz",
                        StrMeasure2 = "1 tsp",
                        StrMeasure3 = "2 tsp",
                        StrMeasure4 = "juice of half",
                        StrMeasure5 = "4",
                        StrMeasure6 = "150g/6oz",
                        StrMeasure7 = "80g/3oz",
                        StrMeasure8 = "20 chopped",
                        StrMeasure9 = "2 tablespoons",
                        StrMeasure10 = "Pinch",
                        StrMeasure11 = "Pinch",
                        StrMeasure12 = "",
                        StrMeasure13 = "",
                        StrMeasure14 = "",
                        StrMeasure15 = "",
                        StrMeasure16 = "",
                        StrMeasure17 = "",
                        StrMeasure18 = "",
                        StrMeasure19 = "",
                        StrMeasure20 = "",
                    }
                }
            };

            await GetFromAPI.Program.AddOneMeal(meal, contextOptions);
        }
    }
}
