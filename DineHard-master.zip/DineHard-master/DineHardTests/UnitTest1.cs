using System;
using System.Collections.Generic;
using NUnit.Framework;
using DineHard.Logic;

namespace DineHardTests
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void FailsIfTooFewMeals()
        {
            var myTestList = new List<int>
            {
                1, 2
            };
            var numberOfMealsToGenerate = 3;

            Assert.Throws<ArgumentException>(() =>
            {
                GenerateRandomMeal.GenerateMealPlan(myTestList, numberOfMealsToGenerate);
            });
        }

        [Test]
        public void Test1()
        {
            var myTestList = new List<int>
            {
                1, 2, 3
            };
            var numberOfMealsToGenerate = 2;

            var mealPlan = GenerateRandomMeal.GenerateMealPlan(myTestList, numberOfMealsToGenerate);

            Assert.AreEqual(mealPlan.Count, numberOfMealsToGenerate);
        }
    }
}